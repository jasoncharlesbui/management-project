--
-- PostgreSQL database dump
--

-- Dumped from database version 9.5.12
-- Dumped by pg_dump version 9.5.12

SET statement_timeout = 0;
SET lock_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: plpgsql; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS plpgsql WITH SCHEMA pg_catalog;


--
-- Name: EXTENSION plpgsql; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON EXTENSION plpgsql IS 'PL/pgSQL procedural language';


--
-- Name: uid(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.uid() RETURNS text
    LANGUAGE sql
    AS $$ SELECT substring('abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ' FROM (random()*51)::int +1 for 1) || array_to_string(ARRAY(SELECT substring('abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789'  FROM (random()*61)::int + 1 FOR 1) FROM generate_series(1,10)), '') $$;


SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: attribute; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.attribute (
    attributeid integer NOT NULL,
    uid character varying(11) NOT NULL,
    code character varying(50),
    created timestamp without time zone NOT NULL,
    lastupdated timestamp without time zone NOT NULL,
    lastupdatedby integer,
    name character varying(230) NOT NULL,
    shortname character varying(50),
    description text,
    valuetype character varying(50) NOT NULL,
    mandatory boolean NOT NULL,
    isunique boolean,
    dataelementattribute boolean NOT NULL,
    dataelementgroupattribute boolean,
    indicatorattribute boolean NOT NULL,
    indicatorgroupattribute boolean,
    datasetattribute boolean,
    organisationunitattribute boolean NOT NULL,
    organisationunitgroupattribute boolean,
    organisationunitgroupsetattribute boolean,
    userattribute boolean NOT NULL,
    usergroupattribute boolean,
    programattribute boolean,
    programstageattribute boolean,
    trackedentitytypeattribute boolean,
    trackedentityattributeattribute boolean,
    categoryoptionattribute boolean,
    categoryoptiongroupattribute boolean,
    documentattribute boolean,
    optionattribute boolean,
    optionsetattribute boolean,
    constantattribute boolean,
    legendsetattribute boolean,
    programindicatorattribute boolean,
    sqlviewattribute boolean,
    sectionattribute boolean,
    categoryoptioncomboattribute boolean,
    sortorder integer,
    optionsetid integer,
    userid integer,
    publicaccess character varying(8)
);


--
-- Name: attributetranslations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.attributetranslations (
    attributeid integer NOT NULL,
    objecttranslationid integer NOT NULL
);


--
-- Name: attributeuseraccesses; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.attributeuseraccesses (
    attributeid integer NOT NULL,
    useraccessid integer NOT NULL
);


--
-- Name: attributeusergroupaccesses; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.attributeusergroupaccesses (
    attributeid integer NOT NULL,
    usergroupaccessid integer NOT NULL
);


--
-- Name: attributevalue; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.attributevalue (
    attributevalueid integer NOT NULL,
    created timestamp without time zone,
    lastupdated timestamp without time zone,
    value text,
    attributeid integer NOT NULL
);


--
-- Name: categories_categoryoptions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.categories_categoryoptions (
    categoryid integer NOT NULL,
    sort_order integer NOT NULL,
    categoryoptionid integer NOT NULL
);


--
-- Name: categorycombo; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.categorycombo (
    categorycomboid integer NOT NULL,
    uid character varying(11) NOT NULL,
    code character varying(50),
    created timestamp without time zone NOT NULL,
    lastupdated timestamp without time zone NOT NULL,
    lastupdatedby integer,
    name character varying(230) NOT NULL,
    datadimensiontype character varying(255) NOT NULL,
    skiptotal boolean NOT NULL,
    userid integer,
    publicaccess character varying(8)
);


--
-- Name: categorycombos_categories; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.categorycombos_categories (
    categoryid integer,
    sort_order integer NOT NULL,
    categorycomboid integer NOT NULL
);


--
-- Name: categorycombos_optioncombos; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.categorycombos_optioncombos (
    categoryoptioncomboid integer NOT NULL,
    categorycomboid integer NOT NULL
);


--
-- Name: categorycombotranslations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.categorycombotranslations (
    categorycomboid integer NOT NULL,
    objecttranslationid integer NOT NULL
);


--
-- Name: categorycombouseraccesses; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.categorycombouseraccesses (
    categorycomboid integer NOT NULL,
    useraccessid integer NOT NULL
);


--
-- Name: categorycombousergroupaccesses; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.categorycombousergroupaccesses (
    categorycomboid integer NOT NULL,
    usergroupaccessid integer NOT NULL
);


--
-- Name: categorydimension; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.categorydimension (
    categorydimensionid integer NOT NULL,
    categoryid integer
);


--
-- Name: categorydimension_items; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.categorydimension_items (
    categorydimensionid integer NOT NULL,
    sort_order integer NOT NULL,
    categoryoptionid integer NOT NULL
);


--
-- Name: categoryoption_organisationunits; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.categoryoption_organisationunits (
    organisationunitid integer NOT NULL,
    categoryoptionid integer NOT NULL
);


--
-- Name: categoryoptioncombo; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.categoryoptioncombo (
    categoryoptioncomboid integer NOT NULL,
    uid character varying(11) NOT NULL,
    code character varying(50),
    created timestamp without time zone NOT NULL,
    lastupdated timestamp without time zone NOT NULL,
    lastupdatedby integer,
    name text,
    ignoreapproval boolean
);


--
-- Name: categoryoptioncomboattributevalues; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.categoryoptioncomboattributevalues (
    categoryoptioncomboid integer NOT NULL,
    attributevalueid integer NOT NULL
);


--
-- Name: categoryoptioncombos_categoryoptions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.categoryoptioncombos_categoryoptions (
    categoryoptionid integer NOT NULL,
    categoryoptioncomboid integer NOT NULL
);


--
-- Name: categoryoptioncombotranslations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.categoryoptioncombotranslations (
    categoryoptioncomboid integer NOT NULL,
    objecttranslationid integer NOT NULL
);


--
-- Name: categoryoptiongroup; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.categoryoptiongroup (
    categoryoptiongroupid integer NOT NULL,
    uid character varying(11) NOT NULL,
    code character varying(50),
    created timestamp without time zone NOT NULL,
    lastupdated timestamp without time zone NOT NULL,
    lastupdatedby integer,
    name character varying(230) NOT NULL,
    shortname character varying(50) NOT NULL,
    datadimensiontype character varying(255),
    userid integer,
    publicaccess character varying(8)
);


--
-- Name: categoryoptiongroupattributevalues; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.categoryoptiongroupattributevalues (
    categoryoptiongroupid integer NOT NULL,
    attributevalueid integer NOT NULL
);


--
-- Name: categoryoptiongroupmembers; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.categoryoptiongroupmembers (
    categoryoptiongroupid integer NOT NULL,
    categoryoptionid integer NOT NULL
);


--
-- Name: categoryoptiongroupset; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.categoryoptiongroupset (
    categoryoptiongroupsetid integer NOT NULL,
    uid character varying(11) NOT NULL,
    code character varying(50),
    created timestamp without time zone NOT NULL,
    lastupdated timestamp without time zone NOT NULL,
    lastupdatedby integer,
    name character varying(230) NOT NULL,
    description text,
    datadimension boolean NOT NULL,
    datadimensiontype character varying(255),
    userid integer,
    publicaccess character varying(8)
);


--
-- Name: categoryoptiongroupsetdimension; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.categoryoptiongroupsetdimension (
    categoryoptiongroupsetdimensionid integer NOT NULL,
    categoryoptiongroupsetid integer
);


--
-- Name: categoryoptiongroupsetdimension_items; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.categoryoptiongroupsetdimension_items (
    categoryoptiongroupsetdimensionid integer NOT NULL,
    sort_order integer NOT NULL,
    categoryoptiongroupid integer NOT NULL
);


--
-- Name: categoryoptiongroupsetmembers; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.categoryoptiongroupsetmembers (
    categoryoptiongroupsetid integer NOT NULL,
    sort_order integer NOT NULL,
    categoryoptiongroupid integer NOT NULL
);


--
-- Name: categoryoptiongroupsettranslations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.categoryoptiongroupsettranslations (
    categoryoptiongroupsetid integer NOT NULL,
    objecttranslationid integer NOT NULL
);


--
-- Name: categoryoptiongroupsetuseraccesses; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.categoryoptiongroupsetuseraccesses (
    categoryoptiongroupsetid integer NOT NULL,
    useraccessid integer NOT NULL
);


--
-- Name: categoryoptiongroupsetusergroupaccesses; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.categoryoptiongroupsetusergroupaccesses (
    categoryoptiongroupsetid integer NOT NULL,
    usergroupaccessid integer NOT NULL
);


--
-- Name: categoryoptiongrouptranslations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.categoryoptiongrouptranslations (
    categoryoptiongroupid integer NOT NULL,
    objecttranslationid integer NOT NULL
);


--
-- Name: categoryoptiongroupuseraccesses; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.categoryoptiongroupuseraccesses (
    categoryoptiongroupid integer NOT NULL,
    useraccessid integer NOT NULL
);


--
-- Name: categoryoptiongroupusergroupaccesses; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.categoryoptiongroupusergroupaccesses (
    categoryoptiongroupid integer NOT NULL,
    usergroupaccessid integer NOT NULL
);


--
-- Name: categoryoptiontranslations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.categoryoptiontranslations (
    categoryoptionid integer NOT NULL,
    objecttranslationid integer NOT NULL
);


--
-- Name: chart; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.chart (
    chartid integer NOT NULL,
    uid character varying(11) NOT NULL,
    code character varying(50),
    created timestamp without time zone NOT NULL,
    lastupdated timestamp without time zone NOT NULL,
    lastupdatedby integer,
    name character varying(230) NOT NULL,
    description text,
    domainaxislabel character varying(255),
    rangeaxislabel character varying(255),
    type character varying(40) NOT NULL,
    series character varying(255),
    category character varying(255),
    hidelegend boolean,
    nospacebetweencolumns boolean,
    regressiontype character varying(40) NOT NULL,
    title character varying(255),
    subtitle character varying(255),
    hidetitle boolean,
    hidesubtitle boolean,
    targetlinevalue double precision,
    targetlinelabel character varying(255),
    baselinevalue double precision,
    baselinelabel character varying(255),
    relativeperiodsid integer,
    userorganisationunit boolean,
    userorganisationunitchildren boolean,
    userorganisationunitgrandchildren boolean,
    aggregationtype character varying(40),
    completedonly boolean,
    showdata boolean,
    hideemptyrowitems character varying(40),
    percentstackedvalues boolean,
    cumulativevalues boolean,
    rangeaxismaxvalue double precision,
    rangeaxisminvalue double precision,
    rangeaxissteps integer,
    rangeaxisdecimals integer,
    legendsetid integer,
    legenddisplaystrategy character varying(40),
    colorsetid integer,
    sortorder integer,
    externalaccess boolean,
    userid integer,
    publicaccess character varying(8),
    favorites jsonb
);


--
-- Name: chart_categorydimensions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.chart_categorydimensions (
    chartid integer NOT NULL,
    sort_order integer NOT NULL,
    categorydimensionid integer NOT NULL
);


--
-- Name: chart_categoryoptiongroupsetdimensions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.chart_categoryoptiongroupsetdimensions (
    chart integer NOT NULL,
    sort_order integer NOT NULL,
    categoryoptiongroupsetdimensionid integer NOT NULL
);


--
-- Name: chart_datadimensionitems; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.chart_datadimensionitems (
    chartid integer NOT NULL,
    sort_order integer NOT NULL,
    datadimensionitemid integer NOT NULL
);


--
-- Name: chart_dataelementgroupsetdimensions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.chart_dataelementgroupsetdimensions (
    chartid integer NOT NULL,
    sort_order integer NOT NULL,
    dataelementgroupsetdimensionid integer NOT NULL
);


--
-- Name: chart_filters; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.chart_filters (
    chartid integer NOT NULL,
    sort_order integer NOT NULL,
    filter character varying(255)
);


--
-- Name: chart_itemorgunitgroups; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.chart_itemorgunitgroups (
    chartid integer NOT NULL,
    sort_order integer NOT NULL,
    orgunitgroupid integer NOT NULL
);


--
-- Name: chart_organisationunits; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.chart_organisationunits (
    chartid integer NOT NULL,
    sort_order integer NOT NULL,
    organisationunitid integer NOT NULL
);


--
-- Name: chart_orgunitgroupsetdimensions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.chart_orgunitgroupsetdimensions (
    chartid integer NOT NULL,
    sort_order integer NOT NULL,
    orgunitgroupsetdimensionid integer NOT NULL
);


--
-- Name: chart_orgunitlevels; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.chart_orgunitlevels (
    chartid integer NOT NULL,
    sort_order integer NOT NULL,
    orgunitlevel integer
);


--
-- Name: chart_periods; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.chart_periods (
    chartid integer NOT NULL,
    sort_order integer NOT NULL,
    periodid integer NOT NULL
);


--
-- Name: charttranslations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.charttranslations (
    chartid integer NOT NULL,
    objecttranslationid integer NOT NULL
);


--
-- Name: chartuseraccesses; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.chartuseraccesses (
    chartid integer NOT NULL,
    useraccessid integer NOT NULL
);


--
-- Name: chartusergroupaccesses; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.chartusergroupaccesses (
    chartid integer NOT NULL,
    usergroupaccessid integer NOT NULL
);


--
-- Name: color; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.color (
    colorid integer NOT NULL,
    uid character varying(11) NOT NULL,
    code character varying(50),
    created timestamp without time zone NOT NULL,
    lastupdated timestamp without time zone NOT NULL,
    lastupdatedby integer,
    color character varying(255)
);


--
-- Name: colorset; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.colorset (
    colorsetid integer NOT NULL,
    uid character varying(11) NOT NULL,
    code character varying(50),
    created timestamp without time zone NOT NULL,
    lastupdated timestamp without time zone NOT NULL,
    lastupdatedby integer,
    name character varying(230) NOT NULL
);


--
-- Name: colorset_colors; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.colorset_colors (
    colorsetid integer NOT NULL,
    sort_order integer NOT NULL,
    colorid integer NOT NULL
);


--
-- Name: colorsettranslations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.colorsettranslations (
    colorsetid integer NOT NULL,
    objecttranslationid integer NOT NULL
);


--
-- Name: colortranslations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.colortranslations (
    colorid integer NOT NULL,
    objecttranslationid integer NOT NULL
);


--
-- Name: completedatasetregistration; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.completedatasetregistration (
    datasetid integer NOT NULL,
    periodid integer NOT NULL,
    sourceid integer NOT NULL,
    attributeoptioncomboid integer NOT NULL,
    date timestamp without time zone,
    storedby character varying(255)
);


--
-- Name: configuration; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.configuration (
    configurationid integer NOT NULL,
    systemid character varying(255),
    feedbackrecipientsid integer,
    offlineorgunitlevelid integer,
    infrastructuralindicatorsid integer,
    infrastructuraldataelementsid integer,
    infrastructuralperiodtypeid integer,
    selfregistrationrole integer,
    selfregistrationorgunit integer
);


--
-- Name: configuration_corswhitelist; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.configuration_corswhitelist (
    configurationid integer NOT NULL,
    corswhitelist character varying(255)
);


--
-- Name: constant; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.constant (
    constantid integer NOT NULL,
    uid character varying(11) NOT NULL,
    code character varying(50),
    created timestamp without time zone NOT NULL,
    lastupdated timestamp without time zone NOT NULL,
    lastupdatedby integer,
    name character varying(230) NOT NULL,
    shortname character varying(50),
    description text,
    value double precision NOT NULL,
    userid integer,
    publicaccess character varying(8)
);


--
-- Name: constantattributevalues; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.constantattributevalues (
    constantid integer NOT NULL,
    attributevalueid integer NOT NULL
);


--
-- Name: constanttranslations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.constanttranslations (
    colorid integer NOT NULL,
    objecttranslationid integer NOT NULL
);


--
-- Name: constantuseraccesses; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.constantuseraccesses (
    constantid integer NOT NULL,
    useraccessid integer NOT NULL
);


--
-- Name: constantusergroupaccesses; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.constantusergroupaccesses (
    constantid integer NOT NULL,
    usergroupaccessid integer NOT NULL
);


--
-- Name: dashboard; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.dashboard (
    dashboardid integer NOT NULL,
    uid character varying(11) NOT NULL,
    code character varying(50),
    created timestamp without time zone NOT NULL,
    lastupdated timestamp without time zone NOT NULL,
    lastupdatedby integer,
    name character varying(230) NOT NULL,
    description text,
    userid integer,
    externalaccess boolean,
    publicaccess character varying(8),
    favorites jsonb
);


--
-- Name: dashboard_items; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.dashboard_items (
    dashboardid integer NOT NULL,
    sort_order integer NOT NULL,
    dashboarditemid integer NOT NULL
);


--
-- Name: dashboarditem; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.dashboarditem (
    dashboarditemid integer NOT NULL,
    uid character varying(11) NOT NULL,
    code character varying(50),
    created timestamp without time zone NOT NULL,
    lastupdated timestamp without time zone NOT NULL,
    lastupdatedby integer,
    chartid integer,
    eventchartid integer,
    mapid integer,
    reporttable integer,
    eventreport integer,
    textcontent text,
    messages boolean,
    appkey character varying(255),
    shape character varying(50),
    x integer,
    y integer,
    height integer,
    width integer
);


--
-- Name: dashboarditem_reports; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.dashboarditem_reports (
    dashboarditemid integer NOT NULL,
    sort_order integer NOT NULL,
    reportid integer NOT NULL
);


--
-- Name: dashboarditem_resources; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.dashboarditem_resources (
    dashboarditemid integer NOT NULL,
    sort_order integer NOT NULL,
    resourceid integer NOT NULL
);


--
-- Name: dashboarditem_users; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.dashboarditem_users (
    dashboarditemid integer NOT NULL,
    sort_order integer NOT NULL,
    userid integer NOT NULL
);


--
-- Name: dashboarditemtranslations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.dashboarditemtranslations (
    dashboarditemid integer NOT NULL,
    objecttranslationid integer NOT NULL
);


--
-- Name: dashboardtranslations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.dashboardtranslations (
    dashboardid integer NOT NULL,
    objecttranslationid integer NOT NULL
);


--
-- Name: dashboarduseraccesses; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.dashboarduseraccesses (
    dashboardid integer NOT NULL,
    useraccessid integer NOT NULL
);


--
-- Name: dashboardusergroupaccesses; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.dashboardusergroupaccesses (
    dashboardid integer NOT NULL,
    usergroupaccessid integer NOT NULL
);


--
-- Name: dataapproval; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.dataapproval (
    dataapprovalid integer NOT NULL,
    dataapprovallevelid integer NOT NULL,
    workflowid integer NOT NULL,
    periodid integer NOT NULL,
    organisationunitid integer NOT NULL,
    attributeoptioncomboid integer NOT NULL,
    accepted boolean NOT NULL,
    created timestamp without time zone NOT NULL,
    creator integer NOT NULL
);


--
-- Name: dataapprovalaudit; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.dataapprovalaudit (
    dataapprovalauditid integer NOT NULL,
    levelid integer NOT NULL,
    workflowid integer NOT NULL,
    periodid integer NOT NULL,
    organisationunitid integer NOT NULL,
    attributeoptioncomboid integer NOT NULL,
    action character varying(100) NOT NULL,
    created timestamp without time zone NOT NULL,
    creator integer NOT NULL
);


--
-- Name: dataapprovallevel; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.dataapprovallevel (
    dataapprovallevelid integer NOT NULL,
    uid character varying(11) NOT NULL,
    code character varying(50),
    created timestamp without time zone NOT NULL,
    lastupdated timestamp without time zone NOT NULL,
    lastupdatedby integer,
    name character varying(230) NOT NULL,
    level integer NOT NULL,
    orgunitlevel integer NOT NULL,
    categoryoptiongroupsetid integer,
    userid integer,
    publicaccess character varying(8)
);


--
-- Name: dataapprovalleveltranslations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.dataapprovalleveltranslations (
    dataapprovallevelid integer NOT NULL,
    objecttranslationid integer NOT NULL
);


--
-- Name: dataapprovalleveluseraccesses; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.dataapprovalleveluseraccesses (
    dataapprovallevelid integer NOT NULL,
    useraccessid integer NOT NULL
);


--
-- Name: dataapprovallevelusergroupaccesses; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.dataapprovallevelusergroupaccesses (
    dataapprovallevelid integer NOT NULL,
    usergroupaccessid integer NOT NULL
);


--
-- Name: dataapprovalworkflow; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.dataapprovalworkflow (
    workflowid integer NOT NULL,
    uid character varying(11) NOT NULL,
    code character varying(50),
    created timestamp without time zone NOT NULL,
    lastupdated timestamp without time zone NOT NULL,
    lastupdatedby integer,
    name character varying(230) NOT NULL,
    periodtypeid integer NOT NULL,
    categorycomboid integer,
    userid integer,
    publicaccess character varying(8)
);


--
-- Name: dataapprovalworkflowlevels; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.dataapprovalworkflowlevels (
    workflowid integer NOT NULL,
    dataapprovallevelid integer NOT NULL
);


--
-- Name: dataapprovalworkflowtranslations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.dataapprovalworkflowtranslations (
    workflowid integer NOT NULL,
    objecttranslationid integer NOT NULL
);


--
-- Name: dataapprovalworkflowuseraccesses; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.dataapprovalworkflowuseraccesses (
    workflowid integer NOT NULL,
    useraccessid integer NOT NULL
);


--
-- Name: dataapprovalworkflowusergroupaccesses; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.dataapprovalworkflowusergroupaccesses (
    workflowid integer NOT NULL,
    usergroupaccessid integer NOT NULL
);


--
-- Name: datadimensionitem; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.datadimensionitem (
    datadimensionitemid integer NOT NULL,
    indicatorid integer,
    dataelementid integer,
    dataelementoperand_dataelementid integer,
    dataelementoperand_categoryoptioncomboid integer,
    datasetid integer,
    metric character varying(50),
    programindicatorid integer,
    programdataelement_programid integer,
    programdataelement_dataelementid integer,
    programattribute_programid integer,
    programattribute_attributeid integer
);


--
-- Name: dataelement; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.dataelement (
    dataelementid integer NOT NULL,
    uid character varying(11) NOT NULL,
    code character varying(50),
    created timestamp without time zone NOT NULL,
    lastupdated timestamp without time zone NOT NULL,
    lastupdatedby integer,
    name character varying(230) NOT NULL,
    shortname character varying(50) NOT NULL,
    description text,
    formname character varying(230),
    style jsonb,
    valuetype character varying(50) NOT NULL,
    domaintype character varying(255) NOT NULL,
    aggregationtype character varying(50) NOT NULL,
    categorycomboid integer NOT NULL,
    url character varying(255),
    zeroissignificant boolean NOT NULL,
    optionsetid integer,
    commentoptionsetid integer,
    userid integer,
    publicaccess character varying(8)
);


--
-- Name: dataelementaggregationlevels; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.dataelementaggregationlevels (
    dataelementid integer NOT NULL,
    sort_order integer NOT NULL,
    aggregationlevel integer
);


--
-- Name: dataelementattributevalues; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.dataelementattributevalues (
    dataelementid integer NOT NULL,
    attributevalueid integer NOT NULL
);


--
-- Name: dataelementcategory; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.dataelementcategory (
    categoryid integer NOT NULL,
    uid character varying(11) NOT NULL,
    code character varying(50),
    created timestamp without time zone NOT NULL,
    lastupdated timestamp without time zone NOT NULL,
    lastupdatedby integer,
    name character varying(230) NOT NULL,
    datadimensiontype character varying(255) NOT NULL,
    datadimension boolean NOT NULL,
    userid integer,
    publicaccess character varying(8)
);


--
-- Name: dataelementcategoryoption; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.dataelementcategoryoption (
    categoryoptionid integer NOT NULL,
    uid character varying(11) NOT NULL,
    code character varying(50),
    created timestamp without time zone NOT NULL,
    lastupdated timestamp without time zone NOT NULL,
    lastupdatedby integer,
    name character varying(230) NOT NULL,
    shortname character varying(50),
    startdate date,
    enddate date,
    style jsonb,
    userid integer,
    publicaccess character varying(8)
);


--
-- Name: dataelementcategoryoptionattributevalues; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.dataelementcategoryoptionattributevalues (
    categoryoptionid integer NOT NULL,
    attributevalueid integer NOT NULL
);


--
-- Name: dataelementcategoryoptionuseraccesses; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.dataelementcategoryoptionuseraccesses (
    categoryoptionid integer NOT NULL,
    useraccessid integer NOT NULL
);


--
-- Name: dataelementcategoryoptionusergroupaccesses; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.dataelementcategoryoptionusergroupaccesses (
    categoryoptionid integer NOT NULL,
    usergroupaccessid integer NOT NULL
);


--
-- Name: dataelementcategorytranslations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.dataelementcategorytranslations (
    categoryid integer NOT NULL,
    objecttranslationid integer NOT NULL
);


--
-- Name: dataelementcategoryuseraccesses; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.dataelementcategoryuseraccesses (
    categoryid integer NOT NULL,
    useraccessid integer NOT NULL
);


--
-- Name: dataelementcategoryusergroupaccesses; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.dataelementcategoryusergroupaccesses (
    categoryid integer NOT NULL,
    usergroupaccessid integer NOT NULL
);


--
-- Name: dataelementgroup; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.dataelementgroup (
    dataelementgroupid integer NOT NULL,
    uid character varying(11) NOT NULL,
    code character varying(50),
    created timestamp without time zone NOT NULL,
    lastupdated timestamp without time zone NOT NULL,
    lastupdatedby integer,
    name character varying(230) NOT NULL,
    shortname character varying(50),
    userid integer,
    publicaccess character varying(8)
);


--
-- Name: dataelementgroupattributevalues; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.dataelementgroupattributevalues (
    dataelementgroupid integer NOT NULL,
    attributevalueid integer NOT NULL
);


--
-- Name: dataelementgroupmembers; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.dataelementgroupmembers (
    dataelementgroupid integer NOT NULL,
    dataelementid integer NOT NULL
);


--
-- Name: dataelementgroupset; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.dataelementgroupset (
    dataelementgroupsetid integer NOT NULL,
    uid character varying(11) NOT NULL,
    code character varying(50),
    created timestamp without time zone NOT NULL,
    lastupdated timestamp without time zone NOT NULL,
    lastupdatedby integer,
    name character varying(230) NOT NULL,
    description text,
    compulsory boolean,
    datadimension boolean NOT NULL,
    userid integer,
    publicaccess character varying(8)
);


--
-- Name: dataelementgroupsetdimension; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.dataelementgroupsetdimension (
    dataelementgroupsetdimensionid integer NOT NULL,
    dataelementgroupsetid integer
);


--
-- Name: dataelementgroupsetdimension_items; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.dataelementgroupsetdimension_items (
    dataelementgroupsetdimensionid integer NOT NULL,
    sort_order integer NOT NULL,
    dataelementgroupid integer NOT NULL
);


--
-- Name: dataelementgroupsetmembers; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.dataelementgroupsetmembers (
    dataelementgroupsetid integer NOT NULL,
    sort_order integer NOT NULL,
    dataelementgroupid integer NOT NULL
);


--
-- Name: dataelementgroupsettranslations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.dataelementgroupsettranslations (
    dataelementgroupsetid integer NOT NULL,
    objecttranslationid integer NOT NULL
);


--
-- Name: dataelementgroupsetuseraccesses; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.dataelementgroupsetuseraccesses (
    dataelementgroupsetid integer NOT NULL,
    useraccessid integer NOT NULL
);


--
-- Name: dataelementgroupsetusergroupaccesses; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.dataelementgroupsetusergroupaccesses (
    dataelementgroupsetid integer NOT NULL,
    usergroupaccessid integer NOT NULL
);


--
-- Name: dataelementgrouptranslations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.dataelementgrouptranslations (
    dataelementgroupid integer NOT NULL,
    objecttranslationid integer NOT NULL
);


--
-- Name: dataelementgroupuseraccesses; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.dataelementgroupuseraccesses (
    dataelementgroupid integer NOT NULL,
    useraccessid integer NOT NULL
);


--
-- Name: dataelementgroupusergroupaccesses; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.dataelementgroupusergroupaccesses (
    dataelementgroupid integer NOT NULL,
    usergroupaccessid integer NOT NULL
);


--
-- Name: dataelementlegendsets; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.dataelementlegendsets (
    dataelementid integer NOT NULL,
    sort_order integer NOT NULL,
    legendsetid integer NOT NULL
);


--
-- Name: dataelementoperand; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.dataelementoperand (
    dataelementoperandid integer NOT NULL,
    dataelementid integer,
    categoryoptioncomboid integer
);


--
-- Name: dataelementtranslations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.dataelementtranslations (
    dataelementid integer NOT NULL,
    objecttranslationid integer NOT NULL
);


--
-- Name: dataelementuseraccesses; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.dataelementuseraccesses (
    dataelementid integer NOT NULL,
    useraccessid integer NOT NULL
);


--
-- Name: dataelementusergroupaccesses; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.dataelementusergroupaccesses (
    dataelementid integer NOT NULL,
    usergroupaccessid integer NOT NULL
);


--
-- Name: dataentryform; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.dataentryform (
    dataentryformid integer NOT NULL,
    uid character varying(11) NOT NULL,
    code character varying(50),
    created timestamp without time zone NOT NULL,
    lastupdated timestamp without time zone NOT NULL,
    lastupdatedby integer,
    name character varying(160) NOT NULL,
    style character varying(40),
    htmlcode text,
    format integer
);


--
-- Name: dataentryformtranslations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.dataentryformtranslations (
    dataentryformid integer NOT NULL,
    objecttranslationid integer NOT NULL
);


--
-- Name: datainputperiod; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.datainputperiod (
    datainputperiodid integer NOT NULL,
    periodid integer NOT NULL,
    openingdate timestamp without time zone,
    closingdate timestamp without time zone,
    datasetid integer
);


--
-- Name: dataset; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.dataset (
    datasetid integer NOT NULL,
    uid character varying(11) NOT NULL,
    code character varying(50),
    created timestamp without time zone NOT NULL,
    lastupdated timestamp without time zone NOT NULL,
    lastupdatedby integer,
    name character varying(230) NOT NULL,
    shortname character varying(50),
    description text,
    formname text,
    style jsonb,
    periodtypeid integer NOT NULL,
    categorycomboid integer NOT NULL,
    dataentryform integer,
    mobile boolean NOT NULL,
    version integer,
    expirydays integer,
    timelydays integer,
    notifycompletinguser boolean,
    workflowid integer,
    openfutureperiods integer,
    fieldcombinationrequired boolean,
    validcompleteonly boolean,
    novaluerequirescomment boolean,
    skipoffline boolean,
    dataelementdecoration boolean,
    renderastabs boolean,
    renderhorizontally boolean,
    compulsoryfieldscompleteonly boolean,
    userid integer,
    publicaccess character varying(8),
    notificationrecipients integer
);


--
-- Name: datasetattributevalues; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.datasetattributevalues (
    datasetid integer NOT NULL,
    attributevalueid integer NOT NULL
);


--
-- Name: datasetelement; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.datasetelement (
    datasetelementid integer NOT NULL,
    datasetid integer,
    dataelementid integer NOT NULL,
    categorycomboid integer
);


--
-- Name: datasetindicators; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.datasetindicators (
    datasetid integer NOT NULL,
    indicatorid integer NOT NULL
);


--
-- Name: datasetlegendsets; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.datasetlegendsets (
    datasetid integer NOT NULL,
    sort_order integer NOT NULL,
    legendsetid integer NOT NULL
);


--
-- Name: datasetnotification_datasets; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.datasetnotification_datasets (
    datasetnotificationtemplateid integer NOT NULL,
    datasetid integer NOT NULL
);


--
-- Name: datasetnotificationtemplate; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.datasetnotificationtemplate (
    datasetnotificationtemplateid integer NOT NULL,
    uid character varying(11) NOT NULL,
    code character varying(50),
    created timestamp without time zone NOT NULL,
    lastupdated timestamp without time zone NOT NULL,
    lastupdatedby integer,
    name character varying(230) NOT NULL,
    subjecttemplate character varying(100),
    messagetemplate text NOT NULL,
    relativescheduleddays integer,
    sendstrategy character varying(50),
    usergroupid integer,
    datasetnotificationtrigger character varying(255),
    notificationrecipienttype character varying(255)
);


--
-- Name: datasetnotificationtemplate_deliverychannel; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.datasetnotificationtemplate_deliverychannel (
    datasetnotificationtemplateid integer NOT NULL,
    deliverychannel character varying(255)
);


--
-- Name: datasetoperands; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.datasetoperands (
    datasetid integer NOT NULL,
    dataelementoperandid integer NOT NULL
);


--
-- Name: datasetsectiontranslations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.datasetsectiontranslations (
    sectionid integer NOT NULL,
    objecttranslationid integer NOT NULL
);


--
-- Name: datasetsource; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.datasetsource (
    datasetid integer NOT NULL,
    sourceid integer NOT NULL
);


--
-- Name: datasettranslations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.datasettranslations (
    datasetid integer NOT NULL,
    objecttranslationid integer NOT NULL
);


--
-- Name: datasetuseraccesses; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.datasetuseraccesses (
    datasetid integer NOT NULL,
    useraccessid integer NOT NULL
);


--
-- Name: datasetusergroupaccesses; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.datasetusergroupaccesses (
    datasetid integer NOT NULL,
    usergroupaccessid integer NOT NULL
);


--
-- Name: datastatistics; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.datastatistics (
    statisticsid integer NOT NULL,
    uid character varying(11) NOT NULL,
    code character varying(50),
    created timestamp without time zone NOT NULL,
    lastupdated timestamp without time zone NOT NULL,
    lastupdatedby integer,
    chartviews double precision,
    mapviews double precision,
    reporttableviews double precision,
    eventreportviews double precision,
    eventchartviews double precision,
    dashboardviews double precision,
    datasetreportviews double precision,
    active_users integer,
    totalviews double precision,
    charts double precision,
    maps double precision,
    reporttables double precision,
    eventreports double precision,
    eventcharts double precision,
    dashboards double precision,
    indicators double precision,
    datavalues double precision,
    users integer
);


--
-- Name: datastatisticsevent; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.datastatisticsevent (
    eventid integer NOT NULL,
    eventtype character varying,
    "timestamp" timestamp without time zone,
    username character varying(255),
    favoriteuid character varying(255)
);


--
-- Name: datavalue; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.datavalue (
    dataelementid integer NOT NULL,
    periodid integer NOT NULL,
    sourceid integer NOT NULL,
    categoryoptioncomboid integer NOT NULL,
    attributeoptioncomboid integer NOT NULL,
    value character varying(50000),
    storedby character varying(255),
    created timestamp without time zone NOT NULL,
    lastupdated timestamp without time zone NOT NULL,
    comment character varying(50000),
    followup boolean,
    deleted boolean NOT NULL
);


--
-- Name: datavalueaudit; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.datavalueaudit (
    datavalueauditid integer NOT NULL,
    dataelementid integer NOT NULL,
    periodid integer NOT NULL,
    organisationunitid integer NOT NULL,
    categoryoptioncomboid integer NOT NULL,
    attributeoptioncomboid integer NOT NULL,
    value character varying(50000),
    created timestamp without time zone,
    modifiedby character varying(100),
    audittype character varying(100) NOT NULL
);


--
-- Name: deletedobject; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.deletedobject (
    deletedobjectid integer NOT NULL,
    klass character varying(255) NOT NULL,
    uid character varying(255) NOT NULL,
    code character varying(255),
    deleted_at timestamp without time zone NOT NULL,
    deleted_by character varying(255)
);


--
-- Name: document; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.document (
    documentid integer NOT NULL,
    uid character varying(11) NOT NULL,
    code character varying(50),
    created timestamp without time zone NOT NULL,
    lastupdated timestamp without time zone NOT NULL,
    lastupdatedby integer,
    name character varying(230) NOT NULL,
    url text NOT NULL,
    fileresource integer,
    external boolean NOT NULL,
    contenttype character varying(255),
    attachment boolean,
    externalaccess boolean,
    userid integer,
    publicaccess character varying(8)
);


--
-- Name: documentattributevalues; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.documentattributevalues (
    documentid integer NOT NULL,
    attributevalueid integer NOT NULL
);


--
-- Name: documenttranslations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.documenttranslations (
    documentid integer NOT NULL,
    objecttranslationid integer NOT NULL
);


--
-- Name: documentuseraccesses; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.documentuseraccesses (
    documentid integer NOT NULL,
    useraccessid integer NOT NULL
);


--
-- Name: documentusergroupaccesses; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.documentusergroupaccesses (
    documentid integer NOT NULL,
    usergroupaccessid integer NOT NULL
);


--
-- Name: eventchart; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.eventchart (
    eventchartid integer NOT NULL,
    uid character varying(11) NOT NULL,
    code character varying(50),
    created timestamp without time zone NOT NULL,
    lastupdated timestamp without time zone NOT NULL,
    lastupdatedby integer,
    name character varying(230) NOT NULL,
    description text,
    relativeperiodsid integer,
    userorganisationunit boolean,
    userorganisationunitchildren boolean,
    userorganisationunitgrandchildren boolean,
    programid integer NOT NULL,
    programstageid integer,
    startdate timestamp without time zone,
    enddate timestamp without time zone,
    dataelementvaluedimensionid integer,
    attributevaluedimensionid integer,
    aggregationtype character varying(40),
    completedonly boolean,
    title character varying(255),
    subtitle character varying(255),
    hidetitle boolean,
    hidesubtitle boolean,
    type character varying(40) NOT NULL,
    showdata boolean,
    hideemptyrowitems character varying(40),
    hidenadata boolean,
    programstatus character varying(40),
    eventstatus character varying(40),
    percentstackedvalues boolean,
    cumulativevalues boolean,
    rangeaxismaxvalue double precision,
    rangeaxisminvalue double precision,
    rangeaxissteps integer,
    rangeaxisdecimals integer,
    outputtype character varying(30),
    collapsedatadimensions boolean,
    domainaxislabel character varying(255),
    rangeaxislabel character varying(255),
    hidelegend boolean,
    nospacebetweencolumns boolean,
    regressiontype character varying(40) NOT NULL,
    targetlinevalue double precision,
    targetlinelabel character varying(255),
    baselinevalue double precision,
    baselinelabel character varying(255),
    sortorder integer,
    externalaccess boolean,
    userid integer,
    publicaccess character varying(8),
    favorites jsonb
);


--
-- Name: eventchart_attributedimensions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.eventchart_attributedimensions (
    eventchartid integer NOT NULL,
    sort_order integer NOT NULL,
    trackedentityattributedimensionid integer NOT NULL
);


--
-- Name: eventchart_categorydimensions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.eventchart_categorydimensions (
    eventchartid integer NOT NULL,
    sort_order integer NOT NULL,
    categorydimensionid integer NOT NULL
);


--
-- Name: eventchart_categoryoptiongroupsetdimensions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.eventchart_categoryoptiongroupsetdimensions (
    eventchartid integer NOT NULL,
    sort_order integer NOT NULL,
    categoryoptiongroupsetdimensionid integer NOT NULL
);


--
-- Name: eventchart_columns; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.eventchart_columns (
    eventchartid integer NOT NULL,
    sort_order integer NOT NULL,
    dimension character varying(255)
);


--
-- Name: eventchart_dataelementdimensions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.eventchart_dataelementdimensions (
    eventchartid integer NOT NULL,
    sort_order integer NOT NULL,
    trackedentitydataelementdimensionid integer NOT NULL
);


--
-- Name: eventchart_filters; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.eventchart_filters (
    eventchartid integer NOT NULL,
    sort_order integer NOT NULL,
    dimension character varying(255)
);


--
-- Name: eventchart_itemorgunitgroups; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.eventchart_itemorgunitgroups (
    eventchartid integer NOT NULL,
    sort_order integer NOT NULL,
    orgunitgroupid integer NOT NULL
);


--
-- Name: eventchart_organisationunits; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.eventchart_organisationunits (
    eventchartid integer NOT NULL,
    sort_order integer NOT NULL,
    organisationunitid integer NOT NULL
);


--
-- Name: eventchart_orgunitgroupsetdimensions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.eventchart_orgunitgroupsetdimensions (
    eventchartid integer NOT NULL,
    sort_order integer NOT NULL,
    orgunitgroupsetdimensionid integer NOT NULL
);


--
-- Name: eventchart_orgunitlevels; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.eventchart_orgunitlevels (
    eventchartid integer NOT NULL,
    sort_order integer NOT NULL,
    orgunitlevel integer
);


--
-- Name: eventchart_periods; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.eventchart_periods (
    eventchartid integer NOT NULL,
    sort_order integer NOT NULL,
    periodid integer NOT NULL
);


--
-- Name: eventchart_programindicatordimensions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.eventchart_programindicatordimensions (
    eventchartid integer NOT NULL,
    sort_order integer NOT NULL,
    trackedentityprogramindicatordimensionid integer NOT NULL
);


--
-- Name: eventchart_rows; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.eventchart_rows (
    eventchartid integer NOT NULL,
    sort_order integer NOT NULL,
    dimension character varying(255)
);


--
-- Name: eventcharttranslations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.eventcharttranslations (
    eventchartid integer NOT NULL,
    objecttranslationid integer NOT NULL
);


--
-- Name: eventchartuseraccesses; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.eventchartuseraccesses (
    eventchartid integer NOT NULL,
    useraccessid integer NOT NULL
);


--
-- Name: eventchartusergroupaccesses; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.eventchartusergroupaccesses (
    eventchartid integer NOT NULL,
    usergroupaccessid integer NOT NULL
);


--
-- Name: eventreport; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.eventreport (
    eventreportid integer NOT NULL,
    uid character varying(11) NOT NULL,
    code character varying(50),
    created timestamp without time zone NOT NULL,
    lastupdated timestamp without time zone NOT NULL,
    lastupdatedby integer,
    name character varying(230) NOT NULL,
    description text,
    relativeperiodsid integer,
    userorganisationunit boolean,
    userorganisationunitchildren boolean,
    userorganisationunitgrandchildren boolean,
    programid integer NOT NULL,
    programstageid integer,
    startdate timestamp without time zone,
    enddate timestamp without time zone,
    dataelementvaluedimensionid integer,
    attributevaluedimensionid integer,
    aggregationtype character varying(40),
    completedonly boolean,
    title character varying(255),
    subtitle character varying(255),
    hidetitle boolean,
    hidesubtitle boolean,
    datatype character varying(40),
    rowtotals boolean,
    coltotals boolean,
    rowsubtotals boolean,
    colsubtotals boolean,
    hideemptyrows boolean,
    hidenadata boolean,
    showhierarchy boolean,
    outputtype character varying(30),
    collapsedatadimensions boolean,
    showdimensionlabels boolean,
    digitgroupseparator character varying(40),
    displaydensity character varying(40),
    fontsize character varying(40),
    programstatus character varying(40),
    eventstatus character varying(40),
    sortorder integer,
    toplimit integer,
    externalaccess boolean,
    userid integer,
    publicaccess character varying(8),
    favorites jsonb
);


--
-- Name: eventreport_attributedimensions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.eventreport_attributedimensions (
    eventreportid integer NOT NULL,
    sort_order integer NOT NULL,
    trackedentityattributedimensionid integer NOT NULL
);


--
-- Name: eventreport_categorydimensions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.eventreport_categorydimensions (
    eventreportid integer NOT NULL,
    sort_order integer NOT NULL,
    categorydimensionid integer NOT NULL
);


--
-- Name: eventreport_categoryoptiongroupsetdimensions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.eventreport_categoryoptiongroupsetdimensions (
    eventreportid integer NOT NULL,
    sort_order integer NOT NULL,
    categoryoptiongroupsetdimensionid integer NOT NULL
);


--
-- Name: eventreport_columns; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.eventreport_columns (
    eventreportid integer NOT NULL,
    sort_order integer NOT NULL,
    dimension character varying(255)
);


--
-- Name: eventreport_dataelementdimensions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.eventreport_dataelementdimensions (
    eventreportid integer NOT NULL,
    sort_order integer NOT NULL,
    trackedentitydataelementdimensionid integer NOT NULL
);


--
-- Name: eventreport_filters; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.eventreport_filters (
    eventreportid integer NOT NULL,
    sort_order integer NOT NULL,
    dimension character varying(255)
);


--
-- Name: eventreport_itemorgunitgroups; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.eventreport_itemorgunitgroups (
    eventreportid integer NOT NULL,
    sort_order integer NOT NULL,
    orgunitgroupid integer NOT NULL
);


--
-- Name: eventreport_organisationunits; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.eventreport_organisationunits (
    eventreportid integer NOT NULL,
    sort_order integer NOT NULL,
    organisationunitid integer NOT NULL
);


--
-- Name: eventreport_orgunitgroupsetdimensions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.eventreport_orgunitgroupsetdimensions (
    eventreportid integer NOT NULL,
    sort_order integer NOT NULL,
    orgunitgroupsetdimensionid integer NOT NULL
);


--
-- Name: eventreport_orgunitlevels; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.eventreport_orgunitlevels (
    eventreportid integer NOT NULL,
    sort_order integer NOT NULL,
    orgunitlevel integer
);


--
-- Name: eventreport_periods; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.eventreport_periods (
    eventreportid integer NOT NULL,
    sort_order integer NOT NULL,
    periodid integer NOT NULL
);


--
-- Name: eventreport_programindicatordimensions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.eventreport_programindicatordimensions (
    eventreportid integer NOT NULL,
    sort_order integer NOT NULL,
    trackedentityprogramindicatordimensionid integer NOT NULL
);


--
-- Name: eventreport_rows; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.eventreport_rows (
    eventreportid integer NOT NULL,
    sort_order integer NOT NULL,
    dimension character varying(255)
);


--
-- Name: eventreporttranslations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.eventreporttranslations (
    eventreportid integer NOT NULL,
    objecttranslationid integer NOT NULL
);


--
-- Name: eventreportuseraccesses; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.eventreportuseraccesses (
    eventreportid integer NOT NULL,
    useraccessid integer NOT NULL
);


--
-- Name: eventreportusergroupaccesses; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.eventreportusergroupaccesses (
    eventreportid integer NOT NULL,
    usergroupaccessid integer NOT NULL
);


--
-- Name: expression; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.expression (
    expressionid integer NOT NULL,
    description character varying(255),
    expression text,
    slidingwindow boolean,
    missingvaluestrategy character varying(100) NOT NULL
);


--
-- Name: externalfileresource; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.externalfileresource (
    externalfileresourceid integer NOT NULL,
    uid character varying(11) NOT NULL,
    code character varying(50),
    created timestamp without time zone NOT NULL,
    lastupdated timestamp without time zone NOT NULL,
    lastupdatedby integer,
    accesstoken character varying(255),
    expires timestamp without time zone,
    fileresourceid integer NOT NULL
);


--
-- Name: externalmaplayer; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.externalmaplayer (
    externalmaplayerid integer NOT NULL,
    uid character varying(11) NOT NULL,
    code character varying(50),
    created timestamp without time zone NOT NULL,
    lastupdated timestamp without time zone NOT NULL,
    lastupdatedby integer,
    name character varying(230) NOT NULL,
    attribution text,
    url text NOT NULL,
    legendseturl text,
    maplayerposition bytea NOT NULL,
    layers text,
    imageformat bytea NOT NULL,
    mapservice bytea NOT NULL,
    legendsetid integer,
    userid integer,
    publicaccess character varying(8)
);


--
-- Name: externalmaplayeruseraccesses; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.externalmaplayeruseraccesses (
    externalmaplayerid integer NOT NULL,
    useraccessid integer NOT NULL
);


--
-- Name: externalmaplayerusergroupaccesses; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.externalmaplayerusergroupaccesses (
    externalmaplayerid integer NOT NULL,
    usergroupaccessid integer NOT NULL
);


--
-- Name: externalnotificationlogentry; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.externalnotificationlogentry (
    externalnotificationlogentryid integer NOT NULL,
    uid character varying(11),
    created timestamp without time zone NOT NULL,
    lastupdated timestamp without time zone NOT NULL,
    lastsentat timestamp without time zone,
    retries integer,
    key text NOT NULL,
    templateuid text NOT NULL,
    allowmultiple boolean,
    triggerby character varying(255)
);


--
-- Name: fileresource; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.fileresource (
    fileresourceid integer NOT NULL,
    uid character varying(11) NOT NULL,
    code character varying(50),
    created timestamp without time zone NOT NULL,
    lastupdated timestamp without time zone NOT NULL,
    lastupdatedby integer,
    name character varying(230) NOT NULL,
    contenttype character varying(255) NOT NULL,
    contentlength bigint NOT NULL,
    contentmd5 character varying(32) NOT NULL,
    storagekey character varying(1024) NOT NULL,
    isassigned boolean NOT NULL,
    storagestatus character varying(40),
    domain character varying(40),
    userid integer
);


--
-- Name: hibernate_sequence; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.hibernate_sequence
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: i18nlocale; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.i18nlocale (
    i18nlocaleid integer NOT NULL,
    uid character varying(11) NOT NULL,
    code character varying(50),
    created timestamp without time zone NOT NULL,
    lastupdated timestamp without time zone NOT NULL,
    lastupdatedby integer,
    name character varying(250) NOT NULL,
    locale character varying(15) NOT NULL
);


--
-- Name: incomingsms; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.incomingsms (
    id integer NOT NULL,
    originator character varying(255) NOT NULL,
    encoding integer NOT NULL,
    sentdate timestamp without time zone NOT NULL,
    receiveddate timestamp without time zone NOT NULL,
    text character varying(255),
    gatewayid character varying(255) NOT NULL,
    status integer NOT NULL,
    parsed boolean,
    statusmessage character varying(255),
    userid integer
);


--
-- Name: indicator; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.indicator (
    indicatorid integer NOT NULL,
    uid character varying(11) NOT NULL,
    code character varying(50),
    created timestamp without time zone NOT NULL,
    lastupdated timestamp without time zone NOT NULL,
    lastupdatedby integer,
    name character varying(230) NOT NULL,
    shortname character varying(50) NOT NULL,
    description text,
    formname text,
    annualized boolean NOT NULL,
    decimals integer,
    indicatortypeid integer NOT NULL,
    numerator text NOT NULL,
    numeratordescription text,
    denominator text NOT NULL,
    denominatordescription text,
    url character varying(255),
    style jsonb,
    aggregateexportcategoryoptioncombo character varying(255),
    aggregateexportattributeoptioncombo character varying(255),
    userid integer,
    publicaccess character varying(8)
);


--
-- Name: indicatorattributevalues; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.indicatorattributevalues (
    indicatorid integer NOT NULL,
    attributevalueid integer NOT NULL
);


--
-- Name: indicatorgroup; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.indicatorgroup (
    indicatorgroupid integer NOT NULL,
    uid character varying(11) NOT NULL,
    code character varying(50),
    created timestamp without time zone NOT NULL,
    lastupdated timestamp without time zone NOT NULL,
    lastupdatedby integer,
    name character varying(230) NOT NULL,
    userid integer,
    publicaccess character varying(8)
);


--
-- Name: indicatorgroupattributevalues; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.indicatorgroupattributevalues (
    indicatorgroupid integer NOT NULL,
    attributevalueid integer NOT NULL
);


--
-- Name: indicatorgroupmembers; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.indicatorgroupmembers (
    indicatorgroupid integer NOT NULL,
    indicatorid integer NOT NULL
);


--
-- Name: indicatorgroupset; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.indicatorgroupset (
    indicatorgroupsetid integer NOT NULL,
    uid character varying(11) NOT NULL,
    code character varying(50),
    created timestamp without time zone NOT NULL,
    lastupdated timestamp without time zone NOT NULL,
    lastupdatedby integer,
    name character varying(230) NOT NULL,
    description text,
    compulsory boolean,
    userid integer,
    publicaccess character varying(8)
);


--
-- Name: indicatorgroupsetmembers; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.indicatorgroupsetmembers (
    indicatorgroupid integer NOT NULL,
    indicatorgroupsetid integer NOT NULL,
    sort_order integer NOT NULL
);


--
-- Name: indicatorgroupsettranslations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.indicatorgroupsettranslations (
    indicatorgroupsetid integer NOT NULL,
    objecttranslationid integer NOT NULL
);


--
-- Name: indicatorgroupsetuseraccesses; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.indicatorgroupsetuseraccesses (
    indicatorgroupsetid integer NOT NULL,
    useraccessid integer NOT NULL
);


--
-- Name: indicatorgroupsetusergroupaccesses; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.indicatorgroupsetusergroupaccesses (
    indicatorgroupsetid integer NOT NULL,
    usergroupaccessid integer NOT NULL
);


--
-- Name: indicatorgrouptranslations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.indicatorgrouptranslations (
    indicatorgroupid integer NOT NULL,
    objecttranslationid integer NOT NULL
);


--
-- Name: indicatorgroupuseraccesses; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.indicatorgroupuseraccesses (
    indicatorgroupid integer NOT NULL,
    useraccessid integer NOT NULL
);


--
-- Name: indicatorgroupusergroupaccesses; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.indicatorgroupusergroupaccesses (
    indicatorgroupid integer NOT NULL,
    usergroupaccessid integer NOT NULL
);


--
-- Name: indicatorlegendsets; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.indicatorlegendsets (
    indicatorid integer NOT NULL,
    sort_order integer NOT NULL,
    legendsetid integer NOT NULL
);


--
-- Name: indicatortranslations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.indicatortranslations (
    indicatorid integer NOT NULL,
    objecttranslationid integer NOT NULL
);


--
-- Name: indicatortype; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.indicatortype (
    indicatortypeid integer NOT NULL,
    uid character varying(11) NOT NULL,
    code character varying(50),
    created timestamp without time zone NOT NULL,
    lastupdated timestamp without time zone NOT NULL,
    lastupdatedby integer,
    name character varying(230) NOT NULL,
    indicatorfactor integer NOT NULL,
    indicatornumber boolean
);


--
-- Name: indicatortypetranslations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.indicatortypetranslations (
    indicatortypeid integer NOT NULL,
    objecttranslationid integer NOT NULL
);


--
-- Name: indicatoruseraccesses; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.indicatoruseraccesses (
    indicatorid integer NOT NULL,
    useraccessid integer NOT NULL
);


--
-- Name: indicatorusergroupaccesses; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.indicatorusergroupaccesses (
    indicatorid integer NOT NULL,
    usergroupaccessid integer NOT NULL
);


--
-- Name: intepretation_likedby; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.intepretation_likedby (
    interpretationid integer NOT NULL,
    userid integer NOT NULL
);


--
-- Name: interpretation; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.interpretation (
    interpretationid integer NOT NULL,
    uid character varying(11) NOT NULL,
    lastupdated timestamp without time zone NOT NULL,
    reporttableid integer,
    chartid integer,
    mapid integer,
    eventreportid integer,
    eventchartid integer,
    datasetid integer,
    periodid integer,
    organisationunitid integer,
    interpretationtext text,
    created timestamp without time zone NOT NULL,
    likes integer,
    userid integer,
    publicaccess character varying(8)
);


--
-- Name: interpretation_comments; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.interpretation_comments (
    interpretationid integer NOT NULL,
    sort_order integer NOT NULL,
    interpretationcommentid integer NOT NULL
);


--
-- Name: interpretationcomment; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.interpretationcomment (
    interpretationcommentid integer NOT NULL,
    uid character varying(11),
    lastupdated timestamp without time zone NOT NULL,
    commenttext text,
    userid integer NOT NULL,
    created timestamp without time zone NOT NULL
);


--
-- Name: interpretationuseraccesses; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.interpretationuseraccesses (
    interpretationid integer NOT NULL,
    useraccessid integer NOT NULL
);


--
-- Name: interpretationusergroupaccesses; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.interpretationusergroupaccesses (
    interpretationid integer NOT NULL,
    usergroupaccessid integer NOT NULL
);


--
-- Name: jobconfiguration; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.jobconfiguration (
    jobconfigurationid integer NOT NULL,
    uid character varying(11) NOT NULL,
    code character varying(50),
    created timestamp without time zone NOT NULL,
    lastupdated timestamp without time zone NOT NULL,
    lastupdatedby integer,
    name character varying(230) NOT NULL,
    cronexpression character varying(255) NOT NULL,
    jobtype bytea NOT NULL,
    jobstatus bytea NOT NULL,
    lastexecutedstatus bytea,
    lastexecuted timestamp without time zone,
    lastruntimeexecution text,
    nextexecutiontime timestamp without time zone,
    continuousexecution boolean NOT NULL,
    enabled boolean NOT NULL,
    jobparameters bytea
);


--
-- Name: keyjsonvalue; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.keyjsonvalue (
    keyjsonvalueid integer NOT NULL,
    uid character varying(11) NOT NULL,
    code character varying(50),
    created timestamp without time zone NOT NULL,
    lastupdated timestamp without time zone NOT NULL,
    lastupdatedby integer,
    namespace character varying(255) NOT NULL,
    namespacekey character varying(255) NOT NULL,
    value text,
    encrypted_value character varying(255),
    encrypted boolean
);


--
-- Name: legendsetattributevalues; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.legendsetattributevalues (
    legendsetid integer NOT NULL,
    attributevalueid integer NOT NULL
);


--
-- Name: legendsetuseraccesses; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.legendsetuseraccesses (
    maplegendsetid integer NOT NULL,
    useraccessid integer NOT NULL
);


--
-- Name: legendsetusergroupaccesses; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.legendsetusergroupaccesses (
    maplegendsetid integer NOT NULL,
    usergroupaccessid integer NOT NULL
);


--
-- Name: lockexception; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.lockexception (
    lockexceptionid integer NOT NULL,
    organisationunitid integer,
    periodid integer,
    datasetid integer
);


--
-- Name: map; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.map (
    mapid integer NOT NULL,
    uid character varying(11) NOT NULL,
    code character varying(50),
    created timestamp without time zone NOT NULL,
    lastupdated timestamp without time zone NOT NULL,
    lastupdatedby integer,
    name character varying(230) NOT NULL,
    description text,
    longitude double precision,
    latitude double precision,
    zoom integer,
    basemap character varying(255),
    title character varying(255),
    externalaccess boolean,
    userid integer,
    publicaccess character varying(8),
    favorites jsonb
);


--
-- Name: maplegend; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.maplegend (
    maplegendid integer NOT NULL,
    uid character varying(11) NOT NULL,
    code character varying(50),
    created timestamp without time zone NOT NULL,
    lastupdated timestamp without time zone NOT NULL,
    lastupdatedby integer,
    name character varying(230) NOT NULL,
    startvalue double precision NOT NULL,
    endvalue double precision NOT NULL,
    color character varying(255),
    image character varying(255),
    maplegendsetid integer
);


--
-- Name: maplegendset; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.maplegendset (
    maplegendsetid integer NOT NULL,
    uid character varying(11) NOT NULL,
    code character varying(50),
    created timestamp without time zone NOT NULL,
    lastupdated timestamp without time zone NOT NULL,
    lastupdatedby integer,
    name character varying(230) NOT NULL,
    symbolizer character varying(255),
    userid integer,
    publicaccess character varying(8)
);


--
-- Name: maplegendsettranslations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.maplegendsettranslations (
    maplegendsetid integer NOT NULL,
    objecttranslationid integer NOT NULL
);


--
-- Name: maplegendtranslations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.maplegendtranslations (
    maplegendid integer NOT NULL,
    objecttranslationid integer NOT NULL
);


--
-- Name: mapmapviews; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.mapmapviews (
    mapid integer NOT NULL,
    sort_order integer NOT NULL,
    mapviewid integer NOT NULL
);


--
-- Name: mapuseraccesses; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.mapuseraccesses (
    mapid integer NOT NULL,
    useraccessid integer NOT NULL
);


--
-- Name: mapusergroupaccesses; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.mapusergroupaccesses (
    mapid integer NOT NULL,
    usergroupaccessid integer NOT NULL
);


--
-- Name: mapview; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.mapview (
    mapviewid integer NOT NULL,
    uid character varying(11) NOT NULL,
    code character varying(50),
    created timestamp without time zone NOT NULL,
    lastupdated timestamp without time zone NOT NULL,
    lastupdatedby integer,
    description text,
    layer character varying(255) NOT NULL,
    relativeperiodsid integer,
    userorganisationunit boolean,
    userorganisationunitchildren boolean,
    userorganisationunitgrandchildren boolean,
    aggregationtype character varying(40),
    programid integer,
    programstageid integer,
    startdate timestamp without time zone,
    enddate timestamp without time zone,
    method integer,
    classes integer,
    colorlow character varying(255),
    colorhigh character varying(255),
    colorscale character varying(255),
    legendsetid integer,
    radiuslow integer,
    radiushigh integer,
    opacity double precision,
    orgunitgroupsetid integer,
    arearadius integer,
    hidden boolean,
    labels boolean,
    labelfontsize character varying(255),
    labelfontweight character varying(255),
    labelfontstyle character varying(255),
    labelfontcolor character varying(255),
    eventclustering boolean,
    eventcoordinatefield character varying(255),
    eventpointcolor character varying(255),
    eventpointradius integer,
    config text,
    styledataitem jsonb
);


--
-- Name: mapview_attributedimensions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.mapview_attributedimensions (
    mapviewid integer NOT NULL,
    sort_order integer NOT NULL,
    trackedentityattributedimensionid integer NOT NULL
);


--
-- Name: mapview_columns; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.mapview_columns (
    mapviewid integer NOT NULL,
    sort_order integer NOT NULL,
    dimension character varying(255)
);


--
-- Name: mapview_datadimensionitems; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.mapview_datadimensionitems (
    mapviewid integer NOT NULL,
    sort_order integer NOT NULL,
    datadimensionitemid integer NOT NULL
);


--
-- Name: mapview_dataelementdimensions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.mapview_dataelementdimensions (
    mapviewid integer NOT NULL,
    sort_order integer NOT NULL,
    trackedentitydataelementdimensionid integer NOT NULL
);


--
-- Name: mapview_itemorgunitgroups; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.mapview_itemorgunitgroups (
    mapviewid integer NOT NULL,
    sort_order integer NOT NULL,
    orgunitgroupid integer NOT NULL
);


--
-- Name: mapview_organisationunits; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.mapview_organisationunits (
    mapviewid integer NOT NULL,
    sort_order integer NOT NULL,
    organisationunitid integer NOT NULL
);


--
-- Name: mapview_orgunitlevels; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.mapview_orgunitlevels (
    mapviewid integer NOT NULL,
    sort_order integer NOT NULL,
    orgunitlevel integer
);


--
-- Name: mapview_periods; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.mapview_periods (
    mapviewid integer NOT NULL,
    sort_order integer NOT NULL,
    periodid integer NOT NULL
);


--
-- Name: mapviewtranslations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.mapviewtranslations (
    mapviewid integer NOT NULL,
    objecttranslationid integer NOT NULL
);


--
-- Name: message; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.message (
    messageid integer NOT NULL,
    uid character varying(11),
    created timestamp without time zone NOT NULL,
    lastupdated timestamp without time zone NOT NULL,
    messagetext text,
    internal boolean,
    metadata character varying(255),
    userid integer
);


--
-- Name: messageconversation; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.messageconversation (
    messageconversationid integer NOT NULL,
    uid character varying(11),
    messagecount integer,
    created timestamp without time zone NOT NULL,
    lastupdated timestamp without time zone NOT NULL,
    subject character varying(255) NOT NULL,
    messagetype character varying(255) NOT NULL,
    priority character varying(255),
    status character varying(255),
    user_assigned integer,
    lastsenderid integer,
    lastmessage timestamp without time zone,
    userid integer
);


--
-- Name: messageconversation_messages; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.messageconversation_messages (
    messageconversationid integer NOT NULL,
    sort_order integer NOT NULL,
    messageid integer NOT NULL
);


--
-- Name: messageconversation_usermessages; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.messageconversation_usermessages (
    messageconversationid integer NOT NULL,
    usermessageid integer NOT NULL
);


--
-- Name: metadataaudit; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.metadataaudit (
    metadataauditid integer NOT NULL,
    created_at timestamp without time zone NOT NULL,
    created_by character varying(255) NOT NULL,
    klass character varying(255) NOT NULL,
    uid character varying(255) NOT NULL,
    code character varying(255),
    type character varying(50) NOT NULL,
    value text
);


--
-- Name: metadataversion; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.metadataversion (
    versionid integer NOT NULL,
    uid character varying(11) NOT NULL,
    code character varying(50),
    created timestamp without time zone NOT NULL,
    lastupdated timestamp without time zone NOT NULL,
    lastupdatedby integer,
    name character varying(230) NOT NULL,
    versiontype character varying(50),
    importdate timestamp without time zone,
    hashcode character varying(50) NOT NULL
);


--
-- Name: minmaxdataelement; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.minmaxdataelement (
    minmaxdataelementid integer NOT NULL,
    sourceid integer,
    dataelementid integer,
    categoryoptioncomboid integer,
    minimumvalue integer NOT NULL,
    maximumvalue integer NOT NULL,
    generatedvalue boolean NOT NULL
);


--
-- Name: oauth2client; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.oauth2client (
    oauth2clientid integer NOT NULL,
    uid character varying(11) NOT NULL,
    code character varying(50),
    created timestamp without time zone NOT NULL,
    lastupdated timestamp without time zone NOT NULL,
    lastupdatedby integer,
    name character varying(230) NOT NULL,
    cid character varying(230) NOT NULL,
    secret character varying(512) NOT NULL
);


--
-- Name: oauth2clientgranttypes; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.oauth2clientgranttypes (
    oauth2clientid integer NOT NULL,
    sort_order integer NOT NULL,
    granttype character varying(255)
);


--
-- Name: oauth2clientredirecturis; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.oauth2clientredirecturis (
    oauth2clientid integer NOT NULL,
    sort_order integer NOT NULL,
    redirecturi character varying(255)
);


--
-- Name: oauth_access_token; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.oauth_access_token (
    token_id character varying(256),
    token bytea,
    authentication_id character varying(256) NOT NULL,
    user_name character varying(256),
    client_id character varying(256),
    authentication bytea,
    refresh_token character varying(256)
);


--
-- Name: oauth_code; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.oauth_code (
    code character varying(256),
    authentication bytea
);


--
-- Name: oauth_refresh_token; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.oauth_refresh_token (
    token_id character varying(256),
    token bytea,
    authentication bytea
);


--
-- Name: objecttranslation; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.objecttranslation (
    objecttranslationid integer NOT NULL,
    locale character varying(15) NOT NULL,
    property character varying(50) NOT NULL,
    value text NOT NULL
);


--
-- Name: optionattributevalues; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.optionattributevalues (
    optionvalueid integer NOT NULL,
    attributevalueid integer NOT NULL
);


--
-- Name: optiongroup; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.optiongroup (
    optiongroupid integer NOT NULL,
    uid character varying(11) NOT NULL,
    code character varying(50),
    created timestamp without time zone NOT NULL,
    lastupdated timestamp without time zone NOT NULL,
    lastupdatedby integer,
    name character varying(230) NOT NULL,
    shortname character varying(50) NOT NULL,
    userid integer,
    publicaccess character varying(8)
);


--
-- Name: optiongroupattributevalues; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.optiongroupattributevalues (
    optiongroupid integer NOT NULL,
    attributevalueid integer NOT NULL
);


--
-- Name: optiongroupmembers; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.optiongroupmembers (
    optiongroupid integer NOT NULL,
    optionid integer NOT NULL
);


--
-- Name: optiongroupset; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.optiongroupset (
    optiongroupsetid integer NOT NULL,
    uid character varying(11) NOT NULL,
    code character varying(50),
    created timestamp without time zone NOT NULL,
    lastupdated timestamp without time zone NOT NULL,
    lastupdatedby integer,
    name character varying(230) NOT NULL,
    description text,
    datadimension boolean NOT NULL,
    optionsetid integer,
    userid integer,
    publicaccess character varying(8)
);


--
-- Name: optiongroupsetmembers; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.optiongroupsetmembers (
    optiongroupsetid integer NOT NULL,
    sort_order integer NOT NULL,
    optiongroupid integer NOT NULL
);


--
-- Name: optiongroupsettranslations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.optiongroupsettranslations (
    optiongroupsetid integer NOT NULL,
    objecttranslationid integer NOT NULL
);


--
-- Name: optiongroupsetuseraccesses; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.optiongroupsetuseraccesses (
    optiongroupsetid integer NOT NULL,
    useraccessid integer NOT NULL
);


--
-- Name: optiongroupsetusergroupaccesses; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.optiongroupsetusergroupaccesses (
    optiongroupsetid integer NOT NULL,
    usergroupaccessid integer NOT NULL
);


--
-- Name: optiongrouptranslations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.optiongrouptranslations (
    optiongroupid integer NOT NULL,
    objecttranslationid integer NOT NULL
);


--
-- Name: optiongroupuseraccesses; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.optiongroupuseraccesses (
    optiongroupid integer NOT NULL,
    useraccessid integer NOT NULL
);


--
-- Name: optiongroupusergroupaccesses; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.optiongroupusergroupaccesses (
    optiongroupid integer NOT NULL,
    usergroupaccessid integer NOT NULL
);


--
-- Name: optionset; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.optionset (
    optionsetid integer NOT NULL,
    uid character varying(11) NOT NULL,
    code character varying(50),
    created timestamp without time zone NOT NULL,
    lastupdated timestamp without time zone NOT NULL,
    lastupdatedby integer,
    name character varying(230) NOT NULL,
    valuetype character varying(50) NOT NULL,
    version integer,
    userid integer,
    publicaccess character varying(8)
);


--
-- Name: optionsetattributevalues; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.optionsetattributevalues (
    optionsetid integer NOT NULL,
    attributevalueid integer NOT NULL
);


--
-- Name: optionsettranslations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.optionsettranslations (
    optionsetid integer NOT NULL,
    objecttranslationid integer NOT NULL
);


--
-- Name: optionsetuseraccesses; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.optionsetuseraccesses (
    optionsetid integer NOT NULL,
    useraccessid integer NOT NULL
);


--
-- Name: optionsetusergroupaccesses; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.optionsetusergroupaccesses (
    optionsetid integer NOT NULL,
    usergroupaccessid integer NOT NULL
);


--
-- Name: optionvalue; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.optionvalue (
    optionvalueid integer NOT NULL,
    uid character varying(11) NOT NULL,
    code character varying(230) NOT NULL,
    name character varying(230) NOT NULL,
    created timestamp without time zone NOT NULL,
    lastupdated timestamp without time zone NOT NULL,
    sort_order integer,
    description text,
    formname text,
    style jsonb,
    optionsetid integer
);


--
-- Name: optionvaluetranslations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.optionvaluetranslations (
    optionvalueid integer NOT NULL,
    objecttranslationid integer NOT NULL
);


--
-- Name: organisationunit; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.organisationunit (
    organisationunitid integer NOT NULL,
    uid character varying(11) NOT NULL,
    code character varying(50),
    created timestamp without time zone NOT NULL,
    lastupdated timestamp without time zone NOT NULL,
    lastupdatedby integer,
    name character varying(230) NOT NULL,
    shortname character varying(50) NOT NULL,
    parentid integer,
    path character varying(255),
    hierarchylevel integer,
    description text,
    openingdate date NOT NULL,
    closeddate date,
    comment text,
    featuretype character varying(50),
    coordinates text,
    url character varying(255),
    contactperson character varying(255),
    address character varying(255),
    email character varying(150),
    phonenumber character varying(150),
    userid integer
);


--
-- Name: organisationunitattributevalues; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.organisationunitattributevalues (
    organisationunitid integer NOT NULL,
    attributevalueid integer NOT NULL
);


--
-- Name: organisationunittranslations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.organisationunittranslations (
    organisationunitid integer NOT NULL,
    objecttranslationid integer NOT NULL
);


--
-- Name: orgunitgroup; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.orgunitgroup (
    orgunitgroupid integer NOT NULL,
    uid character varying(11) NOT NULL,
    code character varying(50),
    created timestamp without time zone NOT NULL,
    lastupdated timestamp without time zone NOT NULL,
    lastupdatedby integer,
    name character varying(230) NOT NULL,
    shortname character varying(50),
    symbol character varying(255),
    color character varying(255),
    coordinates text,
    userid integer,
    publicaccess character varying(8)
);


--
-- Name: orgunitgroupattributevalues; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.orgunitgroupattributevalues (
    orgunitgroupid integer NOT NULL,
    attributevalueid integer NOT NULL
);


--
-- Name: orgunitgroupmembers; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.orgunitgroupmembers (
    organisationunitid integer NOT NULL,
    orgunitgroupid integer NOT NULL
);


--
-- Name: orgunitgroupset; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.orgunitgroupset (
    orgunitgroupsetid integer NOT NULL,
    uid character varying(11) NOT NULL,
    code character varying(50),
    created timestamp without time zone NOT NULL,
    lastupdated timestamp without time zone NOT NULL,
    lastupdatedby integer,
    name character varying(230) NOT NULL,
    description text,
    compulsory boolean NOT NULL,
    includesubhierarchyinanalytics boolean,
    datadimension boolean NOT NULL,
    userid integer,
    publicaccess character varying(8)
);


--
-- Name: orgunitgroupsetattributevalues; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.orgunitgroupsetattributevalues (
    orgunitgroupsetid integer NOT NULL,
    attributevalueid integer NOT NULL
);


--
-- Name: orgunitgroupsetdimension; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.orgunitgroupsetdimension (
    orgunitgroupsetdimensionid integer NOT NULL,
    orgunitgroupsetid integer
);


--
-- Name: orgunitgroupsetdimension_items; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.orgunitgroupsetdimension_items (
    orgunitgroupsetdimensionid integer NOT NULL,
    sort_order integer NOT NULL,
    orgunitgroupid integer NOT NULL
);


--
-- Name: orgunitgroupsetmembers; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.orgunitgroupsetmembers (
    orgunitgroupsetid integer NOT NULL,
    orgunitgroupid integer NOT NULL
);


--
-- Name: orgunitgroupsettranslations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.orgunitgroupsettranslations (
    orgunitgroupsetid integer NOT NULL,
    objecttranslationid integer NOT NULL
);


--
-- Name: orgunitgroupsetuseraccesses; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.orgunitgroupsetuseraccesses (
    orgunitgroupsetid integer NOT NULL,
    useraccessid integer NOT NULL
);


--
-- Name: orgunitgroupsetusergroupaccesses; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.orgunitgroupsetusergroupaccesses (
    orgunitgroupsetid integer NOT NULL,
    usergroupaccessid integer NOT NULL
);


--
-- Name: orgunitgrouptranslations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.orgunitgrouptranslations (
    orgunitgroupid integer NOT NULL,
    objecttranslationid integer NOT NULL
);


--
-- Name: orgunitgroupuseraccesses; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.orgunitgroupuseraccesses (
    orgunitgroupid integer NOT NULL,
    useraccessid integer NOT NULL
);


--
-- Name: orgunitgroupusergroupaccesses; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.orgunitgroupusergroupaccesses (
    orgunitgroupid integer NOT NULL,
    usergroupaccessid integer NOT NULL
);


--
-- Name: orgunitlevel; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.orgunitlevel (
    orgunitlevelid integer NOT NULL,
    uid character varying(11) NOT NULL,
    code character varying(50),
    created timestamp without time zone NOT NULL,
    lastupdated timestamp without time zone NOT NULL,
    lastupdatedby integer,
    name character varying(230) NOT NULL,
    level integer NOT NULL,
    offlinelevels integer
);


--
-- Name: orgunitleveltranslations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.orgunitleveltranslations (
    orgunitlevelid integer NOT NULL,
    objecttranslationid integer NOT NULL
);


--
-- Name: outbound_sms; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.outbound_sms (
    id integer NOT NULL,
    date timestamp without time zone NOT NULL,
    message character varying(500),
    status integer NOT NULL,
    sender character varying(255)
);


--
-- Name: outbound_sms_recipients; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.outbound_sms_recipients (
    outbound_sms_id integer NOT NULL,
    elt text
);


--
-- Name: period; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.period (
    periodid integer NOT NULL,
    periodtypeid integer,
    startdate date NOT NULL,
    enddate date NOT NULL
);


--
-- Name: periodtype; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.periodtype (
    periodtypeid integer NOT NULL,
    name character varying(50) NOT NULL
);


--
-- Name: predictor; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.predictor (
    predictorid integer NOT NULL,
    uid character varying(11) NOT NULL,
    code character varying(50),
    created timestamp without time zone NOT NULL,
    lastupdated timestamp without time zone NOT NULL,
    lastupdatedby integer,
    name character varying(230) NOT NULL,
    description text,
    generatorexpressionid integer NOT NULL,
    generatoroutput integer NOT NULL,
    generatoroutputcombo integer,
    skiptestexpressionid integer,
    periodtypeid integer NOT NULL,
    sequentialsamplecount integer NOT NULL,
    annualsamplecount integer NOT NULL,
    sequentialskipcount integer
);


--
-- Name: predictororgunitlevels; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.predictororgunitlevels (
    predictorid integer NOT NULL,
    orgunitlevelid integer NOT NULL
);


--
-- Name: previouspasswords; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.previouspasswords (
    userid integer NOT NULL,
    list_index integer NOT NULL,
    previouspassword text
);


--
-- Name: program; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.program (
    programid integer NOT NULL,
    uid character varying(11) NOT NULL,
    code character varying(50),
    created timestamp without time zone NOT NULL,
    lastupdated timestamp without time zone NOT NULL,
    lastupdatedby integer,
    name character varying(230) NOT NULL,
    shortname character varying(50) NOT NULL,
    description text,
    formname text,
    version integer,
    enrollmentdatelabel text,
    incidentdatelabel text,
    type character varying(255) NOT NULL,
    displayincidentdate boolean,
    onlyenrollonce boolean,
    skipoffline boolean NOT NULL,
    displayfrontpagelist boolean,
    usefirststageduringregistration boolean,
    capturecoordinates boolean,
    expirydays integer,
    completeeventsexpirydays integer,
    minattributesrequiredtosearch integer,
    maxteicounttoreturn integer,
    style jsonb,
    expiryperiodtypeid integer,
    ignoreoverdueevents boolean,
    selectenrollmentdatesinfuture boolean,
    selectincidentdatesinfuture boolean,
    relationshiptext character varying(255),
    relationshiptypeid integer,
    relationshipfroma boolean,
    relatedprogramid integer,
    categorycomboid integer NOT NULL,
    trackedentitytypeid integer,
    dataentryformid integer,
    workflowid integer,
    userid integer,
    publicaccess character varying(8)
);


--
-- Name: program_attribute_group; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.program_attribute_group (
    programtrackedentityattributegroupid integer NOT NULL,
    uid character varying(11) NOT NULL,
    code character varying(50),
    created timestamp without time zone NOT NULL,
    lastupdated timestamp without time zone NOT NULL,
    lastupdatedby integer,
    name character varying(230) NOT NULL,
    shortname character varying(255),
    description text,
    uniqunessype bytea NOT NULL
);


--
-- Name: program_attributes; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.program_attributes (
    programtrackedentityattributeid integer NOT NULL,
    uid character varying(11) NOT NULL,
    code character varying(50),
    created timestamp without time zone NOT NULL,
    lastupdated timestamp without time zone NOT NULL,
    lastupdatedby integer,
    programid integer,
    trackedentityattributeid integer,
    displayinlist boolean,
    mandatory boolean,
    sort_order integer,
    allowfuturedate boolean,
    renderoptionsasradio boolean,
    rendertype jsonb,
    searchable boolean
);


--
-- Name: program_criteria; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.program_criteria (
    programid integer NOT NULL,
    validationcriteriaid integer NOT NULL
);


--
-- Name: program_organisationunits; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.program_organisationunits (
    organisationunitid integer NOT NULL,
    programid integer NOT NULL
);


--
-- Name: program_userroles; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.program_userroles (
    programid integer,
    userroleid integer NOT NULL
);


--
-- Name: programattributevalues; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.programattributevalues (
    programid integer NOT NULL,
    attributevalueid integer NOT NULL
);


--
-- Name: programexpression; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.programexpression (
    programexpressionid integer NOT NULL,
    description character varying(255),
    expression text
);


--
-- Name: programindicator; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.programindicator (
    programindicatorid integer NOT NULL,
    uid character varying(11) NOT NULL,
    code character varying(50),
    created timestamp without time zone NOT NULL,
    lastupdated timestamp without time zone NOT NULL,
    lastupdatedby integer,
    name character varying(230) NOT NULL,
    shortname character varying(50) NOT NULL,
    description text,
    formname text,
    style jsonb,
    programid integer NOT NULL,
    expression text,
    filter text,
    aggregationtype character varying(40),
    decimals integer,
    aggregateexportcategoryoptioncombo character varying(255),
    aggregateexportattributeoptioncombo character varying(255),
    displayinform boolean,
    analyticstype character varying(15) NOT NULL,
    userid integer,
    publicaccess character varying(8)
);


--
-- Name: programindicatorattributevalues; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.programindicatorattributevalues (
    programindicatorid integer NOT NULL,
    attributevalueid integer NOT NULL
);


--
-- Name: programindicatorgroup; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.programindicatorgroup (
    programindicatorgroupid integer NOT NULL,
    uid character varying(11) NOT NULL,
    code character varying(50),
    created timestamp without time zone NOT NULL,
    lastupdated timestamp without time zone NOT NULL,
    lastupdatedby integer,
    name character varying(230) NOT NULL,
    description text,
    userid integer,
    publicaccess character varying(8)
);


--
-- Name: programindicatorgroupattributevalues; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.programindicatorgroupattributevalues (
    programindicatorgroupid integer NOT NULL,
    attributevalueid integer NOT NULL
);


--
-- Name: programindicatorgroupmembers; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.programindicatorgroupmembers (
    programindicatorgroupid integer NOT NULL,
    programindicatorid integer NOT NULL
);


--
-- Name: programindicatorgrouptranslations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.programindicatorgrouptranslations (
    programindicatorgroupid integer NOT NULL,
    objecttranslationid integer NOT NULL
);


--
-- Name: programindicatorgroupuseraccesses; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.programindicatorgroupuseraccesses (
    programindicatorgroupid integer NOT NULL,
    useraccessid integer NOT NULL
);


--
-- Name: programindicatorgroupusergroupaccesses; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.programindicatorgroupusergroupaccesses (
    programindicatorgroupid integer NOT NULL,
    usergroupaccessid integer NOT NULL
);


--
-- Name: programindicatorlegendsets; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.programindicatorlegendsets (
    programindicatorid integer NOT NULL,
    sort_order integer NOT NULL,
    legendsetid integer NOT NULL
);


--
-- Name: programindicatortranslations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.programindicatortranslations (
    programindicatorid integer NOT NULL,
    objecttranslationid integer NOT NULL
);


--
-- Name: programindicatoruseraccesses; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.programindicatoruseraccesses (
    programindicatorid integer NOT NULL,
    useraccessid integer NOT NULL
);


--
-- Name: programindicatorusergroupaccesses; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.programindicatorusergroupaccesses (
    programindicatorid integer NOT NULL,
    usergroupaccessid integer NOT NULL
);


--
-- Name: programinstance; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.programinstance (
    programinstanceid integer NOT NULL,
    uid character varying(11),
    created timestamp without time zone NOT NULL,
    lastupdated timestamp without time zone NOT NULL,
    createdatclient timestamp without time zone,
    lastupdatedatclient timestamp without time zone,
    incidentdate timestamp without time zone,
    enrollmentdate timestamp without time zone NOT NULL,
    enddate timestamp without time zone,
    followup boolean,
    completedby character varying(255),
    longitude double precision,
    latitude double precision,
    deleted boolean NOT NULL,
    storedby character varying(255),
    status character varying(50),
    trackedentityinstanceid integer,
    programid integer NOT NULL,
    organisationunitid integer
);


--
-- Name: programinstance_messageconversation; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.programinstance_messageconversation (
    programinstanceid integer NOT NULL,
    sort_order integer NOT NULL,
    messageconversationid integer NOT NULL
);


--
-- Name: programinstancecomments; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.programinstancecomments (
    programinstanceid integer NOT NULL,
    sort_order integer NOT NULL,
    trackedentitycommentid integer NOT NULL
);


--
-- Name: programmessage; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.programmessage (
    id integer NOT NULL,
    uid character varying(11) NOT NULL,
    code character varying(50),
    created timestamp without time zone NOT NULL,
    lastupdated timestamp without time zone NOT NULL,
    lastupdatedby integer,
    text character varying(500) NOT NULL,
    subject character varying(200),
    processeddate timestamp without time zone,
    messagestatus character varying(50),
    trackedentityinstanceid integer,
    organisationunitid integer,
    programinstanceid integer,
    programstageinstanceid integer
);


--
-- Name: programmessage_deliverychannels; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.programmessage_deliverychannels (
    programmessagedeliverychannelsid integer NOT NULL,
    deliverychannel character varying(255)
);


--
-- Name: programmessage_emailaddresses; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.programmessage_emailaddresses (
    programmessageemailaddressid integer NOT NULL,
    email text
);


--
-- Name: programmessage_phonenumbers; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.programmessage_phonenumbers (
    programmessagephonenumberid integer NOT NULL,
    phonenumber text
);


--
-- Name: programmessagetranslations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.programmessagetranslations (
    id integer NOT NULL,
    objecttranslationid integer NOT NULL
);


--
-- Name: programnotificationtemplate; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.programnotificationtemplate (
    programnotificationtemplateid integer NOT NULL,
    uid character varying(11) NOT NULL,
    code character varying(50),
    created timestamp without time zone NOT NULL,
    lastupdated timestamp without time zone NOT NULL,
    lastupdatedby integer,
    name character varying(230) NOT NULL,
    relativescheduleddays integer,
    usergroupid integer,
    trackedentityattributeid integer,
    dataelementid integer,
    subjecttemplate character varying(100),
    messagetemplate text NOT NULL,
    notificationtrigger character varying(255),
    notificationrecipienttype character varying(255),
    programstageid integer,
    programid integer
);


--
-- Name: programnotificationtemplate_deliverychannel; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.programnotificationtemplate_deliverychannel (
    programnotificationtemplatedeliverychannelid integer NOT NULL,
    deliverychannel character varying(255)
);


--
-- Name: programrule; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.programrule (
    programruleid integer NOT NULL,
    uid character varying(11) NOT NULL,
    code character varying(50),
    created timestamp without time zone NOT NULL,
    lastupdated timestamp without time zone NOT NULL,
    lastupdatedby integer,
    name character varying(230) NOT NULL,
    description character varying(255),
    programid integer NOT NULL,
    programstageid integer,
    rulecondition text,
    priority integer
);


--
-- Name: programruleaction; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.programruleaction (
    programruleactionid integer NOT NULL,
    uid character varying(11) NOT NULL,
    code character varying(50),
    created timestamp without time zone NOT NULL,
    lastupdated timestamp without time zone NOT NULL,
    lastupdatedby integer,
    programruleid integer,
    actiontype character varying(255) NOT NULL,
    dataelementid integer,
    trackedentityattributeid integer,
    programindicatorid integer,
    programstagesectionid integer,
    programstageid integer,
    programnotificationtemplateid integer,
    location character varying(255),
    content text,
    data text
);


--
-- Name: programruletranslations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.programruletranslations (
    programruleid integer NOT NULL,
    objecttranslationid integer NOT NULL
);


--
-- Name: programrulevariable; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.programrulevariable (
    programrulevariableid integer NOT NULL,
    uid character varying(11) NOT NULL,
    code character varying(50),
    created timestamp without time zone NOT NULL,
    lastupdated timestamp without time zone NOT NULL,
    lastupdatedby integer,
    name character varying(230) NOT NULL,
    programid integer NOT NULL,
    sourcetype character varying(255) NOT NULL,
    trackedentityattributeid integer,
    dataelementid integer,
    usecodeforoptionset boolean,
    programstageid integer
);


--
-- Name: programsection; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.programsection (
    programsectionid integer NOT NULL,
    uid character varying(11) NOT NULL,
    code character varying(50),
    created timestamp without time zone NOT NULL,
    lastupdated timestamp without time zone NOT NULL,
    lastupdatedby integer,
    name character varying(230) NOT NULL,
    description text,
    formname text,
    style jsonb,
    rendertype jsonb,
    programid integer,
    sortorder integer NOT NULL
);


--
-- Name: programsection_attributes; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.programsection_attributes (
    programsectionid integer NOT NULL,
    sort_order integer NOT NULL,
    trackedentityattributeid integer NOT NULL
);


--
-- Name: programsectiontranslations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.programsectiontranslations (
    programsectionid integer NOT NULL,
    objecttranslationid integer NOT NULL
);


--
-- Name: programstage; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.programstage (
    programstageid integer NOT NULL,
    uid character varying(11) NOT NULL,
    code character varying(50),
    created timestamp without time zone NOT NULL,
    lastupdated timestamp without time zone NOT NULL,
    lastupdatedby integer,
    name character varying(230),
    description text,
    formname text,
    mindaysfromstart integer NOT NULL,
    programid integer,
    repeatable boolean NOT NULL,
    dataentryformid integer,
    standardinterval integer,
    executiondatelabel character varying(255),
    duedatelabel character varying(255),
    autogenerateevent boolean,
    validcompleteonly boolean,
    displaygenerateeventbox boolean,
    capturecoordinates boolean,
    generatedbyenrollmentdate boolean,
    blockentryform boolean,
    remindcompleted boolean,
    allowgeneratenextvisit boolean,
    openafterenrollment boolean,
    reportdatetouse character varying(255),
    pregenerateuid boolean,
    style jsonb,
    hideduedate boolean,
    sort_order integer,
    periodtypeid integer,
    userid integer,
    publicaccess character varying(8)
);


--
-- Name: programstageattributevalues; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.programstageattributevalues (
    programstageid integer NOT NULL,
    attributevalueid integer NOT NULL
);


--
-- Name: programstagedataelement; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.programstagedataelement (
    programstagedataelementid integer NOT NULL,
    uid character varying(11) NOT NULL,
    code character varying(50),
    created timestamp without time zone NOT NULL,
    lastupdated timestamp without time zone NOT NULL,
    lastupdatedby integer,
    programstageid integer,
    dataelementid integer,
    compulsory boolean NOT NULL,
    allowprovidedelsewhere boolean,
    sort_order integer,
    displayinreports boolean,
    allowfuturedate boolean,
    renderoptionsasradio boolean,
    rendertype jsonb
);


--
-- Name: programstageinstance; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.programstageinstance (
    programstageinstanceid integer NOT NULL,
    uid character varying(11),
    code character varying(50),
    created timestamp without time zone NOT NULL,
    lastupdated timestamp without time zone NOT NULL,
    createdatclient timestamp without time zone,
    lastupdatedatclient timestamp without time zone,
    programinstanceid integer NOT NULL,
    programstageid integer NOT NULL,
    attributeoptioncomboid integer,
    deleted boolean NOT NULL,
    storedby character varying(255),
    duedate timestamp without time zone,
    executiondate timestamp without time zone,
    organisationunitid integer,
    status character varying(25) NOT NULL,
    longitude double precision,
    latitude double precision,
    completedby character varying(255),
    completeddate timestamp without time zone
);


--
-- Name: programstageinstance_messageconversation; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.programstageinstance_messageconversation (
    programstageinstanceid integer NOT NULL,
    sort_order integer NOT NULL,
    messageconversationid integer NOT NULL
);


--
-- Name: programstageinstancecomments; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.programstageinstancecomments (
    programstageinstanceid integer NOT NULL,
    sort_order integer NOT NULL,
    trackedentitycommentid integer NOT NULL
);


--
-- Name: programstagesection; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.programstagesection (
    programstagesectionid integer NOT NULL,
    uid character varying(11) NOT NULL,
    code character varying(50),
    created timestamp without time zone NOT NULL,
    lastupdated timestamp without time zone NOT NULL,
    lastupdatedby integer,
    name character varying(230) NOT NULL,
    description text,
    formname text,
    style jsonb,
    rendertype jsonb,
    programstageid integer,
    sortorder integer NOT NULL
);


--
-- Name: programstagesection_dataelements; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.programstagesection_dataelements (
    programstagesectionid integer NOT NULL,
    sort_order integer NOT NULL,
    dataelementid integer NOT NULL
);


--
-- Name: programstagesection_programindicators; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.programstagesection_programindicators (
    programstagesectionid integer NOT NULL,
    sort_order integer NOT NULL,
    programindicatorid integer NOT NULL
);


--
-- Name: programstagesectiontranslations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.programstagesectiontranslations (
    programstagesectionid integer NOT NULL,
    objecttranslationid integer NOT NULL
);


--
-- Name: programstagetranslations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.programstagetranslations (
    programstageid integer NOT NULL,
    objecttranslationid integer NOT NULL
);


--
-- Name: programstageuseraccesses; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.programstageuseraccesses (
    programstageid integer NOT NULL,
    useraccessid integer NOT NULL
);


--
-- Name: programstageusergroupaccesses; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.programstageusergroupaccesses (
    programid integer NOT NULL,
    usergroupaccessid integer NOT NULL
);


--
-- Name: programtrackedentityattributegroupmembers; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.programtrackedentityattributegroupmembers (
    programtrackedentityattributegroupid integer NOT NULL,
    programtrackedentityattributeid integer NOT NULL
);


--
-- Name: programtrackedentityattributegrouptranslations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.programtrackedentityattributegrouptranslations (
    programtrackedentityattributegroupid integer NOT NULL,
    objecttranslationid integer NOT NULL
);


--
-- Name: programtranslations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.programtranslations (
    programid integer NOT NULL,
    objecttranslationid integer NOT NULL
);


--
-- Name: programuseraccesses; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.programuseraccesses (
    programid integer NOT NULL,
    useraccessid integer NOT NULL
);


--
-- Name: programusergroupaccesses; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.programusergroupaccesses (
    programid integer NOT NULL,
    usergroupaccessid integer NOT NULL
);


--
-- Name: pushanalysis; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.pushanalysis (
    pushanalysisid integer NOT NULL,
    uid character varying(11) NOT NULL,
    code character varying(50),
    created timestamp without time zone NOT NULL,
    lastupdated timestamp without time zone NOT NULL,
    lastupdatedby integer,
    name character varying(255) NOT NULL,
    title character varying(255),
    message text,
    enabled boolean NOT NULL,
    schedulingdayoffrequency integer,
    schedulingfrequency bytea,
    dashboard integer NOT NULL
);


--
-- Name: pushanalysisrecipientusergroups; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.pushanalysisrecipientusergroups (
    usergroupid integer NOT NULL,
    elt integer NOT NULL
);


--
-- Name: relationship; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.relationship (
    relationshipid integer NOT NULL,
    formname text,
    description text,
    style jsonb,
    trackedentityinstanceaid integer NOT NULL,
    relationshiptypeid integer NOT NULL,
    trackedentityinstancebid integer NOT NULL
);


--
-- Name: relationshiptype; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.relationshiptype (
    relationshiptypeid integer NOT NULL,
    uid character varying(11) NOT NULL,
    code character varying(50),
    created timestamp without time zone NOT NULL,
    lastupdated timestamp without time zone NOT NULL,
    lastupdatedby integer,
    name character varying(230) NOT NULL,
    a_is_to_b character varying(255) NOT NULL,
    b_is_to_a character varying(255) NOT NULL
);


--
-- Name: relationshiptypetranslations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.relationshiptypetranslations (
    relationshiptypeid integer NOT NULL,
    objecttranslationid integer NOT NULL
);


--
-- Name: relativeperiods; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.relativeperiods (
    relativeperiodsid integer NOT NULL,
    thisday boolean NOT NULL,
    yesterday boolean NOT NULL,
    last3days boolean NOT NULL,
    last7days boolean NOT NULL,
    last14days boolean NOT NULL,
    thismonth boolean NOT NULL,
    lastmonth boolean NOT NULL,
    thisbimonth boolean NOT NULL,
    lastbimonth boolean NOT NULL,
    thisquarter boolean NOT NULL,
    lastquarter boolean NOT NULL,
    thissixmonth boolean NOT NULL,
    lastsixmonth boolean NOT NULL,
    weeksthisyear boolean,
    monthsthisyear boolean NOT NULL,
    bimonthsthisyear boolean,
    quartersthisyear boolean NOT NULL,
    thisyear boolean NOT NULL,
    monthslastyear boolean NOT NULL,
    quarterslastyear boolean NOT NULL,
    lastyear boolean NOT NULL,
    last5years boolean NOT NULL,
    last12months boolean NOT NULL,
    last6months boolean NOT NULL,
    last3months boolean NOT NULL,
    last6bimonths boolean NOT NULL,
    last4quarters boolean NOT NULL,
    last2sixmonths boolean NOT NULL,
    thisfinancialyear boolean NOT NULL,
    lastfinancialyear boolean NOT NULL,
    last5financialyears boolean NOT NULL,
    thisweek boolean NOT NULL,
    lastweek boolean NOT NULL,
    thisbiweek boolean,
    lastbiweek boolean,
    last4weeks boolean NOT NULL,
    last4biweeks boolean,
    last12weeks boolean NOT NULL,
    last52weeks boolean NOT NULL
);


--
-- Name: report; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.report (
    reportid integer NOT NULL,
    uid character varying(11) NOT NULL,
    code character varying(50),
    created timestamp without time zone NOT NULL,
    lastupdated timestamp without time zone NOT NULL,
    lastupdatedby integer,
    name character varying(230) NOT NULL,
    type character varying(50),
    designcontent text,
    reporttableid integer,
    relativeperiodsid integer,
    paramreportingmonth boolean,
    paramorganisationunit boolean,
    cachestrategy character varying(40),
    externalaccess boolean,
    userid integer,
    publicaccess character varying(8)
);


--
-- Name: reporttable; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.reporttable (
    reporttableid integer NOT NULL,
    uid character varying(11) NOT NULL,
    code character varying(50),
    created timestamp without time zone NOT NULL,
    lastupdated timestamp without time zone NOT NULL,
    lastupdatedby integer,
    name character varying(230) NOT NULL,
    description text,
    measurecriteria character varying(255),
    regression boolean,
    cumulative boolean,
    relativeperiodsid integer,
    paramreportingmonth boolean,
    paramgrandparentorganisationunit boolean,
    paramparentorganisationunit boolean,
    paramorganisationunit boolean,
    sortorder integer,
    toplimit integer,
    rowtotals boolean,
    coltotals boolean,
    rowsubtotals boolean,
    colsubtotals boolean,
    hideemptyrows boolean,
    hideemptycolumns boolean,
    aggregationtype character varying(40),
    completedonly boolean,
    title character varying(255),
    subtitle character varying(255),
    hidetitle boolean,
    hidesubtitle boolean,
    digitgroupseparator character varying(40),
    displaydensity character varying(40),
    fontsize character varying(40),
    userorganisationunit boolean,
    userorganisationunitchildren boolean,
    userorganisationunitgrandchildren boolean,
    legendsetid integer,
    legenddisplaystyle character varying(40),
    legenddisplaystrategy character varying(40),
    numbertype character varying(40),
    showhierarchy boolean,
    showdimensionlabels boolean,
    skiprounding boolean,
    externalaccess boolean,
    userid integer,
    publicaccess character varying(8),
    favorites jsonb
);


--
-- Name: reporttable_categorydimensions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.reporttable_categorydimensions (
    reporttableid integer NOT NULL,
    sort_order integer NOT NULL,
    categorydimensionid integer NOT NULL
);


--
-- Name: reporttable_categoryoptiongroupsetdimensions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.reporttable_categoryoptiongroupsetdimensions (
    reporttableid integer NOT NULL,
    sort_order integer NOT NULL,
    categoryoptiongroupsetdimensionid integer NOT NULL
);


--
-- Name: reporttable_columns; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.reporttable_columns (
    reporttableid integer NOT NULL,
    sort_order integer NOT NULL,
    dimension character varying(255)
);


--
-- Name: reporttable_datadimensionitems; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.reporttable_datadimensionitems (
    reporttableid integer NOT NULL,
    sort_order integer NOT NULL,
    datadimensionitemid integer NOT NULL
);


--
-- Name: reporttable_dataelementgroupsetdimensions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.reporttable_dataelementgroupsetdimensions (
    reporttableid integer NOT NULL,
    sort_order integer NOT NULL,
    dataelementgroupsetdimensionid integer NOT NULL
);


--
-- Name: reporttable_filters; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.reporttable_filters (
    reporttableid integer NOT NULL,
    sort_order integer NOT NULL,
    dimension character varying(255)
);


--
-- Name: reporttable_itemorgunitgroups; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.reporttable_itemorgunitgroups (
    reporttableid integer NOT NULL,
    sort_order integer NOT NULL,
    orgunitgroupid integer NOT NULL
);


--
-- Name: reporttable_organisationunits; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.reporttable_organisationunits (
    reporttableid integer NOT NULL,
    sort_order integer NOT NULL,
    organisationunitid integer NOT NULL
);


--
-- Name: reporttable_orgunitgroupsetdimensions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.reporttable_orgunitgroupsetdimensions (
    reporttableid integer NOT NULL,
    sort_order integer NOT NULL,
    orgunitgroupsetdimensionid integer NOT NULL
);


--
-- Name: reporttable_orgunitlevels; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.reporttable_orgunitlevels (
    reporttableid integer NOT NULL,
    sort_order integer NOT NULL,
    orgunitlevel integer
);


--
-- Name: reporttable_periods; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.reporttable_periods (
    reporttableid integer NOT NULL,
    sort_order integer NOT NULL,
    periodid integer NOT NULL
);


--
-- Name: reporttable_rows; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.reporttable_rows (
    reporttableid integer NOT NULL,
    sort_order integer NOT NULL,
    dimension character varying(255)
);


--
-- Name: reporttabletranslations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.reporttabletranslations (
    reporttableid integer NOT NULL,
    objecttranslationid integer NOT NULL
);


--
-- Name: reporttableuseraccesses; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.reporttableuseraccesses (
    reporttableid integer NOT NULL,
    useraccessid integer NOT NULL
);


--
-- Name: reporttableusergroupaccesses; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.reporttableusergroupaccesses (
    reporttableid integer NOT NULL,
    usergroupaccessid integer NOT NULL
);


--
-- Name: reporttranslations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.reporttranslations (
    reportid integer NOT NULL,
    objecttranslationid integer NOT NULL
);


--
-- Name: reportuseraccesses; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.reportuseraccesses (
    reportid integer NOT NULL,
    useraccessid integer NOT NULL
);


--
-- Name: reportusergroupaccesses; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.reportusergroupaccesses (
    reportid integer NOT NULL,
    usergroupaccessid integer NOT NULL
);


--
-- Name: reservedvalue; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.reservedvalue (
    reservedvalueid integer NOT NULL,
    expirydate timestamp without time zone NOT NULL,
    created timestamp without time zone NOT NULL,
    ownerobject character varying(255),
    owneruid character varying(255),
    key character varying(255),
    value character varying(255)
);


--
-- Name: section; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.section (
    sectionid integer NOT NULL,
    uid character varying(11) NOT NULL,
    code character varying(50),
    created timestamp without time zone NOT NULL,
    lastupdated timestamp without time zone NOT NULL,
    lastupdatedby integer,
    name character varying(230) NOT NULL,
    description text,
    datasetid integer NOT NULL,
    sortorder integer NOT NULL,
    showrowtotals boolean,
    showcolumntotals boolean
);


--
-- Name: sectionattributevalues; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.sectionattributevalues (
    sectionid integer NOT NULL,
    attributevalueid integer NOT NULL
);


--
-- Name: sectiondataelements; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.sectiondataelements (
    sectionid integer NOT NULL,
    sort_order integer NOT NULL,
    dataelementid integer NOT NULL
);


--
-- Name: sectiongreyedfields; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.sectiongreyedfields (
    sectionid integer NOT NULL,
    dataelementoperandid integer NOT NULL
);


--
-- Name: sectionindicators; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.sectionindicators (
    sectionid integer NOT NULL,
    sort_order integer NOT NULL,
    indicatorid integer NOT NULL
);


--
-- Name: sequentialnumbercounter; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.sequentialnumbercounter (
    id integer NOT NULL,
    owneruid character varying(255),
    key character varying(255),
    counter integer
);


--
-- Name: smscodes; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.smscodes (
    smscodeid integer NOT NULL,
    code character varying(255),
    formula text,
    compulsory boolean,
    dataelementid integer,
    trackedentityattributeid integer,
    optionid integer
);


--
-- Name: smscommandcodes; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.smscommandcodes (
    id integer NOT NULL,
    codeid integer NOT NULL
);


--
-- Name: smscommands; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.smscommands (
    smscommandid integer NOT NULL,
    uid character varying(11) NOT NULL,
    created timestamp without time zone NOT NULL,
    lastupdated timestamp without time zone NOT NULL,
    name text,
    parsertype integer,
    separatorkey text,
    codeseparator text,
    defaultmessage text,
    receivedmessage text,
    wrongformatmessage text,
    nousermessage text,
    morethanoneorgunitmessage text,
    successmessage text,
    currentperiodusedforreporting boolean,
    completenessmethod text,
    datasetid integer,
    usergroupid integer,
    programid integer,
    programstageid integer
);


--
-- Name: smscommandspecialcharacters; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.smscommandspecialcharacters (
    smscommandid integer NOT NULL,
    specialcharacterid integer NOT NULL
);


--
-- Name: smsspecialcharacter; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.smsspecialcharacter (
    specialcharacterid integer NOT NULL,
    name text,
    value text
);


--
-- Name: sqlview; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.sqlview (
    sqlviewid integer NOT NULL,
    uid character varying(11) NOT NULL,
    code character varying(50),
    created timestamp without time zone NOT NULL,
    lastupdated timestamp without time zone NOT NULL,
    lastupdatedby integer,
    name character varying(230) NOT NULL,
    description text,
    sqlquery text NOT NULL,
    type character varying(40),
    cachestrategy character varying(40),
    externalaccess boolean,
    userid integer,
    publicaccess character varying(8)
);


--
-- Name: sqlviewattributevalues; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.sqlviewattributevalues (
    sqlviewid integer NOT NULL,
    attributevalueid integer NOT NULL
);


--
-- Name: sqlviewuseraccesses; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.sqlviewuseraccesses (
    sqlviewid integer NOT NULL,
    useraccessid integer NOT NULL
);


--
-- Name: sqlviewusergroupaccesses; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.sqlviewusergroupaccesses (
    sqlviewid integer NOT NULL,
    usergroupaccessid integer NOT NULL
);


--
-- Name: systemsetting; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.systemsetting (
    systemsettingid integer NOT NULL,
    name character varying(255) NOT NULL,
    value bytea
);


--
-- Name: tablehook; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.tablehook (
    analyticstablehookid integer NOT NULL,
    uid character varying(11) NOT NULL,
    code character varying(50),
    created timestamp without time zone NOT NULL,
    lastupdated timestamp without time zone NOT NULL,
    lastupdatedby integer,
    name character varying(255) NOT NULL,
    analyticstablephase character varying(50) NOT NULL,
    resourcetabletype character varying(50),
    analyticstabletype character varying(50),
    sql text NOT NULL
);


--
-- Name: trackedentityattribute; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.trackedentityattribute (
    trackedentityattributeid integer NOT NULL,
    uid character varying(11) NOT NULL,
    code character varying(50),
    created timestamp without time zone NOT NULL,
    lastupdated timestamp without time zone NOT NULL,
    lastupdatedby integer,
    name character varying(230) NOT NULL,
    shortname character varying(50),
    description text,
    formname text,
    valuetype character varying(36) NOT NULL,
    aggregationtype character varying(40) NOT NULL,
    optionsetid integer,
    inherit boolean,
    expression character varying(255),
    displayonvisitschedule boolean,
    sortorderinvisitschedule integer,
    displayinlistnoprogram boolean,
    sortorderinlistnoprogram integer,
    confidential boolean,
    uniquefield boolean,
    generated boolean,
    pattern character varying(255),
    textpattern jsonb,
    style jsonb,
    orgunitscope boolean,
    programscope boolean,
    userid integer,
    publicaccess character varying(8)
);


--
-- Name: trackedentityattributeattributevalues; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.trackedentityattributeattributevalues (
    trackedentityattributeid integer NOT NULL,
    attributevalueid integer NOT NULL
);


--
-- Name: trackedentityattributedimension; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.trackedentityattributedimension (
    trackedentityattributedimensionid integer NOT NULL,
    trackedentityattributeid integer,
    legendsetid integer,
    filter text
);


--
-- Name: trackedentityattributelegendsets; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.trackedentityattributelegendsets (
    trackedentityattributeid integer NOT NULL,
    sort_order integer NOT NULL,
    legendsetid integer NOT NULL
);


--
-- Name: trackedentityattributetranslations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.trackedentityattributetranslations (
    trackedentityattributeid integer NOT NULL,
    objecttranslationid integer NOT NULL
);


--
-- Name: trackedentityattributeuseraccesses; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.trackedentityattributeuseraccesses (
    trackedentityattributeid integer NOT NULL,
    useraccessid integer NOT NULL
);


--
-- Name: trackedentityattributeusergroupaccesses; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.trackedentityattributeusergroupaccesses (
    trackedentityattributeid integer NOT NULL,
    usergroupaccessid integer NOT NULL
);


--
-- Name: trackedentityattributevalue; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.trackedentityattributevalue (
    trackedentityinstanceid integer NOT NULL,
    trackedentityattributeid integer NOT NULL,
    created timestamp without time zone NOT NULL,
    lastupdated timestamp without time zone NOT NULL,
    value character varying(50000),
    encryptedvalue character varying(50000),
    storedby character varying(255)
);


--
-- Name: trackedentityattributevalueaudit; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.trackedentityattributevalueaudit (
    trackedentityattributevalueauditid integer NOT NULL,
    trackedentityinstanceid integer,
    trackedentityattributeid integer,
    value character varying(50000),
    encryptedvalue character varying(50000),
    created timestamp without time zone,
    modifiedby character varying(255),
    audittype character varying(100) NOT NULL
);


--
-- Name: trackedentitycomment; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.trackedentitycomment (
    trackedentitycommentid integer NOT NULL,
    commenttext text,
    createddate timestamp without time zone,
    creator character varying(255)
);


--
-- Name: trackedentitydataelementdimension; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.trackedentitydataelementdimension (
    trackedentitydataelementdimensionid integer NOT NULL,
    dataelementid integer,
    legendsetid integer,
    filter text
);


--
-- Name: trackedentitydatavalue; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.trackedentitydatavalue (
    programstageinstanceid integer NOT NULL,
    dataelementid integer NOT NULL,
    value character varying(50000),
    created timestamp without time zone NOT NULL,
    lastupdated timestamp without time zone NOT NULL,
    providedelsewhere boolean,
    storedby character varying(255)
);


--
-- Name: trackedentitydatavalueaudit; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.trackedentitydatavalueaudit (
    trackedentitydatavalueauditid integer NOT NULL,
    programstageinstanceid integer,
    dataelementid integer,
    value character varying(50000),
    created timestamp without time zone,
    providedelsewhere boolean,
    modifiedby character varying(255),
    audittype character varying(100) NOT NULL
);


--
-- Name: trackedentityinstance; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.trackedentityinstance (
    trackedentityinstanceid integer NOT NULL,
    uid character varying(11) NOT NULL,
    code character varying(50),
    created timestamp without time zone NOT NULL,
    lastupdated timestamp without time zone NOT NULL,
    lastupdatedby integer,
    createdatclient timestamp without time zone,
    lastupdatedatclient timestamp without time zone,
    inactive boolean,
    deleted boolean NOT NULL,
    featuretype character varying(50),
    coordinates text,
    representativeid integer,
    organisationunitid integer NOT NULL,
    trackedentitytypeid integer
);


--
-- Name: trackedentityinstancefilter; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.trackedentityinstancefilter (
    trackedentityinstancefilterid integer NOT NULL,
    uid character varying(11) NOT NULL,
    code character varying(50),
    created timestamp without time zone NOT NULL,
    lastupdated timestamp without time zone NOT NULL,
    lastupdatedby integer,
    name character varying(230) NOT NULL,
    description character varying(255),
    sortorder integer,
    style jsonb,
    programid integer NOT NULL,
    enrollmentstatus character varying(50),
    followup boolean,
    enrollmentcreatedperiod jsonb,
    eventfilters jsonb
);


--
-- Name: trackedentityprogramindicatordimension; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.trackedentityprogramindicatordimension (
    trackedentityprogramindicatordimensionid integer NOT NULL,
    programindicatorid integer,
    legendsetid integer,
    filter text
);


--
-- Name: trackedentitytranslations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.trackedentitytranslations (
    trackedentitytypeid integer NOT NULL,
    objecttranslationid integer NOT NULL
);


--
-- Name: trackedentitytype; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.trackedentitytype (
    trackedentitytypeid integer NOT NULL,
    uid character varying(11) NOT NULL,
    code character varying(50),
    created timestamp without time zone NOT NULL,
    lastupdated timestamp without time zone NOT NULL,
    lastupdatedby integer,
    name character varying(230) NOT NULL,
    description text,
    formname text,
    style jsonb,
    minattributesrequiredtosearch integer,
    maxteicounttoreturn integer,
    userid integer,
    publicaccess character varying(8)
);


--
-- Name: trackedentitytypeattribute; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.trackedentitytypeattribute (
    trackedentitytypeattributeid integer NOT NULL,
    uid character varying(11) NOT NULL,
    code character varying(50),
    created timestamp without time zone NOT NULL,
    lastupdated timestamp without time zone NOT NULL,
    lastupdatedby integer,
    trackedentitytypeid integer,
    trackedentityattributeid integer,
    displayinlist boolean,
    mandatory boolean,
    searchable boolean,
    sort_order integer
);


--
-- Name: trackedentitytypeattributevalues; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.trackedentitytypeattributevalues (
    trackedentitytypeid integer NOT NULL,
    attributevalueid integer NOT NULL
);


--
-- Name: trackedentitytypeuseraccesses; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.trackedentitytypeuseraccesses (
    trackedentitytypeid integer NOT NULL,
    useraccessid integer NOT NULL
);


--
-- Name: trackedentitytypeusergroupaccesses; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.trackedentitytypeusergroupaccesses (
    trackedentitytypeid integer NOT NULL,
    usergroupaccessid integer NOT NULL
);


--
-- Name: useraccess; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.useraccess (
    useraccessid integer NOT NULL,
    access character varying(255),
    userid integer
);


--
-- Name: userapps; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.userapps (
    userinfoid integer NOT NULL,
    sort_order integer NOT NULL,
    app character varying(255)
);


--
-- Name: userattributevalues; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.userattributevalues (
    userinfoid integer NOT NULL,
    attributevalueid integer NOT NULL
);


--
-- Name: userdatavieworgunits; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.userdatavieworgunits (
    userinfoid integer NOT NULL,
    organisationunitid integer NOT NULL
);


--
-- Name: usergroup; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.usergroup (
    usergroupid integer NOT NULL,
    uid character varying(11) NOT NULL,
    code character varying(50),
    created timestamp without time zone NOT NULL,
    lastupdated timestamp without time zone NOT NULL,
    lastupdatedby integer,
    name character varying(230) NOT NULL,
    userid integer,
    publicaccess character varying(8)
);


--
-- Name: usergroupaccess; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.usergroupaccess (
    usergroupaccessid integer NOT NULL,
    access character varying(255),
    usergroupid integer
);


--
-- Name: usergroupattributevalues; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.usergroupattributevalues (
    usergroupid integer NOT NULL,
    attributevalueid integer NOT NULL
);


--
-- Name: usergroupmanaged; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.usergroupmanaged (
    managedbygroupid integer NOT NULL,
    managedgroupid integer NOT NULL
);


--
-- Name: usergroupmembers; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.usergroupmembers (
    userid integer NOT NULL,
    usergroupid integer NOT NULL
);


--
-- Name: usergrouptranslations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.usergrouptranslations (
    usergroupid integer NOT NULL,
    objecttranslationid integer NOT NULL
);


--
-- Name: usergroupuseraccesses; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.usergroupuseraccesses (
    usergroupid integer NOT NULL,
    useraccessid integer NOT NULL
);


--
-- Name: usergroupusergroupaccesses; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.usergroupusergroupaccesses (
    usergroupid integer NOT NULL,
    usergroupaccessid integer NOT NULL
);


--
-- Name: userinfo; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.userinfo (
    userinfoid integer NOT NULL,
    uid character varying(11),
    code character varying(50),
    lastupdated timestamp without time zone NOT NULL,
    created timestamp without time zone NOT NULL,
    surname character varying(160) NOT NULL,
    firstname character varying(160) NOT NULL,
    email character varying(160),
    phonenumber character varying(80),
    jobtitle character varying(160),
    introduction text,
    gender character varying(50),
    birthday date,
    nationality character varying(160),
    employer character varying(160),
    education text,
    interests text,
    languages text,
    lastcheckedinterpretations timestamp without time zone
);


--
-- Name: userkeyjsonvalue; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.userkeyjsonvalue (
    userkeyjsonvalueid integer NOT NULL,
    uid character varying(11) NOT NULL,
    code character varying(50),
    created timestamp without time zone NOT NULL,
    lastupdated timestamp without time zone NOT NULL,
    lastupdatedby integer,
    userid integer NOT NULL,
    namespace character varying(255) NOT NULL,
    userkey character varying(255) NOT NULL,
    value text,
    encrypted_value character varying(255),
    encrypted boolean
);


--
-- Name: usermembership; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.usermembership (
    userinfoid integer NOT NULL,
    organisationunitid integer NOT NULL
);


--
-- Name: usermessage; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.usermessage (
    usermessageid integer NOT NULL,
    usermessagekey character varying(255),
    userid integer NOT NULL,
    isread boolean NOT NULL,
    isfollowup boolean
);


--
-- Name: userrole; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.userrole (
    userroleid integer NOT NULL,
    uid character varying(11) NOT NULL,
    code character varying(50),
    created timestamp without time zone NOT NULL,
    lastupdated timestamp without time zone NOT NULL,
    lastupdatedby integer,
    name character varying(230) NOT NULL,
    description character varying(255),
    userid integer,
    publicaccess character varying(8)
);


--
-- Name: userroleauthorities; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.userroleauthorities (
    userroleid integer NOT NULL,
    authority character varying(255)
);


--
-- Name: userrolemembers; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.userrolemembers (
    userid integer NOT NULL,
    userroleid integer NOT NULL
);


--
-- Name: userroletranslations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.userroletranslations (
    userroleid integer NOT NULL,
    objecttranslationid integer NOT NULL
);


--
-- Name: userroleuseraccesses; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.userroleuseraccesses (
    userroleid integer NOT NULL,
    useraccessid integer NOT NULL
);


--
-- Name: userroleusergroupaccesses; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.userroleusergroupaccesses (
    userroleid integer NOT NULL,
    usergroupaccessid integer NOT NULL
);


--
-- Name: users; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.users (
    userid integer NOT NULL,
    uid character varying(11) NOT NULL,
    code character varying(50),
    created timestamp without time zone NOT NULL,
    lastupdated timestamp without time zone NOT NULL,
    lastupdatedby integer,
    creatoruserid integer,
    username character varying(255) NOT NULL,
    password character varying(60),
    externalauth boolean,
    openid text,
    ldapid text,
    passwordlastupdated timestamp without time zone,
    lastlogin timestamp without time zone,
    restoretoken character varying(255),
    restorecode character varying(255),
    restoreexpiry timestamp without time zone,
    selfregistered boolean,
    invitation boolean,
    disabled boolean
);


--
-- Name: users_catdimensionconstraints; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.users_catdimensionconstraints (
    userid integer NOT NULL,
    dataelementcategoryid integer NOT NULL
);


--
-- Name: users_cogsdimensionconstraints; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.users_cogsdimensionconstraints (
    userid integer NOT NULL,
    categoryoptiongroupsetid integer NOT NULL
);


--
-- Name: usersetting; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.usersetting (
    userinfoid integer NOT NULL,
    name character varying(255) NOT NULL,
    value bytea
);


--
-- Name: userteisearchorgunits; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.userteisearchorgunits (
    userinfoid integer NOT NULL,
    organisationunitid integer NOT NULL
);


--
-- Name: validationcriteria; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.validationcriteria (
    validationcriteriaid integer NOT NULL,
    uid character varying(11) NOT NULL,
    code character varying(50),
    created timestamp without time zone NOT NULL,
    lastupdated timestamp without time zone NOT NULL,
    lastupdatedby integer,
    name character varying(230) NOT NULL,
    description character varying(255),
    property character varying(255),
    operator integer NOT NULL,
    value bytea
);


--
-- Name: validationcriteriatranslations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.validationcriteriatranslations (
    validationcriteriaid integer NOT NULL,
    objecttranslationid integer NOT NULL
);


--
-- Name: validationnotificationtemplate; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.validationnotificationtemplate (
    validationnotificationtemplateid integer NOT NULL,
    uid character varying(11) NOT NULL,
    code character varying(50),
    created timestamp without time zone NOT NULL,
    lastupdated timestamp without time zone NOT NULL,
    lastupdatedby integer,
    name character varying(230) NOT NULL,
    subjecttemplate character varying(100),
    messagetemplate text,
    notifyusersinhierarchyonly boolean,
    sendstrategy character varying(50) NOT NULL
);


--
-- Name: validationnotificationtemplate_recipientusergroups; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.validationnotificationtemplate_recipientusergroups (
    validationnotificationtemplateid integer NOT NULL,
    usergroupid integer NOT NULL
);


--
-- Name: validationnotificationtemplatevalidationrules; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.validationnotificationtemplatevalidationrules (
    validationnotificationtemplateid integer NOT NULL,
    validationruleid integer NOT NULL
);


--
-- Name: validationresult; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.validationresult (
    validationresultid integer NOT NULL,
    created timestamp without time zone NOT NULL,
    leftsidevalue double precision,
    rightsidevalue double precision,
    validationruleid integer,
    periodid integer,
    organisationunitid integer,
    attributeoptioncomboid integer,
    dayinperiod integer,
    notificationsent boolean
);


--
-- Name: validationrule; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.validationrule (
    validationruleid integer NOT NULL,
    uid character varying(11) NOT NULL,
    code character varying(50),
    created timestamp without time zone NOT NULL,
    lastupdated timestamp without time zone NOT NULL,
    lastupdatedby integer,
    name character varying(230) NOT NULL,
    description text,
    instruction text,
    importance character varying(50),
    operator character varying(255) NOT NULL,
    leftexpressionid integer NOT NULL,
    rightexpressionid integer NOT NULL,
    skipformvalidation boolean,
    periodtypeid integer NOT NULL,
    userid integer,
    publicaccess character varying(8)
);


--
-- Name: validationrulegroup; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.validationrulegroup (
    validationrulegroupid integer NOT NULL,
    uid character varying(11) NOT NULL,
    code character varying(50),
    created timestamp without time zone NOT NULL,
    lastupdated timestamp without time zone NOT NULL,
    lastupdatedby integer,
    name character varying(230) NOT NULL,
    description text,
    userid integer,
    publicaccess character varying(8)
);


--
-- Name: validationrulegroupmembers; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.validationrulegroupmembers (
    validationgroupid integer NOT NULL,
    validationruleid integer NOT NULL
);


--
-- Name: validationrulegrouptranslations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.validationrulegrouptranslations (
    validationrulegroupid integer NOT NULL,
    objecttranslationid integer NOT NULL
);


--
-- Name: validationrulegroupuseraccesses; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.validationrulegroupuseraccesses (
    validationrulegroupid integer NOT NULL,
    useraccessid integer NOT NULL
);


--
-- Name: validationrulegroupusergroupaccesses; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.validationrulegroupusergroupaccesses (
    validationrulegroupid integer NOT NULL,
    usergroupaccessid integer NOT NULL
);


--
-- Name: validationruleorganisationunitlevels; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.validationruleorganisationunitlevels (
    validationruleid integer NOT NULL,
    organisationunitlevel integer
);


--
-- Name: validationruletranslations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.validationruletranslations (
    validationruleid integer NOT NULL,
    objecttranslationid integer NOT NULL
);


--
-- Name: validationruleuseraccesses; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.validationruleuseraccesses (
    validationruleid integer NOT NULL,
    useraccessid integer NOT NULL
);


--
-- Name: validationruleusergroupaccesses; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.validationruleusergroupaccesses (
    validationruleid integer NOT NULL,
    usergroupaccessid integer NOT NULL
);


--
-- Name: version; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.version (
    versionid integer NOT NULL,
    versionkey character varying(230) NOT NULL,
    versionvalue character varying(255)
);


--
-- Data for Name: attribute; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.attribute (attributeid, uid, code, created, lastupdated, lastupdatedby, name, shortname, description, valuetype, mandatory, isunique, dataelementattribute, dataelementgroupattribute, indicatorattribute, indicatorgroupattribute, datasetattribute, organisationunitattribute, organisationunitgroupattribute, organisationunitgroupsetattribute, userattribute, usergroupattribute, programattribute, programstageattribute, trackedentitytypeattribute, trackedentityattributeattribute, categoryoptionattribute, categoryoptiongroupattribute, documentattribute, optionattribute, optionsetattribute, constantattribute, legendsetattribute, programindicatorattribute, sqlviewattribute, sectionattribute, categoryoptioncomboattribute, sortorder, optionsetid, userid, publicaccess) FROM stdin;
60	gWjQFnP01Oz	\N	2018-02-25 17:35:12.01	2018-03-27 22:13:38.803	57	Product Group	\N	\N	TEXT	f	f	f	f	f	f	f	f	f	f	f	f	f	f	f	f	f	f	f	t	f	f	f	f	f	f	f	\N	\N	57	rw------
61	jpZsg3mH9SD	\N	2018-02-25 23:37:11.354	2018-03-27 22:13:38.805	57	Product Group Parent Code	\N	\N	TEXT	f	f	f	f	f	f	f	f	f	f	f	f	f	f	f	f	f	f	f	t	f	f	f	f	f	f	f	\N	\N	57	rw------
62	kTEz8fUzxjn	\N	2018-02-24 15:51:28.165	2018-03-27 22:13:38.806	57	Product Image	\N	\N	FILE_RESOURCE	f	f	f	f	f	f	f	f	f	f	f	f	f	f	f	f	f	f	f	t	f	f	f	f	f	f	f	\N	\N	57	rw------
63	gAVTYhhXJcM	\N	2018-02-24 15:40:17.556	2018-03-27 22:13:38.807	57	Product Price	\N	\N	INTEGER_ZERO_OR_POSITIVE	f	f	f	f	f	f	f	f	f	f	f	f	f	f	f	f	f	f	f	t	f	f	f	f	f	f	f	\N	\N	57	rw------
64	Pytqm59iTMC	\N	2018-02-24 15:45:57.939	2018-03-27 22:13:38.808	57	Product Stock	\N	\N	INTEGER_ZERO_OR_POSITIVE	f	f	f	f	f	f	f	f	f	f	f	f	f	f	f	f	f	f	f	t	f	f	f	f	f	f	f	\N	\N	57	rw------
\.


--
-- Data for Name: attributetranslations; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.attributetranslations (attributeid, objecttranslationid) FROM stdin;
\.


--
-- Data for Name: attributeuseraccesses; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.attributeuseraccesses (attributeid, useraccessid) FROM stdin;
\.


--
-- Data for Name: attributeusergroupaccesses; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.attributeusergroupaccesses (attributeid, usergroupaccessid) FROM stdin;
\.


--
-- Data for Name: attributevalue; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.attributevalue (attributevalueid, created, lastupdated, value, attributeid) FROM stdin;
113	2018-02-24 15:41:30.846	2018-02-24 15:41:30.846	40000000	63
114	2018-04-01 20:21:35.45	2018-04-01 20:21:35.45	http://macbooksaigon.vn/layouts/theme/assets/default/uploads//ize_1505390990-macbookpro-15-spacegray-touchbar-a.jpg	62
115	2018-02-24 15:46:32.085	2018-02-24 15:46:32.085	10	64
116	2018-04-03 16:59:03.41	2018-04-03 16:59:03.41	5	64
117	2018-04-03 16:59:48.702	2018-04-03 16:59:48.702	http://macbooksaigon.vn/layouts/theme/assets/default/uploads//ize_1505360523-macbookpro-13-silver-a.jpg	62
118	2018-04-03 16:59:03.41	2018-04-03 16:59:03.41	35000000	63
\.


--
-- Data for Name: categories_categoryoptions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.categories_categoryoptions (categoryid, sort_order, categoryoptionid) FROM stdin;
18	1	17
\.


--
-- Data for Name: categorycombo; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.categorycombo (categorycomboid, uid, code, created, lastupdated, lastupdatedby, name, datadimensiontype, skiptotal, userid, publicaccess) FROM stdin;
19	bjDvmb4bfuf	default	2018-03-27 22:04:55.968	2018-03-27 22:04:55.975	\N	default	DISAGGREGATION	f	\N	--------
\.


--
-- Data for Name: categorycombos_categories; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.categorycombos_categories (categoryid, sort_order, categorycomboid) FROM stdin;
18	1	19
\.


--
-- Data for Name: categorycombos_optioncombos; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.categorycombos_optioncombos (categoryoptioncomboid, categorycomboid) FROM stdin;
20	19
\.


--
-- Data for Name: categorycombotranslations; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.categorycombotranslations (categorycomboid, objecttranslationid) FROM stdin;
\.


--
-- Data for Name: categorycombouseraccesses; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.categorycombouseraccesses (categorycomboid, useraccessid) FROM stdin;
\.


--
-- Data for Name: categorycombousergroupaccesses; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.categorycombousergroupaccesses (categorycomboid, usergroupaccessid) FROM stdin;
\.


--
-- Data for Name: categorydimension; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.categorydimension (categorydimensionid, categoryid) FROM stdin;
\.


--
-- Data for Name: categorydimension_items; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.categorydimension_items (categorydimensionid, sort_order, categoryoptionid) FROM stdin;
\.


--
-- Data for Name: categoryoption_organisationunits; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.categoryoption_organisationunits (organisationunitid, categoryoptionid) FROM stdin;
\.


--
-- Data for Name: categoryoptioncombo; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.categoryoptioncombo (categoryoptioncomboid, uid, code, created, lastupdated, lastupdatedby, name, ignoreapproval) FROM stdin;
20	HllvX50cXC0	default	2018-03-27 22:04:55.972	2018-03-27 22:04:55.972	\N	default	f
\.


--
-- Data for Name: categoryoptioncomboattributevalues; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.categoryoptioncomboattributevalues (categoryoptioncomboid, attributevalueid) FROM stdin;
\.


--
-- Data for Name: categoryoptioncombos_categoryoptions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.categoryoptioncombos_categoryoptions (categoryoptionid, categoryoptioncomboid) FROM stdin;
17	20
\.


--
-- Data for Name: categoryoptioncombotranslations; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.categoryoptioncombotranslations (categoryoptioncomboid, objecttranslationid) FROM stdin;
\.


--
-- Data for Name: categoryoptiongroup; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.categoryoptiongroup (categoryoptiongroupid, uid, code, created, lastupdated, lastupdatedby, name, shortname, datadimensiontype, userid, publicaccess) FROM stdin;
\.


--
-- Data for Name: categoryoptiongroupattributevalues; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.categoryoptiongroupattributevalues (categoryoptiongroupid, attributevalueid) FROM stdin;
\.


--
-- Data for Name: categoryoptiongroupmembers; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.categoryoptiongroupmembers (categoryoptiongroupid, categoryoptionid) FROM stdin;
\.


--
-- Data for Name: categoryoptiongroupset; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.categoryoptiongroupset (categoryoptiongroupsetid, uid, code, created, lastupdated, lastupdatedby, name, description, datadimension, datadimensiontype, userid, publicaccess) FROM stdin;
\.


--
-- Data for Name: categoryoptiongroupsetdimension; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.categoryoptiongroupsetdimension (categoryoptiongroupsetdimensionid, categoryoptiongroupsetid) FROM stdin;
\.


--
-- Data for Name: categoryoptiongroupsetdimension_items; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.categoryoptiongroupsetdimension_items (categoryoptiongroupsetdimensionid, sort_order, categoryoptiongroupid) FROM stdin;
\.


--
-- Data for Name: categoryoptiongroupsetmembers; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.categoryoptiongroupsetmembers (categoryoptiongroupsetid, sort_order, categoryoptiongroupid) FROM stdin;
\.


--
-- Data for Name: categoryoptiongroupsettranslations; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.categoryoptiongroupsettranslations (categoryoptiongroupsetid, objecttranslationid) FROM stdin;
\.


--
-- Data for Name: categoryoptiongroupsetuseraccesses; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.categoryoptiongroupsetuseraccesses (categoryoptiongroupsetid, useraccessid) FROM stdin;
\.


--
-- Data for Name: categoryoptiongroupsetusergroupaccesses; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.categoryoptiongroupsetusergroupaccesses (categoryoptiongroupsetid, usergroupaccessid) FROM stdin;
\.


--
-- Data for Name: categoryoptiongrouptranslations; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.categoryoptiongrouptranslations (categoryoptiongroupid, objecttranslationid) FROM stdin;
\.


--
-- Data for Name: categoryoptiongroupuseraccesses; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.categoryoptiongroupuseraccesses (categoryoptiongroupid, useraccessid) FROM stdin;
\.


--
-- Data for Name: categoryoptiongroupusergroupaccesses; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.categoryoptiongroupusergroupaccesses (categoryoptiongroupid, usergroupaccessid) FROM stdin;
\.


--
-- Data for Name: categoryoptiontranslations; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.categoryoptiontranslations (categoryoptionid, objecttranslationid) FROM stdin;
\.


--
-- Data for Name: chart; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.chart (chartid, uid, code, created, lastupdated, lastupdatedby, name, description, domainaxislabel, rangeaxislabel, type, series, category, hidelegend, nospacebetweencolumns, regressiontype, title, subtitle, hidetitle, hidesubtitle, targetlinevalue, targetlinelabel, baselinevalue, baselinelabel, relativeperiodsid, userorganisationunit, userorganisationunitchildren, userorganisationunitgrandchildren, aggregationtype, completedonly, showdata, hideemptyrowitems, percentstackedvalues, cumulativevalues, rangeaxismaxvalue, rangeaxisminvalue, rangeaxissteps, rangeaxisdecimals, legendsetid, legenddisplaystrategy, colorsetid, sortorder, externalaccess, userid, publicaccess, favorites) FROM stdin;
\.


--
-- Data for Name: chart_categorydimensions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.chart_categorydimensions (chartid, sort_order, categorydimensionid) FROM stdin;
\.


--
-- Data for Name: chart_categoryoptiongroupsetdimensions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.chart_categoryoptiongroupsetdimensions (chart, sort_order, categoryoptiongroupsetdimensionid) FROM stdin;
\.


--
-- Data for Name: chart_datadimensionitems; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.chart_datadimensionitems (chartid, sort_order, datadimensionitemid) FROM stdin;
\.


--
-- Data for Name: chart_dataelementgroupsetdimensions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.chart_dataelementgroupsetdimensions (chartid, sort_order, dataelementgroupsetdimensionid) FROM stdin;
\.


--
-- Data for Name: chart_filters; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.chart_filters (chartid, sort_order, filter) FROM stdin;
\.


--
-- Data for Name: chart_itemorgunitgroups; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.chart_itemorgunitgroups (chartid, sort_order, orgunitgroupid) FROM stdin;
\.


--
-- Data for Name: chart_organisationunits; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.chart_organisationunits (chartid, sort_order, organisationunitid) FROM stdin;
\.


--
-- Data for Name: chart_orgunitgroupsetdimensions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.chart_orgunitgroupsetdimensions (chartid, sort_order, orgunitgroupsetdimensionid) FROM stdin;
\.


--
-- Data for Name: chart_orgunitlevels; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.chart_orgunitlevels (chartid, sort_order, orgunitlevel) FROM stdin;
\.


--
-- Data for Name: chart_periods; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.chart_periods (chartid, sort_order, periodid) FROM stdin;
\.


--
-- Data for Name: charttranslations; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.charttranslations (chartid, objecttranslationid) FROM stdin;
\.


--
-- Data for Name: chartuseraccesses; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.chartuseraccesses (chartid, useraccessid) FROM stdin;
\.


--
-- Data for Name: chartusergroupaccesses; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.chartusergroupaccesses (chartid, usergroupaccessid) FROM stdin;
\.


--
-- Data for Name: color; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.color (colorid, uid, code, created, lastupdated, lastupdatedby, color) FROM stdin;
\.


--
-- Data for Name: colorset; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.colorset (colorsetid, uid, code, created, lastupdated, lastupdatedby, name) FROM stdin;
\.


--
-- Data for Name: colorset_colors; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.colorset_colors (colorsetid, sort_order, colorid) FROM stdin;
\.


--
-- Data for Name: colorsettranslations; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.colorsettranslations (colorsetid, objecttranslationid) FROM stdin;
\.


--
-- Data for Name: colortranslations; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.colortranslations (colorid, objecttranslationid) FROM stdin;
\.


--
-- Data for Name: completedatasetregistration; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.completedatasetregistration (datasetid, periodid, sourceid, attributeoptioncomboid, date, storedby) FROM stdin;
\.


--
-- Data for Name: configuration; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.configuration (configurationid, systemid, feedbackrecipientsid, offlineorgunitlevelid, infrastructuralindicatorsid, infrastructuraldataelementsid, infrastructuralperiodtypeid, selfregistrationrole, selfregistrationorgunit) FROM stdin;
22	755b3a87-d3e6-4264-b515-c7805a7ec38a	\N	\N	\N	\N	\N	\N	\N
\.


--
-- Data for Name: configuration_corswhitelist; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.configuration_corswhitelist (configurationid, corswhitelist) FROM stdin;
22	http://localhost:3000
\.


--
-- Data for Name: constant; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.constant (constantid, uid, code, created, lastupdated, lastupdatedby, name, shortname, description, value, userid, publicaccess) FROM stdin;
\.


--
-- Data for Name: constantattributevalues; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.constantattributevalues (constantid, attributevalueid) FROM stdin;
\.


--
-- Data for Name: constanttranslations; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.constanttranslations (colorid, objecttranslationid) FROM stdin;
\.


--
-- Data for Name: constantuseraccesses; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.constantuseraccesses (constantid, useraccessid) FROM stdin;
\.


--
-- Data for Name: constantusergroupaccesses; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.constantusergroupaccesses (constantid, usergroupaccessid) FROM stdin;
\.


--
-- Data for Name: dashboard; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.dashboard (dashboardid, uid, code, created, lastupdated, lastupdatedby, name, description, userid, externalaccess, publicaccess, favorites) FROM stdin;
\.


--
-- Data for Name: dashboard_items; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.dashboard_items (dashboardid, sort_order, dashboarditemid) FROM stdin;
\.


--
-- Data for Name: dashboarditem; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.dashboarditem (dashboarditemid, uid, code, created, lastupdated, lastupdatedby, chartid, eventchartid, mapid, reporttable, eventreport, textcontent, messages, appkey, shape, x, y, height, width) FROM stdin;
\.


--
-- Data for Name: dashboarditem_reports; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.dashboarditem_reports (dashboarditemid, sort_order, reportid) FROM stdin;
\.


--
-- Data for Name: dashboarditem_resources; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.dashboarditem_resources (dashboarditemid, sort_order, resourceid) FROM stdin;
\.


--
-- Data for Name: dashboarditem_users; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.dashboarditem_users (dashboarditemid, sort_order, userid) FROM stdin;
\.


--
-- Data for Name: dashboarditemtranslations; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.dashboarditemtranslations (dashboarditemid, objecttranslationid) FROM stdin;
\.


--
-- Data for Name: dashboardtranslations; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.dashboardtranslations (dashboardid, objecttranslationid) FROM stdin;
\.


--
-- Data for Name: dashboarduseraccesses; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.dashboarduseraccesses (dashboardid, useraccessid) FROM stdin;
\.


--
-- Data for Name: dashboardusergroupaccesses; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.dashboardusergroupaccesses (dashboardid, usergroupaccessid) FROM stdin;
\.


--
-- Data for Name: dataapproval; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.dataapproval (dataapprovalid, dataapprovallevelid, workflowid, periodid, organisationunitid, attributeoptioncomboid, accepted, created, creator) FROM stdin;
\.


--
-- Data for Name: dataapprovalaudit; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.dataapprovalaudit (dataapprovalauditid, levelid, workflowid, periodid, organisationunitid, attributeoptioncomboid, action, created, creator) FROM stdin;
\.


--
-- Data for Name: dataapprovallevel; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.dataapprovallevel (dataapprovallevelid, uid, code, created, lastupdated, lastupdatedby, name, level, orgunitlevel, categoryoptiongroupsetid, userid, publicaccess) FROM stdin;
\.


--
-- Data for Name: dataapprovalleveltranslations; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.dataapprovalleveltranslations (dataapprovallevelid, objecttranslationid) FROM stdin;
\.


--
-- Data for Name: dataapprovalleveluseraccesses; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.dataapprovalleveluseraccesses (dataapprovallevelid, useraccessid) FROM stdin;
\.


--
-- Data for Name: dataapprovallevelusergroupaccesses; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.dataapprovallevelusergroupaccesses (dataapprovallevelid, usergroupaccessid) FROM stdin;
\.


--
-- Data for Name: dataapprovalworkflow; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.dataapprovalworkflow (workflowid, uid, code, created, lastupdated, lastupdatedby, name, periodtypeid, categorycomboid, userid, publicaccess) FROM stdin;
\.


--
-- Data for Name: dataapprovalworkflowlevels; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.dataapprovalworkflowlevels (workflowid, dataapprovallevelid) FROM stdin;
\.


--
-- Data for Name: dataapprovalworkflowtranslations; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.dataapprovalworkflowtranslations (workflowid, objecttranslationid) FROM stdin;
\.


--
-- Data for Name: dataapprovalworkflowuseraccesses; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.dataapprovalworkflowuseraccesses (workflowid, useraccessid) FROM stdin;
\.


--
-- Data for Name: dataapprovalworkflowusergroupaccesses; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.dataapprovalworkflowusergroupaccesses (workflowid, usergroupaccessid) FROM stdin;
\.


--
-- Data for Name: datadimensionitem; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.datadimensionitem (datadimensionitemid, indicatorid, dataelementid, dataelementoperand_dataelementid, dataelementoperand_categoryoptioncomboid, datasetid, metric, programindicatorid, programdataelement_programid, programdataelement_dataelementid, programattribute_programid, programattribute_attributeid) FROM stdin;
\.


--
-- Data for Name: dataelement; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.dataelement (dataelementid, uid, code, created, lastupdated, lastupdatedby, name, shortname, description, formname, style, valuetype, domaintype, aggregationtype, categorycomboid, url, zeroissignificant, optionsetid, commentoptionsetid, userid, publicaccess) FROM stdin;
\.


--
-- Data for Name: dataelementaggregationlevels; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.dataelementaggregationlevels (dataelementid, sort_order, aggregationlevel) FROM stdin;
\.


--
-- Data for Name: dataelementattributevalues; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.dataelementattributevalues (dataelementid, attributevalueid) FROM stdin;
\.


--
-- Data for Name: dataelementcategory; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.dataelementcategory (categoryid, uid, code, created, lastupdated, lastupdatedby, name, datadimensiontype, datadimension, userid, publicaccess) FROM stdin;
18	GLevLNI9wkl	default	2018-03-27 22:04:55.965	2018-04-03 22:43:36.09	\N	default	DISAGGREGATION	f	\N	--------
\.


--
-- Data for Name: dataelementcategoryoption; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.dataelementcategoryoption (categoryoptionid, uid, code, created, lastupdated, lastupdatedby, name, shortname, startdate, enddate, style, userid, publicaccess) FROM stdin;
17	xYerKDKCefk	default	2018-03-27 22:04:55.939	2018-03-27 22:04:55.977	\N	default	default	\N	\N	\N	\N	--------
\.


--
-- Data for Name: dataelementcategoryoptionattributevalues; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.dataelementcategoryoptionattributevalues (categoryoptionid, attributevalueid) FROM stdin;
\.


--
-- Data for Name: dataelementcategoryoptionuseraccesses; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.dataelementcategoryoptionuseraccesses (categoryoptionid, useraccessid) FROM stdin;
\.


--
-- Data for Name: dataelementcategoryoptionusergroupaccesses; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.dataelementcategoryoptionusergroupaccesses (categoryoptionid, usergroupaccessid) FROM stdin;
\.


--
-- Data for Name: dataelementcategorytranslations; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.dataelementcategorytranslations (categoryid, objecttranslationid) FROM stdin;
\.


--
-- Data for Name: dataelementcategoryuseraccesses; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.dataelementcategoryuseraccesses (categoryid, useraccessid) FROM stdin;
\.


--
-- Data for Name: dataelementcategoryusergroupaccesses; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.dataelementcategoryusergroupaccesses (categoryid, usergroupaccessid) FROM stdin;
\.


--
-- Data for Name: dataelementgroup; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.dataelementgroup (dataelementgroupid, uid, code, created, lastupdated, lastupdatedby, name, shortname, userid, publicaccess) FROM stdin;
\.


--
-- Data for Name: dataelementgroupattributevalues; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.dataelementgroupattributevalues (dataelementgroupid, attributevalueid) FROM stdin;
\.


--
-- Data for Name: dataelementgroupmembers; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.dataelementgroupmembers (dataelementgroupid, dataelementid) FROM stdin;
\.


--
-- Data for Name: dataelementgroupset; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.dataelementgroupset (dataelementgroupsetid, uid, code, created, lastupdated, lastupdatedby, name, description, compulsory, datadimension, userid, publicaccess) FROM stdin;
\.


--
-- Data for Name: dataelementgroupsetdimension; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.dataelementgroupsetdimension (dataelementgroupsetdimensionid, dataelementgroupsetid) FROM stdin;
\.


--
-- Data for Name: dataelementgroupsetdimension_items; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.dataelementgroupsetdimension_items (dataelementgroupsetdimensionid, sort_order, dataelementgroupid) FROM stdin;
\.


--
-- Data for Name: dataelementgroupsetmembers; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.dataelementgroupsetmembers (dataelementgroupsetid, sort_order, dataelementgroupid) FROM stdin;
\.


--
-- Data for Name: dataelementgroupsettranslations; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.dataelementgroupsettranslations (dataelementgroupsetid, objecttranslationid) FROM stdin;
\.


--
-- Data for Name: dataelementgroupsetuseraccesses; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.dataelementgroupsetuseraccesses (dataelementgroupsetid, useraccessid) FROM stdin;
\.


--
-- Data for Name: dataelementgroupsetusergroupaccesses; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.dataelementgroupsetusergroupaccesses (dataelementgroupsetid, usergroupaccessid) FROM stdin;
\.


--
-- Data for Name: dataelementgrouptranslations; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.dataelementgrouptranslations (dataelementgroupid, objecttranslationid) FROM stdin;
\.


--
-- Data for Name: dataelementgroupuseraccesses; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.dataelementgroupuseraccesses (dataelementgroupid, useraccessid) FROM stdin;
\.


--
-- Data for Name: dataelementgroupusergroupaccesses; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.dataelementgroupusergroupaccesses (dataelementgroupid, usergroupaccessid) FROM stdin;
\.


--
-- Data for Name: dataelementlegendsets; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.dataelementlegendsets (dataelementid, sort_order, legendsetid) FROM stdin;
\.


--
-- Data for Name: dataelementoperand; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.dataelementoperand (dataelementoperandid, dataelementid, categoryoptioncomboid) FROM stdin;
\.


--
-- Data for Name: dataelementtranslations; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.dataelementtranslations (dataelementid, objecttranslationid) FROM stdin;
\.


--
-- Data for Name: dataelementuseraccesses; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.dataelementuseraccesses (dataelementid, useraccessid) FROM stdin;
\.


--
-- Data for Name: dataelementusergroupaccesses; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.dataelementusergroupaccesses (dataelementid, usergroupaccessid) FROM stdin;
\.


--
-- Data for Name: dataentryform; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.dataentryform (dataentryformid, uid, code, created, lastupdated, lastupdatedby, name, style, htmlcode, format) FROM stdin;
\.


--
-- Data for Name: dataentryformtranslations; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.dataentryformtranslations (dataentryformid, objecttranslationid) FROM stdin;
\.


--
-- Data for Name: datainputperiod; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.datainputperiod (datainputperiodid, periodid, openingdate, closingdate, datasetid) FROM stdin;
\.


--
-- Data for Name: dataset; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.dataset (datasetid, uid, code, created, lastupdated, lastupdatedby, name, shortname, description, formname, style, periodtypeid, categorycomboid, dataentryform, mobile, version, expirydays, timelydays, notifycompletinguser, workflowid, openfutureperiods, fieldcombinationrequired, validcompleteonly, novaluerequirescomment, skipoffline, dataelementdecoration, renderastabs, renderhorizontally, compulsoryfieldscompleteonly, userid, publicaccess, notificationrecipients) FROM stdin;
\.


--
-- Data for Name: datasetattributevalues; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.datasetattributevalues (datasetid, attributevalueid) FROM stdin;
\.


--
-- Data for Name: datasetelement; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.datasetelement (datasetelementid, datasetid, dataelementid, categorycomboid) FROM stdin;
\.


--
-- Data for Name: datasetindicators; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.datasetindicators (datasetid, indicatorid) FROM stdin;
\.


--
-- Data for Name: datasetlegendsets; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.datasetlegendsets (datasetid, sort_order, legendsetid) FROM stdin;
\.


--
-- Data for Name: datasetnotification_datasets; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.datasetnotification_datasets (datasetnotificationtemplateid, datasetid) FROM stdin;
\.


--
-- Data for Name: datasetnotificationtemplate; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.datasetnotificationtemplate (datasetnotificationtemplateid, uid, code, created, lastupdated, lastupdatedby, name, subjecttemplate, messagetemplate, relativescheduleddays, sendstrategy, usergroupid, datasetnotificationtrigger, notificationrecipienttype) FROM stdin;
\.


--
-- Data for Name: datasetnotificationtemplate_deliverychannel; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.datasetnotificationtemplate_deliverychannel (datasetnotificationtemplateid, deliverychannel) FROM stdin;
\.


--
-- Data for Name: datasetoperands; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.datasetoperands (datasetid, dataelementoperandid) FROM stdin;
\.


--
-- Data for Name: datasetsectiontranslations; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.datasetsectiontranslations (sectionid, objecttranslationid) FROM stdin;
\.


--
-- Data for Name: datasetsource; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.datasetsource (datasetid, sourceid) FROM stdin;
\.


--
-- Data for Name: datasettranslations; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.datasettranslations (datasetid, objecttranslationid) FROM stdin;
\.


--
-- Data for Name: datasetuseraccesses; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.datasetuseraccesses (datasetid, useraccessid) FROM stdin;
\.


--
-- Data for Name: datasetusergroupaccesses; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.datasetusergroupaccesses (datasetid, usergroupaccessid) FROM stdin;
\.


--
-- Data for Name: datastatistics; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.datastatistics (statisticsid, uid, code, created, lastupdated, lastupdatedby, chartviews, mapviews, reporttableviews, eventreportviews, eventchartviews, dashboardviews, datasetreportviews, active_users, totalviews, charts, maps, reporttables, eventreports, eventcharts, dashboards, indicators, datavalues, users) FROM stdin;
\.


--
-- Data for Name: datastatisticsevent; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.datastatisticsevent (eventid, eventtype, "timestamp", username, favoriteuid) FROM stdin;
\.


--
-- Data for Name: datavalue; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.datavalue (dataelementid, periodid, sourceid, categoryoptioncomboid, attributeoptioncomboid, value, storedby, created, lastupdated, comment, followup, deleted) FROM stdin;
\.


--
-- Data for Name: datavalueaudit; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.datavalueaudit (datavalueauditid, dataelementid, periodid, organisationunitid, categoryoptioncomboid, attributeoptioncomboid, value, created, modifiedby, audittype) FROM stdin;
\.


--
-- Data for Name: deletedobject; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.deletedobject (deletedobjectid, klass, uid, code, deleted_at, deleted_by) FROM stdin;
\.


--
-- Data for Name: document; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.document (documentid, uid, code, created, lastupdated, lastupdatedby, name, url, fileresource, external, contenttype, attachment, externalaccess, userid, publicaccess) FROM stdin;
\.


--
-- Data for Name: documentattributevalues; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.documentattributevalues (documentid, attributevalueid) FROM stdin;
\.


--
-- Data for Name: documenttranslations; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.documenttranslations (documentid, objecttranslationid) FROM stdin;
\.


--
-- Data for Name: documentuseraccesses; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.documentuseraccesses (documentid, useraccessid) FROM stdin;
\.


--
-- Data for Name: documentusergroupaccesses; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.documentusergroupaccesses (documentid, usergroupaccessid) FROM stdin;
\.


--
-- Data for Name: eventchart; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.eventchart (eventchartid, uid, code, created, lastupdated, lastupdatedby, name, description, relativeperiodsid, userorganisationunit, userorganisationunitchildren, userorganisationunitgrandchildren, programid, programstageid, startdate, enddate, dataelementvaluedimensionid, attributevaluedimensionid, aggregationtype, completedonly, title, subtitle, hidetitle, hidesubtitle, type, showdata, hideemptyrowitems, hidenadata, programstatus, eventstatus, percentstackedvalues, cumulativevalues, rangeaxismaxvalue, rangeaxisminvalue, rangeaxissteps, rangeaxisdecimals, outputtype, collapsedatadimensions, domainaxislabel, rangeaxislabel, hidelegend, nospacebetweencolumns, regressiontype, targetlinevalue, targetlinelabel, baselinevalue, baselinelabel, sortorder, externalaccess, userid, publicaccess, favorites) FROM stdin;
\.


--
-- Data for Name: eventchart_attributedimensions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.eventchart_attributedimensions (eventchartid, sort_order, trackedentityattributedimensionid) FROM stdin;
\.


--
-- Data for Name: eventchart_categorydimensions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.eventchart_categorydimensions (eventchartid, sort_order, categorydimensionid) FROM stdin;
\.


--
-- Data for Name: eventchart_categoryoptiongroupsetdimensions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.eventchart_categoryoptiongroupsetdimensions (eventchartid, sort_order, categoryoptiongroupsetdimensionid) FROM stdin;
\.


--
-- Data for Name: eventchart_columns; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.eventchart_columns (eventchartid, sort_order, dimension) FROM stdin;
\.


--
-- Data for Name: eventchart_dataelementdimensions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.eventchart_dataelementdimensions (eventchartid, sort_order, trackedentitydataelementdimensionid) FROM stdin;
\.


--
-- Data for Name: eventchart_filters; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.eventchart_filters (eventchartid, sort_order, dimension) FROM stdin;
\.


--
-- Data for Name: eventchart_itemorgunitgroups; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.eventchart_itemorgunitgroups (eventchartid, sort_order, orgunitgroupid) FROM stdin;
\.


--
-- Data for Name: eventchart_organisationunits; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.eventchart_organisationunits (eventchartid, sort_order, organisationunitid) FROM stdin;
\.


--
-- Data for Name: eventchart_orgunitgroupsetdimensions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.eventchart_orgunitgroupsetdimensions (eventchartid, sort_order, orgunitgroupsetdimensionid) FROM stdin;
\.


--
-- Data for Name: eventchart_orgunitlevels; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.eventchart_orgunitlevels (eventchartid, sort_order, orgunitlevel) FROM stdin;
\.


--
-- Data for Name: eventchart_periods; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.eventchart_periods (eventchartid, sort_order, periodid) FROM stdin;
\.


--
-- Data for Name: eventchart_programindicatordimensions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.eventchart_programindicatordimensions (eventchartid, sort_order, trackedentityprogramindicatordimensionid) FROM stdin;
\.


--
-- Data for Name: eventchart_rows; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.eventchart_rows (eventchartid, sort_order, dimension) FROM stdin;
\.


--
-- Data for Name: eventcharttranslations; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.eventcharttranslations (eventchartid, objecttranslationid) FROM stdin;
\.


--
-- Data for Name: eventchartuseraccesses; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.eventchartuseraccesses (eventchartid, useraccessid) FROM stdin;
\.


--
-- Data for Name: eventchartusergroupaccesses; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.eventchartusergroupaccesses (eventchartid, usergroupaccessid) FROM stdin;
\.


--
-- Data for Name: eventreport; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.eventreport (eventreportid, uid, code, created, lastupdated, lastupdatedby, name, description, relativeperiodsid, userorganisationunit, userorganisationunitchildren, userorganisationunitgrandchildren, programid, programstageid, startdate, enddate, dataelementvaluedimensionid, attributevaluedimensionid, aggregationtype, completedonly, title, subtitle, hidetitle, hidesubtitle, datatype, rowtotals, coltotals, rowsubtotals, colsubtotals, hideemptyrows, hidenadata, showhierarchy, outputtype, collapsedatadimensions, showdimensionlabels, digitgroupseparator, displaydensity, fontsize, programstatus, eventstatus, sortorder, toplimit, externalaccess, userid, publicaccess, favorites) FROM stdin;
\.


--
-- Data for Name: eventreport_attributedimensions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.eventreport_attributedimensions (eventreportid, sort_order, trackedentityattributedimensionid) FROM stdin;
\.


--
-- Data for Name: eventreport_categorydimensions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.eventreport_categorydimensions (eventreportid, sort_order, categorydimensionid) FROM stdin;
\.


--
-- Data for Name: eventreport_categoryoptiongroupsetdimensions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.eventreport_categoryoptiongroupsetdimensions (eventreportid, sort_order, categoryoptiongroupsetdimensionid) FROM stdin;
\.


--
-- Data for Name: eventreport_columns; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.eventreport_columns (eventreportid, sort_order, dimension) FROM stdin;
\.


--
-- Data for Name: eventreport_dataelementdimensions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.eventreport_dataelementdimensions (eventreportid, sort_order, trackedentitydataelementdimensionid) FROM stdin;
\.


--
-- Data for Name: eventreport_filters; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.eventreport_filters (eventreportid, sort_order, dimension) FROM stdin;
\.


--
-- Data for Name: eventreport_itemorgunitgroups; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.eventreport_itemorgunitgroups (eventreportid, sort_order, orgunitgroupid) FROM stdin;
\.


--
-- Data for Name: eventreport_organisationunits; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.eventreport_organisationunits (eventreportid, sort_order, organisationunitid) FROM stdin;
\.


--
-- Data for Name: eventreport_orgunitgroupsetdimensions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.eventreport_orgunitgroupsetdimensions (eventreportid, sort_order, orgunitgroupsetdimensionid) FROM stdin;
\.


--
-- Data for Name: eventreport_orgunitlevels; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.eventreport_orgunitlevels (eventreportid, sort_order, orgunitlevel) FROM stdin;
\.


--
-- Data for Name: eventreport_periods; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.eventreport_periods (eventreportid, sort_order, periodid) FROM stdin;
\.


--
-- Data for Name: eventreport_programindicatordimensions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.eventreport_programindicatordimensions (eventreportid, sort_order, trackedentityprogramindicatordimensionid) FROM stdin;
\.


--
-- Data for Name: eventreport_rows; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.eventreport_rows (eventreportid, sort_order, dimension) FROM stdin;
\.


--
-- Data for Name: eventreporttranslations; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.eventreporttranslations (eventreportid, objecttranslationid) FROM stdin;
\.


--
-- Data for Name: eventreportuseraccesses; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.eventreportuseraccesses (eventreportid, useraccessid) FROM stdin;
\.


--
-- Data for Name: eventreportusergroupaccesses; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.eventreportusergroupaccesses (eventreportid, usergroupaccessid) FROM stdin;
\.


--
-- Data for Name: expression; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.expression (expressionid, description, expression, slidingwindow, missingvaluestrategy) FROM stdin;
\.


--
-- Data for Name: externalfileresource; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.externalfileresource (externalfileresourceid, uid, code, created, lastupdated, lastupdatedby, accesstoken, expires, fileresourceid) FROM stdin;
\.


--
-- Data for Name: externalmaplayer; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.externalmaplayer (externalmaplayerid, uid, code, created, lastupdated, lastupdatedby, name, attribution, url, legendseturl, maplayerposition, layers, imageformat, mapservice, legendsetid, userid, publicaccess) FROM stdin;
\.


--
-- Data for Name: externalmaplayeruseraccesses; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.externalmaplayeruseraccesses (externalmaplayerid, useraccessid) FROM stdin;
\.


--
-- Data for Name: externalmaplayerusergroupaccesses; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.externalmaplayerusergroupaccesses (externalmaplayerid, usergroupaccessid) FROM stdin;
\.


--
-- Data for Name: externalnotificationlogentry; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.externalnotificationlogentry (externalnotificationlogentryid, uid, created, lastupdated, lastsentat, retries, key, templateuid, allowmultiple, triggerby) FROM stdin;
\.


--
-- Data for Name: fileresource; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.fileresource (fileresourceid, uid, code, created, lastupdated, lastupdatedby, name, contenttype, contentlength, contentmd5, storagekey, isassigned, storagestatus, domain, userid) FROM stdin;
\.


--
-- Name: hibernate_sequence; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.hibernate_sequence', 118, true);


--
-- Data for Name: i18nlocale; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.i18nlocale (i18nlocaleid, uid, code, created, lastupdated, lastupdatedby, name, locale) FROM stdin;
23	tlevT2eDzvC	\N	2018-03-27 22:05:01.43	2018-03-27 22:05:01.43	\N	Afrikaans	af
24	Vh2vFRLk09c	\N	2018-03-27 22:05:01.431	2018-03-27 22:05:01.431	\N	Arabic	ar
25	zkhTA7mzOKc	\N	2018-03-27 22:05:01.431	2018-03-27 22:05:01.431	\N	Bislama	bi
26	fRNtwjo6z3b	\N	2018-03-27 22:05:01.432	2018-03-27 22:05:01.432	\N	Amharic	am
27	W9Sh1H74Fq5	\N	2018-03-27 22:05:01.432	2018-03-27 22:05:01.432	\N	German	de
28	aMulPCM6UYX	\N	2018-03-27 22:05:01.433	2018-03-27 22:05:01.433	\N	Dzongkha	dz
29	bCUVZFGbJx4	\N	2018-03-27 22:05:01.433	2018-03-27 22:05:01.434	\N	English	en
30	rWOnaju3t0s	\N	2018-03-27 22:05:01.434	2018-03-27 22:05:01.434	\N	Spanish	es
31	gCpTi2ESUEg	\N	2018-03-27 22:05:01.434	2018-03-27 22:05:01.434	\N	Persian	fa
32	AsiazkxCEOw	\N	2018-03-27 22:05:01.435	2018-03-27 22:05:01.435	\N	French	fr
33	AfG5BHPIN70	\N	2018-03-27 22:05:01.435	2018-03-27 22:05:01.435	\N	Gujarati	gu
34	IP8f5NHewDG	\N	2018-03-27 22:05:01.436	2018-03-27 22:05:01.436	\N	Hindi	hi
35	lmcL7a5GySv	\N	2018-03-27 22:05:01.437	2018-03-27 22:05:01.437	\N	Indonesian	in
36	SLHXikc7nI1	\N	2018-03-27 22:05:01.437	2018-03-27 22:05:01.437	\N	Italian	it
37	S41b7QJ05II	\N	2018-03-27 22:05:01.438	2018-03-27 22:05:01.438	\N	Khmer	km
38	CeP6hOh5CyS	\N	2018-03-27 22:05:01.439	2018-03-27 22:05:01.439	\N	Lao	lo
39	IICvJuNjazA	\N	2018-03-27 22:05:01.439	2018-03-27 22:05:01.439	\N	Burmese	my
40	ZHEQFimYKFt	\N	2018-03-27 22:05:01.44	2018-03-27 22:05:01.44	\N	Nepali	ne
41	njbL1lZ7dId	\N	2018-03-27 22:05:01.441	2018-03-27 22:05:01.441	\N	Dutch	nl
42	RPkCAtcOtcT	\N	2018-03-27 22:05:01.441	2018-03-27 22:05:01.441	\N	Norwegian	no
43	nAgVkHggCah	\N	2018-03-27 22:05:01.442	2018-03-27 22:05:01.442	\N	Pushto	ps
44	gZrdM9cXg4J	\N	2018-03-27 22:05:01.442	2018-03-27 22:05:01.442	\N	Portuguese	pt
45	fxfoN08OyCh	\N	2018-03-27 22:05:01.443	2018-03-27 22:05:01.443	\N	Russian	ru
46	UTmfzcyCRNc	\N	2018-03-27 22:05:01.443	2018-03-27 22:05:01.443	\N	Kinyarwanda	rw
47	pooqXrQLyAI	\N	2018-03-27 22:05:01.444	2018-03-27 22:05:01.444	\N	Swahili	sw
48	K4TSljpuAP7	\N	2018-03-27 22:05:01.444	2018-03-27 22:05:01.444	\N	Tajik	tg
49	U6pYW9eEko2	\N	2018-03-27 22:05:01.445	2018-03-27 22:05:01.445	\N	Vietnamese	vi
50	LQNwVAj86ty	\N	2018-03-27 22:05:01.445	2018-03-27 22:05:01.445	\N	Chinese	zh
\.


--
-- Data for Name: incomingsms; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.incomingsms (id, originator, encoding, sentdate, receiveddate, text, gatewayid, status, parsed, statusmessage, userid) FROM stdin;
\.


--
-- Data for Name: indicator; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.indicator (indicatorid, uid, code, created, lastupdated, lastupdatedby, name, shortname, description, formname, annualized, decimals, indicatortypeid, numerator, numeratordescription, denominator, denominatordescription, url, style, aggregateexportcategoryoptioncombo, aggregateexportattributeoptioncombo, userid, publicaccess) FROM stdin;
\.


--
-- Data for Name: indicatorattributevalues; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.indicatorattributevalues (indicatorid, attributevalueid) FROM stdin;
\.


--
-- Data for Name: indicatorgroup; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.indicatorgroup (indicatorgroupid, uid, code, created, lastupdated, lastupdatedby, name, userid, publicaccess) FROM stdin;
\.


--
-- Data for Name: indicatorgroupattributevalues; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.indicatorgroupattributevalues (indicatorgroupid, attributevalueid) FROM stdin;
\.


--
-- Data for Name: indicatorgroupmembers; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.indicatorgroupmembers (indicatorgroupid, indicatorid) FROM stdin;
\.


--
-- Data for Name: indicatorgroupset; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.indicatorgroupset (indicatorgroupsetid, uid, code, created, lastupdated, lastupdatedby, name, description, compulsory, userid, publicaccess) FROM stdin;
\.


--
-- Data for Name: indicatorgroupsetmembers; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.indicatorgroupsetmembers (indicatorgroupid, indicatorgroupsetid, sort_order) FROM stdin;
\.


--
-- Data for Name: indicatorgroupsettranslations; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.indicatorgroupsettranslations (indicatorgroupsetid, objecttranslationid) FROM stdin;
\.


--
-- Data for Name: indicatorgroupsetuseraccesses; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.indicatorgroupsetuseraccesses (indicatorgroupsetid, useraccessid) FROM stdin;
\.


--
-- Data for Name: indicatorgroupsetusergroupaccesses; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.indicatorgroupsetusergroupaccesses (indicatorgroupsetid, usergroupaccessid) FROM stdin;
\.


--
-- Data for Name: indicatorgrouptranslations; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.indicatorgrouptranslations (indicatorgroupid, objecttranslationid) FROM stdin;
\.


--
-- Data for Name: indicatorgroupuseraccesses; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.indicatorgroupuseraccesses (indicatorgroupid, useraccessid) FROM stdin;
\.


--
-- Data for Name: indicatorgroupusergroupaccesses; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.indicatorgroupusergroupaccesses (indicatorgroupid, usergroupaccessid) FROM stdin;
\.


--
-- Data for Name: indicatorlegendsets; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.indicatorlegendsets (indicatorid, sort_order, legendsetid) FROM stdin;
\.


--
-- Data for Name: indicatortranslations; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.indicatortranslations (indicatorid, objecttranslationid) FROM stdin;
\.


--
-- Data for Name: indicatortype; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.indicatortype (indicatortypeid, uid, code, created, lastupdated, lastupdatedby, name, indicatorfactor, indicatornumber) FROM stdin;
\.


--
-- Data for Name: indicatortypetranslations; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.indicatortypetranslations (indicatortypeid, objecttranslationid) FROM stdin;
\.


--
-- Data for Name: indicatoruseraccesses; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.indicatoruseraccesses (indicatorid, useraccessid) FROM stdin;
\.


--
-- Data for Name: indicatorusergroupaccesses; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.indicatorusergroupaccesses (indicatorid, usergroupaccessid) FROM stdin;
\.


--
-- Data for Name: intepretation_likedby; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.intepretation_likedby (interpretationid, userid) FROM stdin;
\.


--
-- Data for Name: interpretation; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.interpretation (interpretationid, uid, lastupdated, reporttableid, chartid, mapid, eventreportid, eventchartid, datasetid, periodid, organisationunitid, interpretationtext, created, likes, userid, publicaccess) FROM stdin;
\.


--
-- Data for Name: interpretation_comments; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.interpretation_comments (interpretationid, sort_order, interpretationcommentid) FROM stdin;
\.


--
-- Data for Name: interpretationcomment; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.interpretationcomment (interpretationcommentid, uid, lastupdated, commenttext, userid, created) FROM stdin;
\.


--
-- Data for Name: interpretationuseraccesses; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.interpretationuseraccesses (interpretationid, useraccessid) FROM stdin;
\.


--
-- Data for Name: interpretationusergroupaccesses; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.interpretationusergroupaccesses (interpretationid, usergroupaccessid) FROM stdin;
\.


--
-- Data for Name: jobconfiguration; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.jobconfiguration (jobconfigurationid, uid, code, created, lastupdated, lastupdatedby, name, cronexpression, jobtype, jobstatus, lastexecutedstatus, lastexecuted, lastruntimeexecution, nextexecutiontime, continuousexecution, enabled, jobparameters) FROM stdin;
55	hNTftz2HkRg	\N	2018-03-27 22:05:01.503	2018-04-03 22:43:45.042	\N	Dataset notification	0 0 2 ? * *	\\xaced00057e7200206f72672e686973702e646869732e7363686564756c696e672e4a6f625479706500000000000000001200007872000e6a6176612e6c616e672e456e756d00000000000000001200007870740015444154415f5345545f4e4f54494649434154494f4e	\\xaced00057e7200226f72672e686973702e646869732e7363686564756c696e672e4a6f6253746174757300000000000000001200007872000e6a6176612e6c616e672e456e756d000000000000000012000078707400095343484544554c4544	\N	\N	\N	2018-04-04 02:00:00	f	t	\N
51	SsNR43G5MJm	\N	2018-03-27 22:05:01.464	2018-04-03 22:43:45.056	\N	File resource clean up	0 0 2 ? * *	\\xaced00057e7200206f72672e686973702e646869732e7363686564756c696e672e4a6f625479706500000000000000001200007872000e6a6176612e6c616e672e456e756d0000000000000000120000787074001546494c455f5245534f555243455f434c45414e5550	\\xaced00057e7200226f72672e686973702e646869732e7363686564756c696e672e4a6f6253746174757300000000000000001200007872000e6a6176612e6c616e672e456e756d000000000000000012000078707400095343484544554c4544	\N	\N	\N	2018-04-04 02:00:00	f	t	\N
52	JLHtpZq1DXo	\N	2018-03-27 22:05:01.485	2018-04-03 22:43:45.062	\N	Data statistics	0 0 2 ? * *	\\xaced00057e7200206f72672e686973702e646869732e7363686564756c696e672e4a6f625479706500000000000000001200007872000e6a6176612e6c616e672e456e756d0000000000000000120000787074000f444154415f53544154495354494353	\\xaced00057e7200226f72672e686973702e646869732e7363686564756c696e672e4a6f6253746174757300000000000000001200007872000e6a6176612e6c616e672e456e756d000000000000000012000078707400095343484544554c4544	\N	\N	\N	2018-04-04 02:00:00	f	t	\N
53	WUf5KBtfEKS	\N	2018-03-27 22:05:01.49	2018-04-03 22:43:45.068	\N	Validation result notification	0 0 7 ? * *	\\xaced00057e7200206f72672e686973702e646869732e7363686564756c696e672e4a6f625479706500000000000000001200007872000e6a6176612e6c616e672e456e756d0000000000000000120000787074001f56414c49444154494f4e5f524553554c54535f4e4f54494649434154494f4e	\\xaced00057e7200226f72672e686973702e646869732e7363686564756c696e672e4a6f6253746174757300000000000000001200007872000e6a6176612e6c616e672e456e756d000000000000000012000078707400095343484544554c4544	\N	\N	\N	2018-04-04 07:00:00	f	t	\N
54	fQmMxemGFgk	\N	2018-03-27 22:05:01.497	2018-04-03 22:43:45.074	\N	Credentials expiry alert	0 0 2 ? * *	\\xaced00057e7200206f72672e686973702e646869732e7363686564756c696e672e4a6f625479706500000000000000001200007872000e6a6176612e6c616e672e456e756d0000000000000000120000787074001843524544454e5449414c535f4558504952595f414c455254	\\xaced00057e7200226f72672e686973702e646869732e7363686564756c696e672e4a6f6253746174757300000000000000001200007872000e6a6176612e6c616e672e456e756d000000000000000012000078707400095343484544554c4544	\N	\N	\N	2018-04-04 02:00:00	f	t	\N
56	pYKox8efzzT	\N	2018-03-27 22:05:01.509	2018-04-04 00:00:00.009	\N	Remove expired reserved values	0 0 * ? * *	\\xaced00057e7200206f72672e686973702e646869732e7363686564756c696e672e4a6f625479706500000000000000001200007872000e6a6176612e6c616e672e456e756d0000000000000000120000787074001e52454d4f56455f455850495245445f52455345525645445f56414c554553	\\xaced00057e7200226f72672e686973702e646869732e7363686564756c696e672e4a6f6253746174757300000000000000001200007872000e6a6176612e6c616e672e456e756d000000000000000012000078707400095343484544554c4544	\\xaced00057e7200226f72672e686973702e646869732e7363686564756c696e672e4a6f6253746174757300000000000000001200007872000e6a6176612e6c616e672e456e756d00000000000000001200007870740009434f4d504c45544544	2018-04-04 00:00:00.007	00:00:00.006	2018-04-04 01:00:00	f	t	\N
\.


--
-- Data for Name: keyjsonvalue; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.keyjsonvalue (keyjsonvalueid, uid, code, created, lastupdated, lastupdatedby, namespace, namespacekey, value, encrypted_value, encrypted) FROM stdin;
\.


--
-- Data for Name: legendsetattributevalues; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.legendsetattributevalues (legendsetid, attributevalueid) FROM stdin;
\.


--
-- Data for Name: legendsetuseraccesses; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.legendsetuseraccesses (maplegendsetid, useraccessid) FROM stdin;
\.


--
-- Data for Name: legendsetusergroupaccesses; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.legendsetusergroupaccesses (maplegendsetid, usergroupaccessid) FROM stdin;
\.


--
-- Data for Name: lockexception; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.lockexception (lockexceptionid, organisationunitid, periodid, datasetid) FROM stdin;
\.


--
-- Data for Name: map; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.map (mapid, uid, code, created, lastupdated, lastupdatedby, name, description, longitude, latitude, zoom, basemap, title, externalaccess, userid, publicaccess, favorites) FROM stdin;
\.


--
-- Data for Name: maplegend; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.maplegend (maplegendid, uid, code, created, lastupdated, lastupdatedby, name, startvalue, endvalue, color, image, maplegendsetid) FROM stdin;
\.


--
-- Data for Name: maplegendset; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.maplegendset (maplegendsetid, uid, code, created, lastupdated, lastupdatedby, name, symbolizer, userid, publicaccess) FROM stdin;
\.


--
-- Data for Name: maplegendsettranslations; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.maplegendsettranslations (maplegendsetid, objecttranslationid) FROM stdin;
\.


--
-- Data for Name: maplegendtranslations; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.maplegendtranslations (maplegendid, objecttranslationid) FROM stdin;
\.


--
-- Data for Name: mapmapviews; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.mapmapviews (mapid, sort_order, mapviewid) FROM stdin;
\.


--
-- Data for Name: mapuseraccesses; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.mapuseraccesses (mapid, useraccessid) FROM stdin;
\.


--
-- Data for Name: mapusergroupaccesses; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.mapusergroupaccesses (mapid, usergroupaccessid) FROM stdin;
\.


--
-- Data for Name: mapview; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.mapview (mapviewid, uid, code, created, lastupdated, lastupdatedby, description, layer, relativeperiodsid, userorganisationunit, userorganisationunitchildren, userorganisationunitgrandchildren, aggregationtype, programid, programstageid, startdate, enddate, method, classes, colorlow, colorhigh, colorscale, legendsetid, radiuslow, radiushigh, opacity, orgunitgroupsetid, arearadius, hidden, labels, labelfontsize, labelfontweight, labelfontstyle, labelfontcolor, eventclustering, eventcoordinatefield, eventpointcolor, eventpointradius, config, styledataitem) FROM stdin;
\.


--
-- Data for Name: mapview_attributedimensions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.mapview_attributedimensions (mapviewid, sort_order, trackedentityattributedimensionid) FROM stdin;
\.


--
-- Data for Name: mapview_columns; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.mapview_columns (mapviewid, sort_order, dimension) FROM stdin;
\.


--
-- Data for Name: mapview_datadimensionitems; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.mapview_datadimensionitems (mapviewid, sort_order, datadimensionitemid) FROM stdin;
\.


--
-- Data for Name: mapview_dataelementdimensions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.mapview_dataelementdimensions (mapviewid, sort_order, trackedentitydataelementdimensionid) FROM stdin;
\.


--
-- Data for Name: mapview_itemorgunitgroups; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.mapview_itemorgunitgroups (mapviewid, sort_order, orgunitgroupid) FROM stdin;
\.


--
-- Data for Name: mapview_organisationunits; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.mapview_organisationunits (mapviewid, sort_order, organisationunitid) FROM stdin;
\.


--
-- Data for Name: mapview_orgunitlevels; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.mapview_orgunitlevels (mapviewid, sort_order, orgunitlevel) FROM stdin;
\.


--
-- Data for Name: mapview_periods; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.mapview_periods (mapviewid, sort_order, periodid) FROM stdin;
\.


--
-- Data for Name: mapviewtranslations; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.mapviewtranslations (mapviewid, objecttranslationid) FROM stdin;
\.


--
-- Data for Name: message; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.message (messageid, uid, created, lastupdated, messagetext, internal, metadata, userid) FROM stdin;
79	WjuGmX1ClIM	2018-03-28 09:31:07.668	2018-03-28 09:31:07.668	Scheduler startup\n\nSystem title: DHIS 2\nBase URL: null\nTime: 2018-03-28T09:31:07.660+07:00\nMessage: Scheduler started with one or more unexecuted jobs:\nJob [pYKox8efzzT, Remove expired reserved values] has status failed or was scheduled in server downtime. Actual execution time was supposed to be: 2018-03-28 01:00:00.0\n\n\nCause: 	f	\N	\N
83	zrdA9uvzBlY	2018-03-29 08:40:14.83	2018-03-29 08:40:14.83	Scheduler startup\n\nSystem title: DHIS 2\nBase URL: null\nTime: 2018-03-29T08:40:14.822+07:00\nMessage: Scheduler started with one or more unexecuted jobs:\nJob [pYKox8efzzT, Remove expired reserved values] has status failed or was scheduled in server downtime. Actual execution time was supposed to be: 2018-03-28 18:00:00.0\nJob [SsNR43G5MJm, File resource clean up] has status failed or was scheduled in server downtime. Actual execution time was supposed to be: 2018-03-29 02:00:00.0\nJob [JLHtpZq1DXo, Data statistics] has status failed or was scheduled in server downtime. Actual execution time was supposed to be: 2018-03-29 02:00:00.0\nJob [WUf5KBtfEKS, Validation result notification] has status failed or was scheduled in server downtime. Actual execution time was supposed to be: 2018-03-29 07:00:00.0\nJob [fQmMxemGFgk, Credentials expiry alert] has status failed or was scheduled in server downtime. Actual execution time was supposed to be: 2018-03-29 02:00:00.0\nJob [hNTftz2HkRg, Dataset notification] has status failed or was scheduled in server downtime. Actual execution time was supposed to be: 2018-03-29 02:00:00.0\n\n\nCause: 	f	\N	\N
85	U3ABM19Bmpy	2018-03-30 09:20:48.932	2018-03-30 09:20:48.932	Scheduler startup\n\nSystem title: DHIS 2\nBase URL: null\nTime: 2018-03-30T09:20:48.924+07:00\nMessage: Scheduler started with one or more unexecuted jobs:\nJob [pYKox8efzzT, Remove expired reserved values] has status failed or was scheduled in server downtime. Actual execution time was supposed to be: 2018-03-29 17:00:00.0\nJob [SsNR43G5MJm, File resource clean up] has status failed or was scheduled in server downtime. Actual execution time was supposed to be: 2018-03-30 02:00:00.0\nJob [JLHtpZq1DXo, Data statistics] has status failed or was scheduled in server downtime. Actual execution time was supposed to be: 2018-03-30 02:00:00.0\nJob [WUf5KBtfEKS, Validation result notification] has status failed or was scheduled in server downtime. Actual execution time was supposed to be: 2018-03-30 07:00:00.0\nJob [fQmMxemGFgk, Credentials expiry alert] has status failed or was scheduled in server downtime. Actual execution time was supposed to be: 2018-03-30 02:00:00.0\nJob [hNTftz2HkRg, Dataset notification] has status failed or was scheduled in server downtime. Actual execution time was supposed to be: 2018-03-30 02:00:00.0\n\n\nCause: 	f	\N	\N
87	wLxjLzahWu9	2018-03-30 23:03:17.92	2018-03-30 23:03:17.92	Scheduler startup\n\nSystem title: DHIS 2\nBase URL: null\nTime: 2018-03-30T23:03:17.912+07:00\nMessage: Scheduler started with one or more unexecuted jobs:\nJob [pYKox8efzzT, Remove expired reserved values] has status failed or was scheduled in server downtime. Actual execution time was supposed to be: 2018-03-30 17:00:00.0\n\n\nCause: 	f	\N	\N
89	ndBQ0CrWhqH	2018-04-01 00:43:51.728	2018-04-01 00:43:51.728	Scheduler startup\n\nSystem title: DHIS 2\nBase URL: null\nTime: 2018-04-01T00:43:51.720+07:00\nMessage: Scheduler started with one or more unexecuted jobs:\nJob [pYKox8efzzT, Remove expired reserved values] has status failed or was scheduled in server downtime. Actual execution time was supposed to be: 2018-03-31 02:00:00.0\nJob [SsNR43G5MJm, File resource clean up] has status failed or was scheduled in server downtime. Actual execution time was supposed to be: 2018-03-31 02:00:00.0\nJob [JLHtpZq1DXo, Data statistics] has status failed or was scheduled in server downtime. Actual execution time was supposed to be: 2018-03-31 02:00:00.0\nJob [WUf5KBtfEKS, Validation result notification] has status failed or was scheduled in server downtime. Actual execution time was supposed to be: 2018-03-31 07:00:00.0\nJob [fQmMxemGFgk, Credentials expiry alert] has status failed or was scheduled in server downtime. Actual execution time was supposed to be: 2018-03-31 02:00:00.0\nJob [hNTftz2HkRg, Dataset notification] has status failed or was scheduled in server downtime. Actual execution time was supposed to be: 2018-03-31 02:00:00.0\n\n\nCause: 	f	\N	\N
91	Y6dzE1QlMoP	2018-04-01 10:51:17.917	2018-04-01 10:51:17.917	Scheduler startup\n\nSystem title: DHIS 2\nBase URL: null\nTime: 2018-04-01T10:51:17.909+07:00\nMessage: Scheduler started with one or more unexecuted jobs:\nJob [SsNR43G5MJm, File resource clean up] has status failed or was scheduled in server downtime. Actual execution time was supposed to be: 2018-04-01 02:00:00.0\nJob [JLHtpZq1DXo, Data statistics] has status failed or was scheduled in server downtime. Actual execution time was supposed to be: 2018-04-01 02:00:00.0\nJob [WUf5KBtfEKS, Validation result notification] has status failed or was scheduled in server downtime. Actual execution time was supposed to be: 2018-04-01 07:00:00.0\nJob [fQmMxemGFgk, Credentials expiry alert] has status failed or was scheduled in server downtime. Actual execution time was supposed to be: 2018-04-01 02:00:00.0\nJob [hNTftz2HkRg, Dataset notification] has status failed or was scheduled in server downtime. Actual execution time was supposed to be: 2018-04-01 02:00:00.0\nJob [pYKox8efzzT, Remove expired reserved values] has status failed or was scheduled in server downtime. Actual execution time was supposed to be: 2018-04-01 01:00:00.0\n\n\nCause: 	f	\N	\N
93	xUCfoFT4f4u	2018-04-01 18:07:00.826	2018-04-01 18:07:00.826	Scheduler startup\n\nSystem title: DHIS 2\nBase URL: null\nTime: 2018-04-01T18:07:00.817+07:00\nMessage: Scheduler started with one or more unexecuted jobs:\nJob [pYKox8efzzT, Remove expired reserved values] has status failed or was scheduled in server downtime. Actual execution time was supposed to be: 2018-04-01 14:00:00.0\n\n\nCause: 	f	\N	\N
98	biT52YtsQ7D	2018-04-02 09:18:55.127	2018-04-02 09:18:55.127	Scheduler startup\n\nSystem title: DHIS 2\nBase URL: null\nTime: 2018-04-02T09:18:55.118+07:00\nMessage: Scheduler started with one or more unexecuted jobs:\nJob [hNTftz2HkRg, Dataset notification] has status failed or was scheduled in server downtime. Actual execution time was supposed to be: 2018-04-02 02:00:00.0\nJob [SsNR43G5MJm, File resource clean up] has status failed or was scheduled in server downtime. Actual execution time was supposed to be: 2018-04-02 02:00:00.0\nJob [JLHtpZq1DXo, Data statistics] has status failed or was scheduled in server downtime. Actual execution time was supposed to be: 2018-04-02 02:00:00.0\nJob [WUf5KBtfEKS, Validation result notification] has status failed or was scheduled in server downtime. Actual execution time was supposed to be: 2018-04-02 07:00:00.0\nJob [fQmMxemGFgk, Credentials expiry alert] has status failed or was scheduled in server downtime. Actual execution time was supposed to be: 2018-04-02 02:00:00.0\nJob [pYKox8efzzT, Remove expired reserved values] has status failed or was scheduled in server downtime. Actual execution time was supposed to be: 2018-04-02 01:00:00.0\n\n\nCause: 	f	\N	\N
100	ZTuoPMGNzfI	2018-04-02 17:02:02.249	2018-04-02 17:02:02.249	Scheduler startup\n\nSystem title: DHIS 2\nBase URL: null\nTime: 2018-04-02T17:02:02.229+07:00\nMessage: Scheduler started with one or more unexecuted jobs:\nJob [pYKox8efzzT, Remove expired reserved values] has status failed or was scheduled in server downtime. Actual execution time was supposed to be: 2018-04-02 17:00:00.0\n\n\nCause: 	f	\N	\N
102	Y9fz7KQkIYn	2018-04-02 23:01:38.956	2018-04-02 23:01:38.956	Scheduler startup\n\nSystem title: DHIS 2\nBase URL: null\nTime: 2018-04-02T23:01:38.941+07:00\nMessage: Scheduler started with one or more unexecuted jobs:\nJob [pYKox8efzzT, Remove expired reserved values] has status failed or was scheduled in server downtime. Actual execution time was supposed to be: 2018-04-02 18:00:00.0\n\n\nCause: 	f	\N	\N
104	q2gSXJPn8hx	2018-04-03 07:52:05.462	2018-04-03 07:52:05.462	Scheduler startup\n\nSystem title: DHIS 2\nBase URL: null\nTime: 2018-04-03T07:52:05.453+07:00\nMessage: Scheduler started with one or more unexecuted jobs:\nJob [pYKox8efzzT, Remove expired reserved values] has status failed or was scheduled in server downtime. Actual execution time was supposed to be: 2018-04-03 01:00:00.0\nJob [hNTftz2HkRg, Dataset notification] has status failed or was scheduled in server downtime. Actual execution time was supposed to be: 2018-04-03 02:00:00.0\nJob [SsNR43G5MJm, File resource clean up] has status failed or was scheduled in server downtime. Actual execution time was supposed to be: 2018-04-03 02:00:00.0\nJob [JLHtpZq1DXo, Data statistics] has status failed or was scheduled in server downtime. Actual execution time was supposed to be: 2018-04-03 02:00:00.0\nJob [WUf5KBtfEKS, Validation result notification] has status failed or was scheduled in server downtime. Actual execution time was supposed to be: 2018-04-03 07:00:00.0\nJob [fQmMxemGFgk, Credentials expiry alert] has status failed or was scheduled in server downtime. Actual execution time was supposed to be: 2018-04-03 02:00:00.0\n\n\nCause: 	f	\N	\N
112	ObpU7gQNTIv	2018-04-03 22:43:45.097	2018-04-03 22:43:45.097	Scheduler startup\n\nSystem title: DHIS 2\nBase URL: null\nTime: 2018-04-03T22:43:45.088+07:00\nMessage: Scheduler started with one or more unexecuted jobs:\nJob [pYKox8efzzT, Remove expired reserved values] has status failed or was scheduled in server downtime. Actual execution time was supposed to be: 2018-04-03 18:00:00.0\n\n\nCause: 	f	\N	\N
\.


--
-- Data for Name: messageconversation; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.messageconversation (messageconversationid, uid, messagecount, created, lastupdated, subject, messagetype, priority, status, user_assigned, lastsenderid, lastmessage, userid) FROM stdin;
78	STp6HUXOR4a	1	2018-03-28 09:31:07.673	2018-03-28 09:31:07.673	Scheduler startup	SYSTEM	NONE	NONE	\N	\N	2018-03-28 09:31:07.668	\N
82	bL7agTNQwCY	1	2018-03-29 08:40:14.836	2018-03-29 08:40:14.836	Scheduler startup	SYSTEM	NONE	NONE	\N	\N	2018-03-29 08:40:14.83	\N
84	E5uvEZeR9uL	1	2018-03-30 09:20:48.938	2018-03-30 09:20:48.938	Scheduler startup	SYSTEM	NONE	NONE	\N	\N	2018-03-30 09:20:48.932	\N
86	JQe7YfKu58Z	1	2018-03-30 23:03:17.926	2018-03-30 23:03:17.926	Scheduler startup	SYSTEM	NONE	NONE	\N	\N	2018-03-30 23:03:17.92	\N
88	kcL3t6Agetz	1	2018-04-01 00:43:51.734	2018-04-01 00:43:51.734	Scheduler startup	SYSTEM	NONE	NONE	\N	\N	2018-04-01 00:43:51.728	\N
90	xAQXzYzQd7F	1	2018-04-01 10:51:17.923	2018-04-01 10:51:17.923	Scheduler startup	SYSTEM	NONE	NONE	\N	\N	2018-04-01 10:51:17.917	\N
92	jCOQslLQk9x	1	2018-04-01 18:07:00.832	2018-04-01 18:07:00.832	Scheduler startup	SYSTEM	NONE	NONE	\N	\N	2018-04-01 18:07:00.826	\N
97	mLiFnH3c9GU	1	2018-04-02 09:18:55.132	2018-04-02 09:18:55.132	Scheduler startup	SYSTEM	NONE	NONE	\N	\N	2018-04-02 09:18:55.127	\N
99	mwAps6spq5C	1	2018-04-02 17:02:02.258	2018-04-02 17:02:02.258	Scheduler startup	SYSTEM	NONE	NONE	\N	\N	2018-04-02 17:02:02.249	\N
101	GZHToxfh6ze	1	2018-04-02 23:01:38.965	2018-04-02 23:01:38.966	Scheduler startup	SYSTEM	NONE	NONE	\N	\N	2018-04-02 23:01:38.956	\N
103	FzQsoqpbXVx	1	2018-04-03 07:52:05.468	2018-04-03 07:52:05.468	Scheduler startup	SYSTEM	NONE	NONE	\N	\N	2018-04-03 07:52:05.462	\N
111	CHBvIIzx3M1	1	2018-04-03 22:43:45.103	2018-04-03 22:43:45.103	Scheduler startup	SYSTEM	NONE	NONE	\N	\N	2018-04-03 22:43:45.097	\N
\.


--
-- Data for Name: messageconversation_messages; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.messageconversation_messages (messageconversationid, sort_order, messageid) FROM stdin;
78	1	79
82	1	83
84	1	85
86	1	87
88	1	89
90	1	91
92	1	93
97	1	98
99	1	100
101	1	102
103	1	104
111	1	112
\.


--
-- Data for Name: messageconversation_usermessages; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.messageconversation_usermessages (messageconversationid, usermessageid) FROM stdin;
\.


--
-- Data for Name: metadataaudit; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.metadataaudit (metadataauditid, created_at, created_by, klass, uid, code, type, value) FROM stdin;
\.


--
-- Data for Name: metadataversion; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.metadataversion (versionid, uid, code, created, lastupdated, lastupdatedby, name, versiontype, importdate, hashcode) FROM stdin;
\.


--
-- Data for Name: minmaxdataelement; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.minmaxdataelement (minmaxdataelementid, sourceid, dataelementid, categoryoptioncomboid, minimumvalue, maximumvalue, generatedvalue) FROM stdin;
\.


--
-- Data for Name: oauth2client; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.oauth2client (oauth2clientid, uid, code, created, lastupdated, lastupdatedby, name, cid, secret) FROM stdin;
\.


--
-- Data for Name: oauth2clientgranttypes; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.oauth2clientgranttypes (oauth2clientid, sort_order, granttype) FROM stdin;
\.


--
-- Data for Name: oauth2clientredirecturis; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.oauth2clientredirecturis (oauth2clientid, sort_order, redirecturi) FROM stdin;
\.


--
-- Data for Name: oauth_access_token; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.oauth_access_token (token_id, token, authentication_id, user_name, client_id, authentication, refresh_token) FROM stdin;
\.


--
-- Data for Name: oauth_code; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.oauth_code (code, authentication) FROM stdin;
\.


--
-- Data for Name: oauth_refresh_token; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.oauth_refresh_token (token_id, token, authentication) FROM stdin;
\.


--
-- Data for Name: objecttranslation; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.objecttranslation (objecttranslationid, locale, property, value) FROM stdin;
\.


--
-- Data for Name: optionattributevalues; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.optionattributevalues (optionvalueid, attributevalueid) FROM stdin;
72	113
72	114
72	115
107	117
107	118
107	116
\.


--
-- Data for Name: optiongroup; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.optiongroup (optiongroupid, uid, code, created, lastupdated, lastupdatedby, name, shortname, userid, publicaccess) FROM stdin;
\.


--
-- Data for Name: optiongroupattributevalues; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.optiongroupattributevalues (optiongroupid, attributevalueid) FROM stdin;
\.


--
-- Data for Name: optiongroupmembers; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.optiongroupmembers (optiongroupid, optionid) FROM stdin;
\.


--
-- Data for Name: optiongroupset; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.optiongroupset (optiongroupsetid, uid, code, created, lastupdated, lastupdatedby, name, description, datadimension, optionsetid, userid, publicaccess) FROM stdin;
\.


--
-- Data for Name: optiongroupsetmembers; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.optiongroupsetmembers (optiongroupsetid, sort_order, optiongroupid) FROM stdin;
\.


--
-- Data for Name: optiongroupsettranslations; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.optiongroupsettranslations (optiongroupsetid, objecttranslationid) FROM stdin;
\.


--
-- Data for Name: optiongroupsetuseraccesses; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.optiongroupsetuseraccesses (optiongroupsetid, useraccessid) FROM stdin;
\.


--
-- Data for Name: optiongroupsetusergroupaccesses; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.optiongroupsetusergroupaccesses (optiongroupsetid, usergroupaccessid) FROM stdin;
\.


--
-- Data for Name: optiongrouptranslations; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.optiongrouptranslations (optiongroupid, objecttranslationid) FROM stdin;
\.


--
-- Data for Name: optiongroupuseraccesses; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.optiongroupuseraccesses (optiongroupid, useraccessid) FROM stdin;
\.


--
-- Data for Name: optiongroupusergroupaccesses; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.optiongroupusergroupaccesses (optiongroupid, usergroupaccessid) FROM stdin;
\.


--
-- Data for Name: optionset; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.optionset (optionsetid, uid, code, created, lastupdated, lastupdatedby, name, valuetype, version, userid, publicaccess) FROM stdin;
66	EHSUGTRBDJg	\N	2018-02-25 17:43:40.216	2018-03-27 22:14:24.819	57	Product Group LV1	TEXT	4	57	rw------
67	dRIoqZkab64	\N	2018-02-25 23:26:51.826	2018-03-27 22:14:24.822	57	Product Group LV2	TEXT	4	57	rw------
68	jdIlO23DnSE	\N	2018-02-25 23:32:50.061	2018-03-27 22:14:24.823	57	Product Group LV3	TEXT	4	57	rw------
65	LIc6avjZYTm	\N	2018-02-24 15:38:36.553	2018-04-03 16:59:03.753	57	Product	LONG_TEXT	5	57	rw------
\.


--
-- Data for Name: optionsetattributevalues; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.optionsetattributevalues (optionsetid, attributevalueid) FROM stdin;
\.


--
-- Data for Name: optionsettranslations; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.optionsettranslations (optionsetid, objecttranslationid) FROM stdin;
\.


--
-- Data for Name: optionsetuseraccesses; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.optionsetuseraccesses (optionsetid, useraccessid) FROM stdin;
\.


--
-- Data for Name: optionsetusergroupaccesses; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.optionsetusergroupaccesses (optionsetid, usergroupaccessid) FROM stdin;
\.


--
-- Data for Name: optionvalue; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.optionvalue (optionvalueid, uid, code, name, created, lastupdated, sort_order, description, formname, style, optionsetid) FROM stdin;
73	o3lYGrhAWcY	TH1	Thit heo	2018-02-25 23:24:56.182	2018-03-27 22:14:31.788	1	\N	\N	\N	66
74	iAu0QN0M5T6	THM	Thịt Heo Mỡ	2018-02-25 23:27:47.707	2018-03-27 22:14:31.788	2	\N	\N	\N	67
75	By7WqquyYu7	THN	Thit Heo Nạc	2018-02-25 23:27:34.142	2018-03-27 22:14:31.788	1	\N	\N	\N	67
76	qr1hCEjOE4P	3-THN1	Thit Heo Nạc Loại 1	2018-02-25 23:34:13.793	2018-03-27 22:14:31.788	1	\N	\N	\N	68
77	fiMt8XgY1WS	3-THN2	Thit Heo Nạc Loại 2	2018-02-25 23:34:38.895	2018-03-27 22:14:31.788	2	\N	\N	\N	68
72	M3nqwbHRLq7	MBP	MacBook Pro 15-inch with Touch Bar 2017	2018-02-24 15:41:30.846	2018-04-04 00:25:07.126	1	\N	\N	\N	65
107	FFDIqEtjiBO	MBP13	MacBook Pro 13-inch with Touch Bar 2017	2018-04-03 16:59:03.41	2018-04-04 00:25:38.58	2	\N	\N	\N	65
\.


--
-- Data for Name: optionvaluetranslations; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.optionvaluetranslations (optionvalueid, objecttranslationid) FROM stdin;
\.


--
-- Data for Name: organisationunit; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.organisationunit (organisationunitid, uid, code, created, lastupdated, lastupdatedby, name, shortname, parentid, path, hierarchylevel, description, openingdate, closeddate, comment, featuretype, coordinates, url, contactperson, address, email, phonenumber, userid) FROM stdin;
\.


--
-- Data for Name: organisationunitattributevalues; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.organisationunitattributevalues (organisationunitid, attributevalueid) FROM stdin;
\.


--
-- Data for Name: organisationunittranslations; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.organisationunittranslations (organisationunitid, objecttranslationid) FROM stdin;
\.


--
-- Data for Name: orgunitgroup; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.orgunitgroup (orgunitgroupid, uid, code, created, lastupdated, lastupdatedby, name, shortname, symbol, color, coordinates, userid, publicaccess) FROM stdin;
\.


--
-- Data for Name: orgunitgroupattributevalues; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.orgunitgroupattributevalues (orgunitgroupid, attributevalueid) FROM stdin;
\.


--
-- Data for Name: orgunitgroupmembers; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.orgunitgroupmembers (organisationunitid, orgunitgroupid) FROM stdin;
\.


--
-- Data for Name: orgunitgroupset; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.orgunitgroupset (orgunitgroupsetid, uid, code, created, lastupdated, lastupdatedby, name, description, compulsory, includesubhierarchyinanalytics, datadimension, userid, publicaccess) FROM stdin;
\.


--
-- Data for Name: orgunitgroupsetattributevalues; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.orgunitgroupsetattributevalues (orgunitgroupsetid, attributevalueid) FROM stdin;
\.


--
-- Data for Name: orgunitgroupsetdimension; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.orgunitgroupsetdimension (orgunitgroupsetdimensionid, orgunitgroupsetid) FROM stdin;
\.


--
-- Data for Name: orgunitgroupsetdimension_items; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.orgunitgroupsetdimension_items (orgunitgroupsetdimensionid, sort_order, orgunitgroupid) FROM stdin;
\.


--
-- Data for Name: orgunitgroupsetmembers; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.orgunitgroupsetmembers (orgunitgroupsetid, orgunitgroupid) FROM stdin;
\.


--
-- Data for Name: orgunitgroupsettranslations; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.orgunitgroupsettranslations (orgunitgroupsetid, objecttranslationid) FROM stdin;
\.


--
-- Data for Name: orgunitgroupsetuseraccesses; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.orgunitgroupsetuseraccesses (orgunitgroupsetid, useraccessid) FROM stdin;
\.


--
-- Data for Name: orgunitgroupsetusergroupaccesses; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.orgunitgroupsetusergroupaccesses (orgunitgroupsetid, usergroupaccessid) FROM stdin;
\.


--
-- Data for Name: orgunitgrouptranslations; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.orgunitgrouptranslations (orgunitgroupid, objecttranslationid) FROM stdin;
\.


--
-- Data for Name: orgunitgroupuseraccesses; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.orgunitgroupuseraccesses (orgunitgroupid, useraccessid) FROM stdin;
\.


--
-- Data for Name: orgunitgroupusergroupaccesses; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.orgunitgroupusergroupaccesses (orgunitgroupid, usergroupaccessid) FROM stdin;
\.


--
-- Data for Name: orgunitlevel; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.orgunitlevel (orgunitlevelid, uid, code, created, lastupdated, lastupdatedby, name, level, offlinelevels) FROM stdin;
\.


--
-- Data for Name: orgunitleveltranslations; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.orgunitleveltranslations (orgunitlevelid, objecttranslationid) FROM stdin;
\.


--
-- Data for Name: outbound_sms; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.outbound_sms (id, date, message, status, sender) FROM stdin;
\.


--
-- Data for Name: outbound_sms_recipients; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.outbound_sms_recipients (outbound_sms_id, elt) FROM stdin;
\.


--
-- Data for Name: period; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.period (periodid, periodtypeid, startdate, enddate) FROM stdin;
\.


--
-- Data for Name: periodtype; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.periodtype (periodtypeid, name) FROM stdin;
1	Daily
2	Weekly
3	WeeklyWednesday
4	WeeklyThursday
5	WeeklySaturday
6	WeeklySunday
7	BiWeekly
8	Monthly
9	BiMonthly
10	Quarterly
11	SixMonthly
12	SixMonthlyApril
13	Yearly
14	FinancialApril
15	FinancialJuly
16	FinancialOct
\.


--
-- Data for Name: predictor; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.predictor (predictorid, uid, code, created, lastupdated, lastupdatedby, name, description, generatorexpressionid, generatoroutput, generatoroutputcombo, skiptestexpressionid, periodtypeid, sequentialsamplecount, annualsamplecount, sequentialskipcount) FROM stdin;
\.


--
-- Data for Name: predictororgunitlevels; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.predictororgunitlevels (predictorid, orgunitlevelid) FROM stdin;
\.


--
-- Data for Name: previouspasswords; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.previouspasswords (userid, list_index, previouspassword) FROM stdin;
57	0	$2a$10$0mTaNa9zTsK9iJHILSycw.oXK9a8.wPTEdQ22enLdqxKtKYFHZ0yK
\.


--
-- Data for Name: program; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.program (programid, uid, code, created, lastupdated, lastupdatedby, name, shortname, description, formname, version, enrollmentdatelabel, incidentdatelabel, type, displayincidentdate, onlyenrollonce, skipoffline, displayfrontpagelist, usefirststageduringregistration, capturecoordinates, expirydays, completeeventsexpirydays, minattributesrequiredtosearch, maxteicounttoreturn, style, expiryperiodtypeid, ignoreoverdueevents, selectenrollmentdatesinfuture, selectincidentdatesinfuture, relationshiptext, relationshiptypeid, relationshipfroma, relatedprogramid, categorycomboid, trackedentitytypeid, dataentryformid, workflowid, userid, publicaccess) FROM stdin;
\.


--
-- Data for Name: program_attribute_group; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.program_attribute_group (programtrackedentityattributegroupid, uid, code, created, lastupdated, lastupdatedby, name, shortname, description, uniqunessype) FROM stdin;
\.


--
-- Data for Name: program_attributes; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.program_attributes (programtrackedentityattributeid, uid, code, created, lastupdated, lastupdatedby, programid, trackedentityattributeid, displayinlist, mandatory, sort_order, allowfuturedate, renderoptionsasradio, rendertype, searchable) FROM stdin;
\.


--
-- Data for Name: program_criteria; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.program_criteria (programid, validationcriteriaid) FROM stdin;
\.


--
-- Data for Name: program_organisationunits; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.program_organisationunits (organisationunitid, programid) FROM stdin;
\.


--
-- Data for Name: program_userroles; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.program_userroles (programid, userroleid) FROM stdin;
\.


--
-- Data for Name: programattributevalues; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.programattributevalues (programid, attributevalueid) FROM stdin;
\.


--
-- Data for Name: programexpression; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.programexpression (programexpressionid, description, expression) FROM stdin;
\.


--
-- Data for Name: programindicator; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.programindicator (programindicatorid, uid, code, created, lastupdated, lastupdatedby, name, shortname, description, formname, style, programid, expression, filter, aggregationtype, decimals, aggregateexportcategoryoptioncombo, aggregateexportattributeoptioncombo, displayinform, analyticstype, userid, publicaccess) FROM stdin;
\.


--
-- Data for Name: programindicatorattributevalues; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.programindicatorattributevalues (programindicatorid, attributevalueid) FROM stdin;
\.


--
-- Data for Name: programindicatorgroup; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.programindicatorgroup (programindicatorgroupid, uid, code, created, lastupdated, lastupdatedby, name, description, userid, publicaccess) FROM stdin;
\.


--
-- Data for Name: programindicatorgroupattributevalues; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.programindicatorgroupattributevalues (programindicatorgroupid, attributevalueid) FROM stdin;
\.


--
-- Data for Name: programindicatorgroupmembers; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.programindicatorgroupmembers (programindicatorgroupid, programindicatorid) FROM stdin;
\.


--
-- Data for Name: programindicatorgrouptranslations; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.programindicatorgrouptranslations (programindicatorgroupid, objecttranslationid) FROM stdin;
\.


--
-- Data for Name: programindicatorgroupuseraccesses; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.programindicatorgroupuseraccesses (programindicatorgroupid, useraccessid) FROM stdin;
\.


--
-- Data for Name: programindicatorgroupusergroupaccesses; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.programindicatorgroupusergroupaccesses (programindicatorgroupid, usergroupaccessid) FROM stdin;
\.


--
-- Data for Name: programindicatorlegendsets; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.programindicatorlegendsets (programindicatorid, sort_order, legendsetid) FROM stdin;
\.


--
-- Data for Name: programindicatortranslations; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.programindicatortranslations (programindicatorid, objecttranslationid) FROM stdin;
\.


--
-- Data for Name: programindicatoruseraccesses; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.programindicatoruseraccesses (programindicatorid, useraccessid) FROM stdin;
\.


--
-- Data for Name: programindicatorusergroupaccesses; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.programindicatorusergroupaccesses (programindicatorid, usergroupaccessid) FROM stdin;
\.


--
-- Data for Name: programinstance; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.programinstance (programinstanceid, uid, created, lastupdated, createdatclient, lastupdatedatclient, incidentdate, enrollmentdate, enddate, followup, completedby, longitude, latitude, deleted, storedby, status, trackedentityinstanceid, programid, organisationunitid) FROM stdin;
\.


--
-- Data for Name: programinstance_messageconversation; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.programinstance_messageconversation (programinstanceid, sort_order, messageconversationid) FROM stdin;
\.


--
-- Data for Name: programinstancecomments; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.programinstancecomments (programinstanceid, sort_order, trackedentitycommentid) FROM stdin;
\.


--
-- Data for Name: programmessage; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.programmessage (id, uid, code, created, lastupdated, lastupdatedby, text, subject, processeddate, messagestatus, trackedentityinstanceid, organisationunitid, programinstanceid, programstageinstanceid) FROM stdin;
\.


--
-- Data for Name: programmessage_deliverychannels; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.programmessage_deliverychannels (programmessagedeliverychannelsid, deliverychannel) FROM stdin;
\.


--
-- Data for Name: programmessage_emailaddresses; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.programmessage_emailaddresses (programmessageemailaddressid, email) FROM stdin;
\.


--
-- Data for Name: programmessage_phonenumbers; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.programmessage_phonenumbers (programmessagephonenumberid, phonenumber) FROM stdin;
\.


--
-- Data for Name: programmessagetranslations; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.programmessagetranslations (id, objecttranslationid) FROM stdin;
\.


--
-- Data for Name: programnotificationtemplate; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.programnotificationtemplate (programnotificationtemplateid, uid, code, created, lastupdated, lastupdatedby, name, relativescheduleddays, usergroupid, trackedentityattributeid, dataelementid, subjecttemplate, messagetemplate, notificationtrigger, notificationrecipienttype, programstageid, programid) FROM stdin;
\.


--
-- Data for Name: programnotificationtemplate_deliverychannel; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.programnotificationtemplate_deliverychannel (programnotificationtemplatedeliverychannelid, deliverychannel) FROM stdin;
\.


--
-- Data for Name: programrule; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.programrule (programruleid, uid, code, created, lastupdated, lastupdatedby, name, description, programid, programstageid, rulecondition, priority) FROM stdin;
\.


--
-- Data for Name: programruleaction; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.programruleaction (programruleactionid, uid, code, created, lastupdated, lastupdatedby, programruleid, actiontype, dataelementid, trackedentityattributeid, programindicatorid, programstagesectionid, programstageid, programnotificationtemplateid, location, content, data) FROM stdin;
\.


--
-- Data for Name: programruletranslations; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.programruletranslations (programruleid, objecttranslationid) FROM stdin;
\.


--
-- Data for Name: programrulevariable; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.programrulevariable (programrulevariableid, uid, code, created, lastupdated, lastupdatedby, name, programid, sourcetype, trackedentityattributeid, dataelementid, usecodeforoptionset, programstageid) FROM stdin;
\.


--
-- Data for Name: programsection; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.programsection (programsectionid, uid, code, created, lastupdated, lastupdatedby, name, description, formname, style, rendertype, programid, sortorder) FROM stdin;
\.


--
-- Data for Name: programsection_attributes; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.programsection_attributes (programsectionid, sort_order, trackedentityattributeid) FROM stdin;
\.


--
-- Data for Name: programsectiontranslations; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.programsectiontranslations (programsectionid, objecttranslationid) FROM stdin;
\.


--
-- Data for Name: programstage; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.programstage (programstageid, uid, code, created, lastupdated, lastupdatedby, name, description, formname, mindaysfromstart, programid, repeatable, dataentryformid, standardinterval, executiondatelabel, duedatelabel, autogenerateevent, validcompleteonly, displaygenerateeventbox, capturecoordinates, generatedbyenrollmentdate, blockentryform, remindcompleted, allowgeneratenextvisit, openafterenrollment, reportdatetouse, pregenerateuid, style, hideduedate, sort_order, periodtypeid, userid, publicaccess) FROM stdin;
\.


--
-- Data for Name: programstageattributevalues; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.programstageattributevalues (programstageid, attributevalueid) FROM stdin;
\.


--
-- Data for Name: programstagedataelement; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.programstagedataelement (programstagedataelementid, uid, code, created, lastupdated, lastupdatedby, programstageid, dataelementid, compulsory, allowprovidedelsewhere, sort_order, displayinreports, allowfuturedate, renderoptionsasradio, rendertype) FROM stdin;
\.


--
-- Data for Name: programstageinstance; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.programstageinstance (programstageinstanceid, uid, code, created, lastupdated, createdatclient, lastupdatedatclient, programinstanceid, programstageid, attributeoptioncomboid, deleted, storedby, duedate, executiondate, organisationunitid, status, longitude, latitude, completedby, completeddate) FROM stdin;
\.


--
-- Data for Name: programstageinstance_messageconversation; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.programstageinstance_messageconversation (programstageinstanceid, sort_order, messageconversationid) FROM stdin;
\.


--
-- Data for Name: programstageinstancecomments; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.programstageinstancecomments (programstageinstanceid, sort_order, trackedentitycommentid) FROM stdin;
\.


--
-- Data for Name: programstagesection; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.programstagesection (programstagesectionid, uid, code, created, lastupdated, lastupdatedby, name, description, formname, style, rendertype, programstageid, sortorder) FROM stdin;
\.


--
-- Data for Name: programstagesection_dataelements; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.programstagesection_dataelements (programstagesectionid, sort_order, dataelementid) FROM stdin;
\.


--
-- Data for Name: programstagesection_programindicators; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.programstagesection_programindicators (programstagesectionid, sort_order, programindicatorid) FROM stdin;
\.


--
-- Data for Name: programstagesectiontranslations; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.programstagesectiontranslations (programstagesectionid, objecttranslationid) FROM stdin;
\.


--
-- Data for Name: programstagetranslations; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.programstagetranslations (programstageid, objecttranslationid) FROM stdin;
\.


--
-- Data for Name: programstageuseraccesses; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.programstageuseraccesses (programstageid, useraccessid) FROM stdin;
\.


--
-- Data for Name: programstageusergroupaccesses; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.programstageusergroupaccesses (programid, usergroupaccessid) FROM stdin;
\.


--
-- Data for Name: programtrackedentityattributegroupmembers; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.programtrackedentityattributegroupmembers (programtrackedentityattributegroupid, programtrackedentityattributeid) FROM stdin;
\.


--
-- Data for Name: programtrackedentityattributegrouptranslations; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.programtrackedentityattributegrouptranslations (programtrackedentityattributegroupid, objecttranslationid) FROM stdin;
\.


--
-- Data for Name: programtranslations; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.programtranslations (programid, objecttranslationid) FROM stdin;
\.


--
-- Data for Name: programuseraccesses; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.programuseraccesses (programid, useraccessid) FROM stdin;
\.


--
-- Data for Name: programusergroupaccesses; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.programusergroupaccesses (programid, usergroupaccessid) FROM stdin;
\.


--
-- Data for Name: pushanalysis; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.pushanalysis (pushanalysisid, uid, code, created, lastupdated, lastupdatedby, name, title, message, enabled, schedulingdayoffrequency, schedulingfrequency, dashboard) FROM stdin;
\.


--
-- Data for Name: pushanalysisrecipientusergroups; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.pushanalysisrecipientusergroups (usergroupid, elt) FROM stdin;
\.


--
-- Data for Name: relationship; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.relationship (relationshipid, formname, description, style, trackedentityinstanceaid, relationshiptypeid, trackedentityinstancebid) FROM stdin;
\.


--
-- Data for Name: relationshiptype; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.relationshiptype (relationshiptypeid, uid, code, created, lastupdated, lastupdatedby, name, a_is_to_b, b_is_to_a) FROM stdin;
\.


--
-- Data for Name: relationshiptypetranslations; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.relationshiptypetranslations (relationshiptypeid, objecttranslationid) FROM stdin;
\.


--
-- Data for Name: relativeperiods; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.relativeperiods (relativeperiodsid, thisday, yesterday, last3days, last7days, last14days, thismonth, lastmonth, thisbimonth, lastbimonth, thisquarter, lastquarter, thissixmonth, lastsixmonth, weeksthisyear, monthsthisyear, bimonthsthisyear, quartersthisyear, thisyear, monthslastyear, quarterslastyear, lastyear, last5years, last12months, last6months, last3months, last6bimonths, last4quarters, last2sixmonths, thisfinancialyear, lastfinancialyear, last5financialyears, thisweek, lastweek, thisbiweek, lastbiweek, last4weeks, last4biweeks, last12weeks, last52weeks) FROM stdin;
\.


--
-- Data for Name: report; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.report (reportid, uid, code, created, lastupdated, lastupdatedby, name, type, designcontent, reporttableid, relativeperiodsid, paramreportingmonth, paramorganisationunit, cachestrategy, externalaccess, userid, publicaccess) FROM stdin;
\.


--
-- Data for Name: reporttable; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.reporttable (reporttableid, uid, code, created, lastupdated, lastupdatedby, name, description, measurecriteria, regression, cumulative, relativeperiodsid, paramreportingmonth, paramgrandparentorganisationunit, paramparentorganisationunit, paramorganisationunit, sortorder, toplimit, rowtotals, coltotals, rowsubtotals, colsubtotals, hideemptyrows, hideemptycolumns, aggregationtype, completedonly, title, subtitle, hidetitle, hidesubtitle, digitgroupseparator, displaydensity, fontsize, userorganisationunit, userorganisationunitchildren, userorganisationunitgrandchildren, legendsetid, legenddisplaystyle, legenddisplaystrategy, numbertype, showhierarchy, showdimensionlabels, skiprounding, externalaccess, userid, publicaccess, favorites) FROM stdin;
\.


--
-- Data for Name: reporttable_categorydimensions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.reporttable_categorydimensions (reporttableid, sort_order, categorydimensionid) FROM stdin;
\.


--
-- Data for Name: reporttable_categoryoptiongroupsetdimensions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.reporttable_categoryoptiongroupsetdimensions (reporttableid, sort_order, categoryoptiongroupsetdimensionid) FROM stdin;
\.


--
-- Data for Name: reporttable_columns; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.reporttable_columns (reporttableid, sort_order, dimension) FROM stdin;
\.


--
-- Data for Name: reporttable_datadimensionitems; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.reporttable_datadimensionitems (reporttableid, sort_order, datadimensionitemid) FROM stdin;
\.


--
-- Data for Name: reporttable_dataelementgroupsetdimensions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.reporttable_dataelementgroupsetdimensions (reporttableid, sort_order, dataelementgroupsetdimensionid) FROM stdin;
\.


--
-- Data for Name: reporttable_filters; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.reporttable_filters (reporttableid, sort_order, dimension) FROM stdin;
\.


--
-- Data for Name: reporttable_itemorgunitgroups; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.reporttable_itemorgunitgroups (reporttableid, sort_order, orgunitgroupid) FROM stdin;
\.


--
-- Data for Name: reporttable_organisationunits; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.reporttable_organisationunits (reporttableid, sort_order, organisationunitid) FROM stdin;
\.


--
-- Data for Name: reporttable_orgunitgroupsetdimensions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.reporttable_orgunitgroupsetdimensions (reporttableid, sort_order, orgunitgroupsetdimensionid) FROM stdin;
\.


--
-- Data for Name: reporttable_orgunitlevels; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.reporttable_orgunitlevels (reporttableid, sort_order, orgunitlevel) FROM stdin;
\.


--
-- Data for Name: reporttable_periods; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.reporttable_periods (reporttableid, sort_order, periodid) FROM stdin;
\.


--
-- Data for Name: reporttable_rows; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.reporttable_rows (reporttableid, sort_order, dimension) FROM stdin;
\.


--
-- Data for Name: reporttabletranslations; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.reporttabletranslations (reporttableid, objecttranslationid) FROM stdin;
\.


--
-- Data for Name: reporttableuseraccesses; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.reporttableuseraccesses (reporttableid, useraccessid) FROM stdin;
\.


--
-- Data for Name: reporttableusergroupaccesses; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.reporttableusergroupaccesses (reporttableid, usergroupaccessid) FROM stdin;
\.


--
-- Data for Name: reporttranslations; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.reporttranslations (reportid, objecttranslationid) FROM stdin;
\.


--
-- Data for Name: reportuseraccesses; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.reportuseraccesses (reportid, useraccessid) FROM stdin;
\.


--
-- Data for Name: reportusergroupaccesses; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.reportusergroupaccesses (reportid, usergroupaccessid) FROM stdin;
\.


--
-- Data for Name: reservedvalue; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.reservedvalue (reservedvalueid, expirydate, created, ownerobject, owneruid, key, value) FROM stdin;
\.


--
-- Data for Name: section; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.section (sectionid, uid, code, created, lastupdated, lastupdatedby, name, description, datasetid, sortorder, showrowtotals, showcolumntotals) FROM stdin;
\.


--
-- Data for Name: sectionattributevalues; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.sectionattributevalues (sectionid, attributevalueid) FROM stdin;
\.


--
-- Data for Name: sectiondataelements; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.sectiondataelements (sectionid, sort_order, dataelementid) FROM stdin;
\.


--
-- Data for Name: sectiongreyedfields; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.sectiongreyedfields (sectionid, dataelementoperandid) FROM stdin;
\.


--
-- Data for Name: sectionindicators; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.sectionindicators (sectionid, sort_order, indicatorid) FROM stdin;
\.


--
-- Data for Name: sequentialnumbercounter; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.sequentialnumbercounter (id, owneruid, key, counter) FROM stdin;
\.


--
-- Data for Name: smscodes; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.smscodes (smscodeid, code, formula, compulsory, dataelementid, trackedentityattributeid, optionid) FROM stdin;
\.


--
-- Data for Name: smscommandcodes; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.smscommandcodes (id, codeid) FROM stdin;
\.


--
-- Data for Name: smscommands; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.smscommands (smscommandid, uid, created, lastupdated, name, parsertype, separatorkey, codeseparator, defaultmessage, receivedmessage, wrongformatmessage, nousermessage, morethanoneorgunitmessage, successmessage, currentperiodusedforreporting, completenessmethod, datasetid, usergroupid, programid, programstageid) FROM stdin;
\.


--
-- Data for Name: smscommandspecialcharacters; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.smscommandspecialcharacters (smscommandid, specialcharacterid) FROM stdin;
\.


--
-- Data for Name: smsspecialcharacter; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.smsspecialcharacter (specialcharacterid, name, value) FROM stdin;
\.


--
-- Data for Name: sqlview; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.sqlview (sqlviewid, uid, code, created, lastupdated, lastupdatedby, name, description, sqlquery, type, cachestrategy, externalaccess, userid, publicaccess) FROM stdin;
\.


--
-- Data for Name: sqlviewattributevalues; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.sqlviewattributevalues (sqlviewid, attributevalueid) FROM stdin;
\.


--
-- Data for Name: sqlviewuseraccesses; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.sqlviewuseraccesses (sqlviewid, useraccessid) FROM stdin;
\.


--
-- Data for Name: sqlviewusergroupaccesses; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.sqlviewusergroupaccesses (sqlviewid, usergroupaccessid) FROM stdin;
\.


--
-- Data for Name: systemsetting; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.systemsetting (systemsettingid, name, value) FROM stdin;
80	keyRemoteInstanceUsername	\\xaced000574000561646d696e
81	keyRemoteInstancePassword	\\xaced0005740018634c67645351654577697a4770517a5a643354524a513d3d
\.


--
-- Data for Name: tablehook; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.tablehook (analyticstablehookid, uid, code, created, lastupdated, lastupdatedby, name, analyticstablephase, resourcetabletype, analyticstabletype, sql) FROM stdin;
\.


--
-- Data for Name: trackedentityattribute; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.trackedentityattribute (trackedentityattributeid, uid, code, created, lastupdated, lastupdatedby, name, shortname, description, formname, valuetype, aggregationtype, optionsetid, inherit, expression, displayonvisitschedule, sortorderinvisitschedule, displayinlistnoprogram, sortorderinlistnoprogram, confidential, uniquefield, generated, pattern, textpattern, style, orgunitscope, programscope, userid, publicaccess) FROM stdin;
\.


--
-- Data for Name: trackedentityattributeattributevalues; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.trackedentityattributeattributevalues (trackedentityattributeid, attributevalueid) FROM stdin;
\.


--
-- Data for Name: trackedentityattributedimension; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.trackedentityattributedimension (trackedentityattributedimensionid, trackedentityattributeid, legendsetid, filter) FROM stdin;
\.


--
-- Data for Name: trackedentityattributelegendsets; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.trackedentityattributelegendsets (trackedentityattributeid, sort_order, legendsetid) FROM stdin;
\.


--
-- Data for Name: trackedentityattributetranslations; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.trackedentityattributetranslations (trackedentityattributeid, objecttranslationid) FROM stdin;
\.


--
-- Data for Name: trackedentityattributeuseraccesses; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.trackedentityattributeuseraccesses (trackedentityattributeid, useraccessid) FROM stdin;
\.


--
-- Data for Name: trackedentityattributeusergroupaccesses; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.trackedentityattributeusergroupaccesses (trackedentityattributeid, usergroupaccessid) FROM stdin;
\.


--
-- Data for Name: trackedentityattributevalue; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.trackedentityattributevalue (trackedentityinstanceid, trackedentityattributeid, created, lastupdated, value, encryptedvalue, storedby) FROM stdin;
\.


--
-- Data for Name: trackedentityattributevalueaudit; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.trackedentityattributevalueaudit (trackedentityattributevalueauditid, trackedentityinstanceid, trackedentityattributeid, value, encryptedvalue, created, modifiedby, audittype) FROM stdin;
\.


--
-- Data for Name: trackedentitycomment; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.trackedentitycomment (trackedentitycommentid, commenttext, createddate, creator) FROM stdin;
\.


--
-- Data for Name: trackedentitydataelementdimension; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.trackedentitydataelementdimension (trackedentitydataelementdimensionid, dataelementid, legendsetid, filter) FROM stdin;
\.


--
-- Data for Name: trackedentitydatavalue; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.trackedentitydatavalue (programstageinstanceid, dataelementid, value, created, lastupdated, providedelsewhere, storedby) FROM stdin;
\.


--
-- Data for Name: trackedentitydatavalueaudit; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.trackedentitydatavalueaudit (trackedentitydatavalueauditid, programstageinstanceid, dataelementid, value, created, providedelsewhere, modifiedby, audittype) FROM stdin;
\.


--
-- Data for Name: trackedentityinstance; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.trackedentityinstance (trackedentityinstanceid, uid, code, created, lastupdated, lastupdatedby, createdatclient, lastupdatedatclient, inactive, deleted, featuretype, coordinates, representativeid, organisationunitid, trackedentitytypeid) FROM stdin;
\.


--
-- Data for Name: trackedentityinstancefilter; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.trackedentityinstancefilter (trackedentityinstancefilterid, uid, code, created, lastupdated, lastupdatedby, name, description, sortorder, style, programid, enrollmentstatus, followup, enrollmentcreatedperiod, eventfilters) FROM stdin;
\.


--
-- Data for Name: trackedentityprogramindicatordimension; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.trackedentityprogramindicatordimension (trackedentityprogramindicatordimensionid, programindicatorid, legendsetid, filter) FROM stdin;
\.


--
-- Data for Name: trackedentitytranslations; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.trackedentitytranslations (trackedentitytypeid, objecttranslationid) FROM stdin;
\.


--
-- Data for Name: trackedentitytype; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.trackedentitytype (trackedentitytypeid, uid, code, created, lastupdated, lastupdatedby, name, description, formname, style, minattributesrequiredtosearch, maxteicounttoreturn, userid, publicaccess) FROM stdin;
21	MCPQUTHX1Ze	Person	2018-03-27 00:00:00	2018-03-27 00:00:00	\N	Person	Person	\N	\N	1	0	\N	rwrw----
\.


--
-- Data for Name: trackedentitytypeattribute; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.trackedentitytypeattribute (trackedentitytypeattributeid, uid, code, created, lastupdated, lastupdatedby, trackedentitytypeid, trackedentityattributeid, displayinlist, mandatory, searchable, sort_order) FROM stdin;
\.


--
-- Data for Name: trackedentitytypeattributevalues; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.trackedentitytypeattributevalues (trackedentitytypeid, attributevalueid) FROM stdin;
\.


--
-- Data for Name: trackedentitytypeuseraccesses; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.trackedentitytypeuseraccesses (trackedentitytypeid, useraccessid) FROM stdin;
\.


--
-- Data for Name: trackedentitytypeusergroupaccesses; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.trackedentitytypeusergroupaccesses (trackedentitytypeid, usergroupaccessid) FROM stdin;
\.


--
-- Data for Name: useraccess; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.useraccess (useraccessid, access, userid) FROM stdin;
\.


--
-- Data for Name: userapps; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.userapps (userinfoid, sort_order, app) FROM stdin;
\.


--
-- Data for Name: userattributevalues; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.userattributevalues (userinfoid, attributevalueid) FROM stdin;
\.


--
-- Data for Name: userdatavieworgunits; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.userdatavieworgunits (userinfoid, organisationunitid) FROM stdin;
\.


--
-- Data for Name: usergroup; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.usergroup (usergroupid, uid, code, created, lastupdated, lastupdatedby, name, userid, publicaccess) FROM stdin;
\.


--
-- Data for Name: usergroupaccess; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.usergroupaccess (usergroupaccessid, access, usergroupid) FROM stdin;
\.


--
-- Data for Name: usergroupattributevalues; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.usergroupattributevalues (usergroupid, attributevalueid) FROM stdin;
\.


--
-- Data for Name: usergroupmanaged; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.usergroupmanaged (managedbygroupid, managedgroupid) FROM stdin;
\.


--
-- Data for Name: usergroupmembers; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.usergroupmembers (userid, usergroupid) FROM stdin;
\.


--
-- Data for Name: usergrouptranslations; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.usergrouptranslations (usergroupid, objecttranslationid) FROM stdin;
\.


--
-- Data for Name: usergroupuseraccesses; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.usergroupuseraccesses (usergroupid, useraccessid) FROM stdin;
\.


--
-- Data for Name: usergroupusergroupaccesses; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.usergroupusergroupaccesses (usergroupid, usergroupaccessid) FROM stdin;
\.


--
-- Data for Name: userinfo; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.userinfo (userinfoid, uid, code, lastupdated, created, surname, firstname, email, phonenumber, jobtitle, introduction, gender, birthday, nationality, employer, education, interests, languages, lastcheckedinterpretations) FROM stdin;
57	M5zQapPyTZI	admin	2018-03-27 22:05:50.006	2018-03-27 22:05:49.805	admin	admin	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
\.


--
-- Data for Name: userkeyjsonvalue; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.userkeyjsonvalue (userkeyjsonvalueid, uid, code, created, lastupdated, lastupdatedby, userid, namespace, userkey, value, encrypted_value, encrypted) FROM stdin;
59	nlRTyotQMP9	\N	2018-03-27 22:05:58.186	2018-03-27 22:18:57.015	57	57	dashboard	controlBarRows	1	\N	f
\.


--
-- Data for Name: usermembership; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.usermembership (userinfoid, organisationunitid) FROM stdin;
\.


--
-- Data for Name: usermessage; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.usermessage (usermessageid, usermessagekey, userid, isread, isfollowup) FROM stdin;
\.


--
-- Data for Name: userrole; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.userrole (userroleid, uid, code, created, lastupdated, lastupdatedby, name, description, userid, publicaccess) FROM stdin;
58	yrB6vc5Ip3r	Superuser	2018-03-27 22:05:49.814	2018-03-27 22:05:49.814	\N	Superuser	Superuser	\N	--------
\.


--
-- Data for Name: userroleauthorities; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.userroleauthorities (userroleid, authority) FROM stdin;
58	F_TRACKED_ENTITY_INSTANCE_SEARCH_IN_ALL_ORGUNITS
58	ALL
58	F_USERGROUP_MANAGING_RELATIONSHIPS_ADD
58	F_LEGEND_DELETE
58	F_TRACKED_ENTITY_INSTANCE_DELETE
58	F_USER_GROUPS_READ_ONLY_ADD_MEMBERS
58	F_ORGANISATIONUNIT_MOVE
58	F_PREDICTOR_RUN
58	F_TRACKED_ENTITY_INSTANCE_SEARCH
58	F_PROGRAM_ENROLLMENT
58	F_REPLICATE_USER
58	F_SEND_EMAIL
58	F_LEGEND_ADD
58	F_INSERT_CUSTOM_JS_CSS
58	F_ENROLLMENT_CASCADE_DELETE
58	F_METADATA_IMPORT
58	F_VIEW_SETTINGS
58	F_VIEW_EVENT_ANALYTICS
58	F_VIEW_UNAPPROVED_DATA
58	F_USERGROUP_MANAGING_RELATIONSHIPS_VIEW
58	F_METADATA_EXPORT
58	F_PROGRAM_UNENROLLMENT
58	F_TEI_CASCADE_DELETE
58	F_APPROVE_DATA
58	F_ACCEPT_DATA_LOWER_LEVELS
58	F_TRACKED_ENTITY_INSTANCE_ADD
58	F_TRACKED_ENTITY_DATAVALUE_ADD
58	F_PROGRAM_DASHBOARD_CONFIG_ADMIN
58	F_TRACKED_ENTITY_DATAVALUE_READ
58	F_PROGRAM_ENROLLMENT_READ
58	F_APPROVE_DATA_LOWER_LEVELS
58	F_TRACKED_ENTITY_DATAVALUE_DELETE
58	F_UNCOMPLETE_EVENT
\.


--
-- Data for Name: userrolemembers; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.userrolemembers (userid, userroleid) FROM stdin;
57	58
\.


--
-- Data for Name: userroletranslations; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.userroletranslations (userroleid, objecttranslationid) FROM stdin;
\.


--
-- Data for Name: userroleuseraccesses; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.userroleuseraccesses (userroleid, useraccessid) FROM stdin;
\.


--
-- Data for Name: userroleusergroupaccesses; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.userroleusergroupaccesses (userroleid, usergroupaccessid) FROM stdin;
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.users (userid, uid, code, created, lastupdated, lastupdatedby, creatoruserid, username, password, externalauth, openid, ldapid, passwordlastupdated, lastlogin, restoretoken, restorecode, restoreexpiry, selfregistered, invitation, disabled) FROM stdin;
57	KvMx6c1eoYo	admin	2018-03-27 22:05:49.825	2018-04-04 00:27:18.888	\N	\N	admin	$2a$10$5fkk6xnzffkIXvkxRSAcv.WnPoz8ncOtrpa8eymKR3x5MgoL3jXWq	f	\N	\N	2018-03-27 22:05:49.826	2018-04-04 00:27:18.888	\N	\N	\N	f	f	f
\.


--
-- Data for Name: users_catdimensionconstraints; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.users_catdimensionconstraints (userid, dataelementcategoryid) FROM stdin;
\.


--
-- Data for Name: users_cogsdimensionconstraints; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.users_cogsdimensionconstraints (userid, categoryoptiongroupsetid) FROM stdin;
\.


--
-- Data for Name: usersetting; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.usersetting (userinfoid, name, value) FROM stdin;
\.


--
-- Data for Name: userteisearchorgunits; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.userteisearchorgunits (userinfoid, organisationunitid) FROM stdin;
\.


--
-- Data for Name: validationcriteria; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.validationcriteria (validationcriteriaid, uid, code, created, lastupdated, lastupdatedby, name, description, property, operator, value) FROM stdin;
\.


--
-- Data for Name: validationcriteriatranslations; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.validationcriteriatranslations (validationcriteriaid, objecttranslationid) FROM stdin;
\.


--
-- Data for Name: validationnotificationtemplate; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.validationnotificationtemplate (validationnotificationtemplateid, uid, code, created, lastupdated, lastupdatedby, name, subjecttemplate, messagetemplate, notifyusersinhierarchyonly, sendstrategy) FROM stdin;
\.


--
-- Data for Name: validationnotificationtemplate_recipientusergroups; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.validationnotificationtemplate_recipientusergroups (validationnotificationtemplateid, usergroupid) FROM stdin;
\.


--
-- Data for Name: validationnotificationtemplatevalidationrules; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.validationnotificationtemplatevalidationrules (validationnotificationtemplateid, validationruleid) FROM stdin;
\.


--
-- Data for Name: validationresult; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.validationresult (validationresultid, created, leftsidevalue, rightsidevalue, validationruleid, periodid, organisationunitid, attributeoptioncomboid, dayinperiod, notificationsent) FROM stdin;
\.


--
-- Data for Name: validationrule; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.validationrule (validationruleid, uid, code, created, lastupdated, lastupdatedby, name, description, instruction, importance, operator, leftexpressionid, rightexpressionid, skipformvalidation, periodtypeid, userid, publicaccess) FROM stdin;
\.


--
-- Data for Name: validationrulegroup; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.validationrulegroup (validationrulegroupid, uid, code, created, lastupdated, lastupdatedby, name, description, userid, publicaccess) FROM stdin;
\.


--
-- Data for Name: validationrulegroupmembers; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.validationrulegroupmembers (validationgroupid, validationruleid) FROM stdin;
\.


--
-- Data for Name: validationrulegrouptranslations; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.validationrulegrouptranslations (validationrulegroupid, objecttranslationid) FROM stdin;
\.


--
-- Data for Name: validationrulegroupuseraccesses; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.validationrulegroupuseraccesses (validationrulegroupid, useraccessid) FROM stdin;
\.


--
-- Data for Name: validationrulegroupusergroupaccesses; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.validationrulegroupusergroupaccesses (validationrulegroupid, usergroupaccessid) FROM stdin;
\.


--
-- Data for Name: validationruleorganisationunitlevels; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.validationruleorganisationunitlevels (validationruleid, organisationunitlevel) FROM stdin;
\.


--
-- Data for Name: validationruletranslations; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.validationruletranslations (validationruleid, objecttranslationid) FROM stdin;
\.


--
-- Data for Name: validationruleuseraccesses; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.validationruleuseraccesses (validationruleid, useraccessid) FROM stdin;
\.


--
-- Data for Name: validationruleusergroupaccesses; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.validationruleusergroupaccesses (validationruleid, usergroupaccessid) FROM stdin;
\.


--
-- Data for Name: version; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.version (versionid, versionkey, versionvalue) FROM stdin;
\.


--
-- Name: attribute_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.attribute
    ADD CONSTRAINT attribute_pkey PRIMARY KEY (attributeid);


--
-- Name: attributetranslations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.attributetranslations
    ADD CONSTRAINT attributetranslations_pkey PRIMARY KEY (attributeid, objecttranslationid);


--
-- Name: attributeuseraccesses_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.attributeuseraccesses
    ADD CONSTRAINT attributeuseraccesses_pkey PRIMARY KEY (attributeid, useraccessid);


--
-- Name: attributeusergroupaccesses_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.attributeusergroupaccesses
    ADD CONSTRAINT attributeusergroupaccesses_pkey PRIMARY KEY (attributeid, usergroupaccessid);


--
-- Name: attributevalue_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.attributevalue
    ADD CONSTRAINT attributevalue_pkey PRIMARY KEY (attributevalueid);


--
-- Name: categories_categoryoptions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.categories_categoryoptions
    ADD CONSTRAINT categories_categoryoptions_pkey PRIMARY KEY (categoryid, sort_order);


--
-- Name: categorycombo_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.categorycombo
    ADD CONSTRAINT categorycombo_pkey PRIMARY KEY (categorycomboid);


--
-- Name: categorycombos_categories_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.categorycombos_categories
    ADD CONSTRAINT categorycombos_categories_pkey PRIMARY KEY (categorycomboid, sort_order);


--
-- Name: categorycombos_optioncombos_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.categorycombos_optioncombos
    ADD CONSTRAINT categorycombos_optioncombos_pkey PRIMARY KEY (categoryoptioncomboid);


--
-- Name: categorycombotranslations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.categorycombotranslations
    ADD CONSTRAINT categorycombotranslations_pkey PRIMARY KEY (categorycomboid, objecttranslationid);


--
-- Name: categorycombouseraccesses_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.categorycombouseraccesses
    ADD CONSTRAINT categorycombouseraccesses_pkey PRIMARY KEY (categorycomboid, useraccessid);


--
-- Name: categorycombousergroupaccesses_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.categorycombousergroupaccesses
    ADD CONSTRAINT categorycombousergroupaccesses_pkey PRIMARY KEY (categorycomboid, usergroupaccessid);


--
-- Name: categorydimension_items_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.categorydimension_items
    ADD CONSTRAINT categorydimension_items_pkey PRIMARY KEY (categorydimensionid, sort_order);


--
-- Name: categorydimension_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.categorydimension
    ADD CONSTRAINT categorydimension_pkey PRIMARY KEY (categorydimensionid);


--
-- Name: categoryoption_organisationunits_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.categoryoption_organisationunits
    ADD CONSTRAINT categoryoption_organisationunits_pkey PRIMARY KEY (categoryoptionid, organisationunitid);


--
-- Name: categoryoptioncombo_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.categoryoptioncombo
    ADD CONSTRAINT categoryoptioncombo_pkey PRIMARY KEY (categoryoptioncomboid);


--
-- Name: categoryoptioncomboattributevalues_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.categoryoptioncomboattributevalues
    ADD CONSTRAINT categoryoptioncomboattributevalues_pkey PRIMARY KEY (categoryoptioncomboid, attributevalueid);


--
-- Name: categoryoptioncombos_categoryoptions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.categoryoptioncombos_categoryoptions
    ADD CONSTRAINT categoryoptioncombos_categoryoptions_pkey PRIMARY KEY (categoryoptioncomboid, categoryoptionid);


--
-- Name: categoryoptioncombotranslations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.categoryoptioncombotranslations
    ADD CONSTRAINT categoryoptioncombotranslations_pkey PRIMARY KEY (categoryoptioncomboid, objecttranslationid);


--
-- Name: categoryoptiongroup_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.categoryoptiongroup
    ADD CONSTRAINT categoryoptiongroup_pkey PRIMARY KEY (categoryoptiongroupid);


--
-- Name: categoryoptiongroupattributevalues_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.categoryoptiongroupattributevalues
    ADD CONSTRAINT categoryoptiongroupattributevalues_pkey PRIMARY KEY (categoryoptiongroupid, attributevalueid);


--
-- Name: categoryoptiongroupmembers_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.categoryoptiongroupmembers
    ADD CONSTRAINT categoryoptiongroupmembers_pkey PRIMARY KEY (categoryoptiongroupid, categoryoptionid);


--
-- Name: categoryoptiongroupset_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.categoryoptiongroupset
    ADD CONSTRAINT categoryoptiongroupset_pkey PRIMARY KEY (categoryoptiongroupsetid);


--
-- Name: categoryoptiongroupsetdimension_items_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.categoryoptiongroupsetdimension_items
    ADD CONSTRAINT categoryoptiongroupsetdimension_items_pkey PRIMARY KEY (categoryoptiongroupsetdimensionid, sort_order);


--
-- Name: categoryoptiongroupsetdimension_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.categoryoptiongroupsetdimension
    ADD CONSTRAINT categoryoptiongroupsetdimension_pkey PRIMARY KEY (categoryoptiongroupsetdimensionid);


--
-- Name: categoryoptiongroupsetmembers_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.categoryoptiongroupsetmembers
    ADD CONSTRAINT categoryoptiongroupsetmembers_pkey PRIMARY KEY (categoryoptiongroupsetid, sort_order);


--
-- Name: categoryoptiongroupsettranslations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.categoryoptiongroupsettranslations
    ADD CONSTRAINT categoryoptiongroupsettranslations_pkey PRIMARY KEY (categoryoptiongroupsetid, objecttranslationid);


--
-- Name: categoryoptiongroupsetuseraccesses_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.categoryoptiongroupsetuseraccesses
    ADD CONSTRAINT categoryoptiongroupsetuseraccesses_pkey PRIMARY KEY (categoryoptiongroupsetid, useraccessid);


--
-- Name: categoryoptiongroupsetusergroupaccesses_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.categoryoptiongroupsetusergroupaccesses
    ADD CONSTRAINT categoryoptiongroupsetusergroupaccesses_pkey PRIMARY KEY (categoryoptiongroupsetid, usergroupaccessid);


--
-- Name: categoryoptiongrouptranslations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.categoryoptiongrouptranslations
    ADD CONSTRAINT categoryoptiongrouptranslations_pkey PRIMARY KEY (categoryoptiongroupid, objecttranslationid);


--
-- Name: categoryoptiongroupuseraccesses_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.categoryoptiongroupuseraccesses
    ADD CONSTRAINT categoryoptiongroupuseraccesses_pkey PRIMARY KEY (categoryoptiongroupid, useraccessid);


--
-- Name: categoryoptiongroupusergroupaccesses_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.categoryoptiongroupusergroupaccesses
    ADD CONSTRAINT categoryoptiongroupusergroupaccesses_pkey PRIMARY KEY (categoryoptiongroupid, usergroupaccessid);


--
-- Name: categoryoptiontranslations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.categoryoptiontranslations
    ADD CONSTRAINT categoryoptiontranslations_pkey PRIMARY KEY (categoryoptionid, objecttranslationid);


--
-- Name: chart_categorydimensions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.chart_categorydimensions
    ADD CONSTRAINT chart_categorydimensions_pkey PRIMARY KEY (chartid, sort_order);


--
-- Name: chart_categoryoptiongroupsetdimensions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.chart_categoryoptiongroupsetdimensions
    ADD CONSTRAINT chart_categoryoptiongroupsetdimensions_pkey PRIMARY KEY (chart, sort_order);


--
-- Name: chart_datadimensionitems_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.chart_datadimensionitems
    ADD CONSTRAINT chart_datadimensionitems_pkey PRIMARY KEY (chartid, sort_order);


--
-- Name: chart_dataelementgroupsetdimensions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.chart_dataelementgroupsetdimensions
    ADD CONSTRAINT chart_dataelementgroupsetdimensions_pkey PRIMARY KEY (chartid, sort_order);


--
-- Name: chart_filters_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.chart_filters
    ADD CONSTRAINT chart_filters_pkey PRIMARY KEY (chartid, sort_order);


--
-- Name: chart_itemorgunitgroups_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.chart_itemorgunitgroups
    ADD CONSTRAINT chart_itemorgunitgroups_pkey PRIMARY KEY (chartid, sort_order);


--
-- Name: chart_organisationunits_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.chart_organisationunits
    ADD CONSTRAINT chart_organisationunits_pkey PRIMARY KEY (chartid, sort_order);


--
-- Name: chart_orgunitgroupsetdimensions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.chart_orgunitgroupsetdimensions
    ADD CONSTRAINT chart_orgunitgroupsetdimensions_pkey PRIMARY KEY (chartid, sort_order);


--
-- Name: chart_orgunitlevels_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.chart_orgunitlevels
    ADD CONSTRAINT chart_orgunitlevels_pkey PRIMARY KEY (chartid, sort_order);


--
-- Name: chart_periods_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.chart_periods
    ADD CONSTRAINT chart_periods_pkey PRIMARY KEY (chartid, sort_order);


--
-- Name: chart_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.chart
    ADD CONSTRAINT chart_pkey PRIMARY KEY (chartid);


--
-- Name: charttranslations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.charttranslations
    ADD CONSTRAINT charttranslations_pkey PRIMARY KEY (chartid, objecttranslationid);


--
-- Name: chartuseraccesses_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.chartuseraccesses
    ADD CONSTRAINT chartuseraccesses_pkey PRIMARY KEY (chartid, useraccessid);


--
-- Name: chartusergroupaccesses_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.chartusergroupaccesses
    ADD CONSTRAINT chartusergroupaccesses_pkey PRIMARY KEY (chartid, usergroupaccessid);


--
-- Name: color_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.color
    ADD CONSTRAINT color_pkey PRIMARY KEY (colorid);


--
-- Name: colorset_colors_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.colorset_colors
    ADD CONSTRAINT colorset_colors_pkey PRIMARY KEY (colorsetid, sort_order);


--
-- Name: colorset_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.colorset
    ADD CONSTRAINT colorset_pkey PRIMARY KEY (colorsetid);


--
-- Name: colorsettranslations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.colorsettranslations
    ADD CONSTRAINT colorsettranslations_pkey PRIMARY KEY (colorsetid, objecttranslationid);


--
-- Name: colortranslations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.colortranslations
    ADD CONSTRAINT colortranslations_pkey PRIMARY KEY (colorid, objecttranslationid);


--
-- Name: completedatasetregistration_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.completedatasetregistration
    ADD CONSTRAINT completedatasetregistration_pkey PRIMARY KEY (datasetid, periodid, sourceid, attributeoptioncomboid);


--
-- Name: configuration_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.configuration
    ADD CONSTRAINT configuration_pkey PRIMARY KEY (configurationid);


--
-- Name: constant_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.constant
    ADD CONSTRAINT constant_pkey PRIMARY KEY (constantid);


--
-- Name: constantattributevalues_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.constantattributevalues
    ADD CONSTRAINT constantattributevalues_pkey PRIMARY KEY (constantid, attributevalueid);


--
-- Name: constanttranslations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.constanttranslations
    ADD CONSTRAINT constanttranslations_pkey PRIMARY KEY (colorid, objecttranslationid);


--
-- Name: constantuseraccesses_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.constantuseraccesses
    ADD CONSTRAINT constantuseraccesses_pkey PRIMARY KEY (constantid, useraccessid);


--
-- Name: constantusergroupaccesses_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.constantusergroupaccesses
    ADD CONSTRAINT constantusergroupaccesses_pkey PRIMARY KEY (constantid, usergroupaccessid);


--
-- Name: dashboard_items_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dashboard_items
    ADD CONSTRAINT dashboard_items_pkey PRIMARY KEY (dashboardid, sort_order);


--
-- Name: dashboard_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dashboard
    ADD CONSTRAINT dashboard_pkey PRIMARY KEY (dashboardid);


--
-- Name: dashboarditem_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dashboarditem
    ADD CONSTRAINT dashboarditem_pkey PRIMARY KEY (dashboarditemid);


--
-- Name: dashboarditem_reports_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dashboarditem_reports
    ADD CONSTRAINT dashboarditem_reports_pkey PRIMARY KEY (dashboarditemid, sort_order);


--
-- Name: dashboarditem_resources_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dashboarditem_resources
    ADD CONSTRAINT dashboarditem_resources_pkey PRIMARY KEY (dashboarditemid, sort_order);


--
-- Name: dashboarditem_users_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dashboarditem_users
    ADD CONSTRAINT dashboarditem_users_pkey PRIMARY KEY (dashboarditemid, sort_order);


--
-- Name: dashboarditemtranslations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dashboarditemtranslations
    ADD CONSTRAINT dashboarditemtranslations_pkey PRIMARY KEY (dashboarditemid, objecttranslationid);


--
-- Name: dashboardtranslations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dashboardtranslations
    ADD CONSTRAINT dashboardtranslations_pkey PRIMARY KEY (dashboardid, objecttranslationid);


--
-- Name: dashboarduseraccesses_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dashboarduseraccesses
    ADD CONSTRAINT dashboarduseraccesses_pkey PRIMARY KEY (dashboardid, useraccessid);


--
-- Name: dashboardusergroupaccesses_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dashboardusergroupaccesses
    ADD CONSTRAINT dashboardusergroupaccesses_pkey PRIMARY KEY (dashboardid, usergroupaccessid);


--
-- Name: dataapproval_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dataapproval
    ADD CONSTRAINT dataapproval_pkey PRIMARY KEY (dataapprovalid);


--
-- Name: dataapproval_unique_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dataapproval
    ADD CONSTRAINT dataapproval_unique_key UNIQUE (dataapprovallevelid, workflowid, periodid, organisationunitid, attributeoptioncomboid);


--
-- Name: dataapprovalaudit_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dataapprovalaudit
    ADD CONSTRAINT dataapprovalaudit_pkey PRIMARY KEY (dataapprovalauditid);


--
-- Name: dataapprovallevel_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dataapprovallevel
    ADD CONSTRAINT dataapprovallevel_pkey PRIMARY KEY (dataapprovallevelid);


--
-- Name: dataapprovalleveltranslations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dataapprovalleveltranslations
    ADD CONSTRAINT dataapprovalleveltranslations_pkey PRIMARY KEY (dataapprovallevelid, objecttranslationid);


--
-- Name: dataapprovalleveluseraccesses_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dataapprovalleveluseraccesses
    ADD CONSTRAINT dataapprovalleveluseraccesses_pkey PRIMARY KEY (dataapprovallevelid, useraccessid);


--
-- Name: dataapprovallevelusergroupaccesses_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dataapprovallevelusergroupaccesses
    ADD CONSTRAINT dataapprovallevelusergroupaccesses_pkey PRIMARY KEY (dataapprovallevelid, usergroupaccessid);


--
-- Name: dataapprovalworkflow_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dataapprovalworkflow
    ADD CONSTRAINT dataapprovalworkflow_pkey PRIMARY KEY (workflowid);


--
-- Name: dataapprovalworkflowlevels_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dataapprovalworkflowlevels
    ADD CONSTRAINT dataapprovalworkflowlevels_pkey PRIMARY KEY (workflowid, dataapprovallevelid);


--
-- Name: dataapprovalworkflowtranslations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dataapprovalworkflowtranslations
    ADD CONSTRAINT dataapprovalworkflowtranslations_pkey PRIMARY KEY (workflowid, objecttranslationid);


--
-- Name: dataapprovalworkflowuseraccesses_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dataapprovalworkflowuseraccesses
    ADD CONSTRAINT dataapprovalworkflowuseraccesses_pkey PRIMARY KEY (workflowid, useraccessid);


--
-- Name: dataapprovalworkflowusergroupaccesses_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dataapprovalworkflowusergroupaccesses
    ADD CONSTRAINT dataapprovalworkflowusergroupaccesses_pkey PRIMARY KEY (workflowid, usergroupaccessid);


--
-- Name: datadimensionitem_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.datadimensionitem
    ADD CONSTRAINT datadimensionitem_pkey PRIMARY KEY (datadimensionitemid);


--
-- Name: dataelement_code_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dataelement
    ADD CONSTRAINT dataelement_code_key UNIQUE (code);


--
-- Name: dataelement_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dataelement
    ADD CONSTRAINT dataelement_pkey PRIMARY KEY (dataelementid);


--
-- Name: dataelementaggregationlevels_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dataelementaggregationlevels
    ADD CONSTRAINT dataelementaggregationlevels_pkey PRIMARY KEY (dataelementid, sort_order);


--
-- Name: dataelementattributevalues_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dataelementattributevalues
    ADD CONSTRAINT dataelementattributevalues_pkey PRIMARY KEY (dataelementid, attributevalueid);


--
-- Name: dataelementcategory_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dataelementcategory
    ADD CONSTRAINT dataelementcategory_pkey PRIMARY KEY (categoryid);


--
-- Name: dataelementcategoryoption_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dataelementcategoryoption
    ADD CONSTRAINT dataelementcategoryoption_pkey PRIMARY KEY (categoryoptionid);


--
-- Name: dataelementcategoryoptionattributevalues_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dataelementcategoryoptionattributevalues
    ADD CONSTRAINT dataelementcategoryoptionattributevalues_pkey PRIMARY KEY (categoryoptionid, attributevalueid);


--
-- Name: dataelementcategoryoptionuseraccesses_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dataelementcategoryoptionuseraccesses
    ADD CONSTRAINT dataelementcategoryoptionuseraccesses_pkey PRIMARY KEY (categoryoptionid, useraccessid);


--
-- Name: dataelementcategoryoptionusergroupaccesses_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dataelementcategoryoptionusergroupaccesses
    ADD CONSTRAINT dataelementcategoryoptionusergroupaccesses_pkey PRIMARY KEY (categoryoptionid, usergroupaccessid);


--
-- Name: dataelementcategorytranslations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dataelementcategorytranslations
    ADD CONSTRAINT dataelementcategorytranslations_pkey PRIMARY KEY (categoryid, objecttranslationid);


--
-- Name: dataelementcategoryuseraccesses_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dataelementcategoryuseraccesses
    ADD CONSTRAINT dataelementcategoryuseraccesses_pkey PRIMARY KEY (categoryid, useraccessid);


--
-- Name: dataelementcategoryusergroupaccesses_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dataelementcategoryusergroupaccesses
    ADD CONSTRAINT dataelementcategoryusergroupaccesses_pkey PRIMARY KEY (categoryid, usergroupaccessid);


--
-- Name: dataelementgroup_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dataelementgroup
    ADD CONSTRAINT dataelementgroup_pkey PRIMARY KEY (dataelementgroupid);


--
-- Name: dataelementgroupattributevalues_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dataelementgroupattributevalues
    ADD CONSTRAINT dataelementgroupattributevalues_pkey PRIMARY KEY (dataelementgroupid, attributevalueid);


--
-- Name: dataelementgroupmembers_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dataelementgroupmembers
    ADD CONSTRAINT dataelementgroupmembers_pkey PRIMARY KEY (dataelementgroupid, dataelementid);


--
-- Name: dataelementgroupset_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dataelementgroupset
    ADD CONSTRAINT dataelementgroupset_pkey PRIMARY KEY (dataelementgroupsetid);


--
-- Name: dataelementgroupsetdimension_items_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dataelementgroupsetdimension_items
    ADD CONSTRAINT dataelementgroupsetdimension_items_pkey PRIMARY KEY (dataelementgroupsetdimensionid, sort_order);


--
-- Name: dataelementgroupsetdimension_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dataelementgroupsetdimension
    ADD CONSTRAINT dataelementgroupsetdimension_pkey PRIMARY KEY (dataelementgroupsetdimensionid);


--
-- Name: dataelementgroupsetmembers_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dataelementgroupsetmembers
    ADD CONSTRAINT dataelementgroupsetmembers_pkey PRIMARY KEY (dataelementgroupsetid, sort_order);


--
-- Name: dataelementgroupsettranslations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dataelementgroupsettranslations
    ADD CONSTRAINT dataelementgroupsettranslations_pkey PRIMARY KEY (dataelementgroupsetid, objecttranslationid);


--
-- Name: dataelementgroupsetuseraccesses_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dataelementgroupsetuseraccesses
    ADD CONSTRAINT dataelementgroupsetuseraccesses_pkey PRIMARY KEY (dataelementgroupsetid, useraccessid);


--
-- Name: dataelementgroupsetusergroupaccesses_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dataelementgroupsetusergroupaccesses
    ADD CONSTRAINT dataelementgroupsetusergroupaccesses_pkey PRIMARY KEY (dataelementgroupsetid, usergroupaccessid);


--
-- Name: dataelementgrouptranslations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dataelementgrouptranslations
    ADD CONSTRAINT dataelementgrouptranslations_pkey PRIMARY KEY (dataelementgroupid, objecttranslationid);


--
-- Name: dataelementgroupuseraccesses_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dataelementgroupuseraccesses
    ADD CONSTRAINT dataelementgroupuseraccesses_pkey PRIMARY KEY (dataelementgroupid, useraccessid);


--
-- Name: dataelementgroupusergroupaccesses_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dataelementgroupusergroupaccesses
    ADD CONSTRAINT dataelementgroupusergroupaccesses_pkey PRIMARY KEY (dataelementgroupid, usergroupaccessid);


--
-- Name: dataelementlegendsets_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dataelementlegendsets
    ADD CONSTRAINT dataelementlegendsets_pkey PRIMARY KEY (dataelementid, sort_order);


--
-- Name: dataelementoperand_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dataelementoperand
    ADD CONSTRAINT dataelementoperand_pkey PRIMARY KEY (dataelementoperandid);


--
-- Name: dataelementtranslations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dataelementtranslations
    ADD CONSTRAINT dataelementtranslations_pkey PRIMARY KEY (dataelementid, objecttranslationid);


--
-- Name: dataelementuseraccesses_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dataelementuseraccesses
    ADD CONSTRAINT dataelementuseraccesses_pkey PRIMARY KEY (dataelementid, useraccessid);


--
-- Name: dataelementusergroupaccesses_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dataelementusergroupaccesses
    ADD CONSTRAINT dataelementusergroupaccesses_pkey PRIMARY KEY (dataelementid, usergroupaccessid);


--
-- Name: dataentryform_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dataentryform
    ADD CONSTRAINT dataentryform_pkey PRIMARY KEY (dataentryformid);


--
-- Name: dataentryformtranslations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dataentryformtranslations
    ADD CONSTRAINT dataentryformtranslations_pkey PRIMARY KEY (dataentryformid, objecttranslationid);


--
-- Name: datainputperiod_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.datainputperiod
    ADD CONSTRAINT datainputperiod_pkey PRIMARY KEY (datainputperiodid);


--
-- Name: dataset_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dataset
    ADD CONSTRAINT dataset_pkey PRIMARY KEY (datasetid);


--
-- Name: datasetattributevalues_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.datasetattributevalues
    ADD CONSTRAINT datasetattributevalues_pkey PRIMARY KEY (datasetid, attributevalueid);


--
-- Name: datasetelement_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.datasetelement
    ADD CONSTRAINT datasetelement_pkey PRIMARY KEY (datasetelementid);


--
-- Name: datasetelement_unique_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.datasetelement
    ADD CONSTRAINT datasetelement_unique_key UNIQUE (datasetid, dataelementid);


--
-- Name: datasetindicators_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.datasetindicators
    ADD CONSTRAINT datasetindicators_pkey PRIMARY KEY (datasetid, indicatorid);


--
-- Name: datasetlegendsets_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.datasetlegendsets
    ADD CONSTRAINT datasetlegendsets_pkey PRIMARY KEY (datasetid, sort_order);


--
-- Name: datasetnotification_datasets_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.datasetnotification_datasets
    ADD CONSTRAINT datasetnotification_datasets_pkey PRIMARY KEY (datasetnotificationtemplateid, datasetid);


--
-- Name: datasetnotificationtemplate_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.datasetnotificationtemplate
    ADD CONSTRAINT datasetnotificationtemplate_pkey PRIMARY KEY (datasetnotificationtemplateid);


--
-- Name: datasetoperands_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.datasetoperands
    ADD CONSTRAINT datasetoperands_pkey PRIMARY KEY (datasetid, dataelementoperandid);


--
-- Name: datasetsectiontranslations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.datasetsectiontranslations
    ADD CONSTRAINT datasetsectiontranslations_pkey PRIMARY KEY (sectionid, objecttranslationid);


--
-- Name: datasetsource_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.datasetsource
    ADD CONSTRAINT datasetsource_pkey PRIMARY KEY (datasetid, sourceid);


--
-- Name: datasettranslations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.datasettranslations
    ADD CONSTRAINT datasettranslations_pkey PRIMARY KEY (datasetid, objecttranslationid);


--
-- Name: datasetuseraccesses_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.datasetuseraccesses
    ADD CONSTRAINT datasetuseraccesses_pkey PRIMARY KEY (datasetid, useraccessid);


--
-- Name: datasetusergroupaccesses_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.datasetusergroupaccesses
    ADD CONSTRAINT datasetusergroupaccesses_pkey PRIMARY KEY (datasetid, usergroupaccessid);


--
-- Name: datastatistics_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.datastatistics
    ADD CONSTRAINT datastatistics_pkey PRIMARY KEY (statisticsid);


--
-- Name: datastatisticsevent_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.datastatisticsevent
    ADD CONSTRAINT datastatisticsevent_pkey PRIMARY KEY (eventid);


--
-- Name: datavalue_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.datavalue
    ADD CONSTRAINT datavalue_pkey PRIMARY KEY (dataelementid, periodid, sourceid, categoryoptioncomboid, attributeoptioncomboid);


--
-- Name: datavalueaudit_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.datavalueaudit
    ADD CONSTRAINT datavalueaudit_pkey PRIMARY KEY (datavalueauditid);


--
-- Name: deletedobject_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.deletedobject
    ADD CONSTRAINT deletedobject_pkey PRIMARY KEY (deletedobjectid);


--
-- Name: document_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document
    ADD CONSTRAINT document_pkey PRIMARY KEY (documentid);


--
-- Name: documentattributevalues_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.documentattributevalues
    ADD CONSTRAINT documentattributevalues_pkey PRIMARY KEY (documentid, attributevalueid);


--
-- Name: documenttranslations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.documenttranslations
    ADD CONSTRAINT documenttranslations_pkey PRIMARY KEY (documentid, objecttranslationid);


--
-- Name: documentuseraccesses_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.documentuseraccesses
    ADD CONSTRAINT documentuseraccesses_pkey PRIMARY KEY (documentid, useraccessid);


--
-- Name: documentusergroupaccesses_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.documentusergroupaccesses
    ADD CONSTRAINT documentusergroupaccesses_pkey PRIMARY KEY (documentid, usergroupaccessid);


--
-- Name: eventchart_attributedimensions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.eventchart_attributedimensions
    ADD CONSTRAINT eventchart_attributedimensions_pkey PRIMARY KEY (eventchartid, sort_order);


--
-- Name: eventchart_categorydimensions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.eventchart_categorydimensions
    ADD CONSTRAINT eventchart_categorydimensions_pkey PRIMARY KEY (eventchartid, sort_order);


--
-- Name: eventchart_categoryoptiongroupsetdimensions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.eventchart_categoryoptiongroupsetdimensions
    ADD CONSTRAINT eventchart_categoryoptiongroupsetdimensions_pkey PRIMARY KEY (eventchartid, sort_order);


--
-- Name: eventchart_columns_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.eventchart_columns
    ADD CONSTRAINT eventchart_columns_pkey PRIMARY KEY (eventchartid, sort_order);


--
-- Name: eventchart_dataelementdimensions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.eventchart_dataelementdimensions
    ADD CONSTRAINT eventchart_dataelementdimensions_pkey PRIMARY KEY (eventchartid, sort_order);


--
-- Name: eventchart_filters_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.eventchart_filters
    ADD CONSTRAINT eventchart_filters_pkey PRIMARY KEY (eventchartid, sort_order);


--
-- Name: eventchart_itemorgunitgroups_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.eventchart_itemorgunitgroups
    ADD CONSTRAINT eventchart_itemorgunitgroups_pkey PRIMARY KEY (eventchartid, sort_order);


--
-- Name: eventchart_organisationunits_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.eventchart_organisationunits
    ADD CONSTRAINT eventchart_organisationunits_pkey PRIMARY KEY (eventchartid, sort_order);


--
-- Name: eventchart_orgunitgroupsetdimensions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.eventchart_orgunitgroupsetdimensions
    ADD CONSTRAINT eventchart_orgunitgroupsetdimensions_pkey PRIMARY KEY (eventchartid, sort_order);


--
-- Name: eventchart_orgunitlevels_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.eventchart_orgunitlevels
    ADD CONSTRAINT eventchart_orgunitlevels_pkey PRIMARY KEY (eventchartid, sort_order);


--
-- Name: eventchart_periods_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.eventchart_periods
    ADD CONSTRAINT eventchart_periods_pkey PRIMARY KEY (eventchartid, sort_order);


--
-- Name: eventchart_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.eventchart
    ADD CONSTRAINT eventchart_pkey PRIMARY KEY (eventchartid);


--
-- Name: eventchart_programindicatordimensions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.eventchart_programindicatordimensions
    ADD CONSTRAINT eventchart_programindicatordimensions_pkey PRIMARY KEY (eventchartid, sort_order);


--
-- Name: eventchart_rows_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.eventchart_rows
    ADD CONSTRAINT eventchart_rows_pkey PRIMARY KEY (eventchartid, sort_order);


--
-- Name: eventcharttranslations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.eventcharttranslations
    ADD CONSTRAINT eventcharttranslations_pkey PRIMARY KEY (eventchartid, objecttranslationid);


--
-- Name: eventchartuseraccesses_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.eventchartuseraccesses
    ADD CONSTRAINT eventchartuseraccesses_pkey PRIMARY KEY (eventchartid, useraccessid);


--
-- Name: eventchartusergroupaccesses_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.eventchartusergroupaccesses
    ADD CONSTRAINT eventchartusergroupaccesses_pkey PRIMARY KEY (eventchartid, usergroupaccessid);


--
-- Name: eventreport_attributedimensions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.eventreport_attributedimensions
    ADD CONSTRAINT eventreport_attributedimensions_pkey PRIMARY KEY (eventreportid, sort_order);


--
-- Name: eventreport_categorydimensions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.eventreport_categorydimensions
    ADD CONSTRAINT eventreport_categorydimensions_pkey PRIMARY KEY (eventreportid, sort_order);


--
-- Name: eventreport_categoryoptiongroupsetdimensions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.eventreport_categoryoptiongroupsetdimensions
    ADD CONSTRAINT eventreport_categoryoptiongroupsetdimensions_pkey PRIMARY KEY (eventreportid, sort_order);


--
-- Name: eventreport_columns_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.eventreport_columns
    ADD CONSTRAINT eventreport_columns_pkey PRIMARY KEY (eventreportid, sort_order);


--
-- Name: eventreport_dataelementdimensions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.eventreport_dataelementdimensions
    ADD CONSTRAINT eventreport_dataelementdimensions_pkey PRIMARY KEY (eventreportid, sort_order);


--
-- Name: eventreport_filters_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.eventreport_filters
    ADD CONSTRAINT eventreport_filters_pkey PRIMARY KEY (eventreportid, sort_order);


--
-- Name: eventreport_itemorgunitgroups_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.eventreport_itemorgunitgroups
    ADD CONSTRAINT eventreport_itemorgunitgroups_pkey PRIMARY KEY (eventreportid, sort_order);


--
-- Name: eventreport_organisationunits_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.eventreport_organisationunits
    ADD CONSTRAINT eventreport_organisationunits_pkey PRIMARY KEY (eventreportid, sort_order);


--
-- Name: eventreport_orgunitgroupsetdimensions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.eventreport_orgunitgroupsetdimensions
    ADD CONSTRAINT eventreport_orgunitgroupsetdimensions_pkey PRIMARY KEY (eventreportid, sort_order);


--
-- Name: eventreport_orgunitlevels_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.eventreport_orgunitlevels
    ADD CONSTRAINT eventreport_orgunitlevels_pkey PRIMARY KEY (eventreportid, sort_order);


--
-- Name: eventreport_periods_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.eventreport_periods
    ADD CONSTRAINT eventreport_periods_pkey PRIMARY KEY (eventreportid, sort_order);


--
-- Name: eventreport_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.eventreport
    ADD CONSTRAINT eventreport_pkey PRIMARY KEY (eventreportid);


--
-- Name: eventreport_programindicatordimensions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.eventreport_programindicatordimensions
    ADD CONSTRAINT eventreport_programindicatordimensions_pkey PRIMARY KEY (eventreportid, sort_order);


--
-- Name: eventreport_rows_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.eventreport_rows
    ADD CONSTRAINT eventreport_rows_pkey PRIMARY KEY (eventreportid, sort_order);


--
-- Name: eventreporttranslations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.eventreporttranslations
    ADD CONSTRAINT eventreporttranslations_pkey PRIMARY KEY (eventreportid, objecttranslationid);


--
-- Name: eventreportuseraccesses_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.eventreportuseraccesses
    ADD CONSTRAINT eventreportuseraccesses_pkey PRIMARY KEY (eventreportid, useraccessid);


--
-- Name: eventreportusergroupaccesses_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.eventreportusergroupaccesses
    ADD CONSTRAINT eventreportusergroupaccesses_pkey PRIMARY KEY (eventreportid, usergroupaccessid);


--
-- Name: expression_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.expression
    ADD CONSTRAINT expression_pkey PRIMARY KEY (expressionid);


--
-- Name: externalfileresource_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.externalfileresource
    ADD CONSTRAINT externalfileresource_pkey PRIMARY KEY (externalfileresourceid);


--
-- Name: externalmaplayer_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.externalmaplayer
    ADD CONSTRAINT externalmaplayer_pkey PRIMARY KEY (externalmaplayerid);


--
-- Name: externalmaplayeruseraccesses_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.externalmaplayeruseraccesses
    ADD CONSTRAINT externalmaplayeruseraccesses_pkey PRIMARY KEY (externalmaplayerid, useraccessid);


--
-- Name: externalmaplayerusergroupaccesses_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.externalmaplayerusergroupaccesses
    ADD CONSTRAINT externalmaplayerusergroupaccesses_pkey PRIMARY KEY (externalmaplayerid, usergroupaccessid);


--
-- Name: externalnotificationlogentry_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.externalnotificationlogentry
    ADD CONSTRAINT externalnotificationlogentry_pkey PRIMARY KEY (externalnotificationlogentryid);


--
-- Name: fileresource_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.fileresource
    ADD CONSTRAINT fileresource_pkey PRIMARY KEY (fileresourceid);


--
-- Name: i18nlocale_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.i18nlocale
    ADD CONSTRAINT i18nlocale_pkey PRIMARY KEY (i18nlocaleid);


--
-- Name: incomingsms_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.incomingsms
    ADD CONSTRAINT incomingsms_pkey PRIMARY KEY (id);


--
-- Name: indicator_code_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.indicator
    ADD CONSTRAINT indicator_code_key UNIQUE (code);


--
-- Name: indicator_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.indicator
    ADD CONSTRAINT indicator_pkey PRIMARY KEY (indicatorid);


--
-- Name: indicatorattributevalues_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.indicatorattributevalues
    ADD CONSTRAINT indicatorattributevalues_pkey PRIMARY KEY (indicatorid, attributevalueid);


--
-- Name: indicatorgroup_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.indicatorgroup
    ADD CONSTRAINT indicatorgroup_pkey PRIMARY KEY (indicatorgroupid);


--
-- Name: indicatorgroupattributevalues_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.indicatorgroupattributevalues
    ADD CONSTRAINT indicatorgroupattributevalues_pkey PRIMARY KEY (indicatorgroupid, attributevalueid);


--
-- Name: indicatorgroupmembers_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.indicatorgroupmembers
    ADD CONSTRAINT indicatorgroupmembers_pkey PRIMARY KEY (indicatorgroupid, indicatorid);


--
-- Name: indicatorgroupset_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.indicatorgroupset
    ADD CONSTRAINT indicatorgroupset_pkey PRIMARY KEY (indicatorgroupsetid);


--
-- Name: indicatorgroupsetmembers_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.indicatorgroupsetmembers
    ADD CONSTRAINT indicatorgroupsetmembers_pkey PRIMARY KEY (indicatorgroupsetid, sort_order);


--
-- Name: indicatorgroupsettranslations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.indicatorgroupsettranslations
    ADD CONSTRAINT indicatorgroupsettranslations_pkey PRIMARY KEY (indicatorgroupsetid, objecttranslationid);


--
-- Name: indicatorgroupsetuseraccesses_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.indicatorgroupsetuseraccesses
    ADD CONSTRAINT indicatorgroupsetuseraccesses_pkey PRIMARY KEY (indicatorgroupsetid, useraccessid);


--
-- Name: indicatorgroupsetusergroupaccesses_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.indicatorgroupsetusergroupaccesses
    ADD CONSTRAINT indicatorgroupsetusergroupaccesses_pkey PRIMARY KEY (indicatorgroupsetid, usergroupaccessid);


--
-- Name: indicatorgrouptranslations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.indicatorgrouptranslations
    ADD CONSTRAINT indicatorgrouptranslations_pkey PRIMARY KEY (indicatorgroupid, objecttranslationid);


--
-- Name: indicatorgroupuseraccesses_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.indicatorgroupuseraccesses
    ADD CONSTRAINT indicatorgroupuseraccesses_pkey PRIMARY KEY (indicatorgroupid, useraccessid);


--
-- Name: indicatorgroupusergroupaccesses_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.indicatorgroupusergroupaccesses
    ADD CONSTRAINT indicatorgroupusergroupaccesses_pkey PRIMARY KEY (indicatorgroupid, usergroupaccessid);


--
-- Name: indicatorlegendsets_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.indicatorlegendsets
    ADD CONSTRAINT indicatorlegendsets_pkey PRIMARY KEY (indicatorid, sort_order);


--
-- Name: indicatortranslations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.indicatortranslations
    ADD CONSTRAINT indicatortranslations_pkey PRIMARY KEY (indicatorid, objecttranslationid);


--
-- Name: indicatortype_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.indicatortype
    ADD CONSTRAINT indicatortype_pkey PRIMARY KEY (indicatortypeid);


--
-- Name: indicatortypetranslations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.indicatortypetranslations
    ADD CONSTRAINT indicatortypetranslations_pkey PRIMARY KEY (indicatortypeid, objecttranslationid);


--
-- Name: indicatoruseraccesses_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.indicatoruseraccesses
    ADD CONSTRAINT indicatoruseraccesses_pkey PRIMARY KEY (indicatorid, useraccessid);


--
-- Name: indicatorusergroupaccesses_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.indicatorusergroupaccesses
    ADD CONSTRAINT indicatorusergroupaccesses_pkey PRIMARY KEY (indicatorid, usergroupaccessid);


--
-- Name: intepretation_likedby_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.intepretation_likedby
    ADD CONSTRAINT intepretation_likedby_pkey PRIMARY KEY (interpretationid, userid);


--
-- Name: interpretation_comments_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.interpretation_comments
    ADD CONSTRAINT interpretation_comments_pkey PRIMARY KEY (interpretationid, sort_order);


--
-- Name: interpretation_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.interpretation
    ADD CONSTRAINT interpretation_pkey PRIMARY KEY (interpretationid);


--
-- Name: interpretationcomment_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.interpretationcomment
    ADD CONSTRAINT interpretationcomment_pkey PRIMARY KEY (interpretationcommentid);


--
-- Name: interpretationuseraccesses_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.interpretationuseraccesses
    ADD CONSTRAINT interpretationuseraccesses_pkey PRIMARY KEY (interpretationid, useraccessid);


--
-- Name: interpretationusergroupaccesses_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.interpretationusergroupaccesses
    ADD CONSTRAINT interpretationusergroupaccesses_pkey PRIMARY KEY (interpretationid, usergroupaccessid);


--
-- Name: jobconfiguration_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.jobconfiguration
    ADD CONSTRAINT jobconfiguration_pkey PRIMARY KEY (jobconfigurationid);


--
-- Name: key_deleted_object_klass_code; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.deletedobject
    ADD CONSTRAINT key_deleted_object_klass_code UNIQUE (klass, code);


--
-- Name: key_deleted_object_klass_uid; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.deletedobject
    ADD CONSTRAINT key_deleted_object_klass_uid UNIQUE (klass, uid);


--
-- Name: key_sectionnamedataset; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.section
    ADD CONSTRAINT key_sectionnamedataset UNIQUE (name, datasetid);


--
-- Name: keyjsonvalue_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.keyjsonvalue
    ADD CONSTRAINT keyjsonvalue_pkey PRIMARY KEY (keyjsonvalueid);


--
-- Name: keyjsonvalue_unique_key_in_namespace; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.keyjsonvalue
    ADD CONSTRAINT keyjsonvalue_unique_key_in_namespace UNIQUE (namespace, namespacekey);


--
-- Name: legendsetattributevalues_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.legendsetattributevalues
    ADD CONSTRAINT legendsetattributevalues_pkey PRIMARY KEY (legendsetid, attributevalueid);


--
-- Name: legendsetuseraccesses_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.legendsetuseraccesses
    ADD CONSTRAINT legendsetuseraccesses_pkey PRIMARY KEY (maplegendsetid, useraccessid);


--
-- Name: legendsetusergroupaccesses_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.legendsetusergroupaccesses
    ADD CONSTRAINT legendsetusergroupaccesses_pkey PRIMARY KEY (maplegendsetid, usergroupaccessid);


--
-- Name: lockexception_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.lockexception
    ADD CONSTRAINT lockexception_pkey PRIMARY KEY (lockexceptionid);


--
-- Name: map_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.map
    ADD CONSTRAINT map_pkey PRIMARY KEY (mapid);


--
-- Name: maplegend_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.maplegend
    ADD CONSTRAINT maplegend_pkey PRIMARY KEY (maplegendid);


--
-- Name: maplegendset_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.maplegendset
    ADD CONSTRAINT maplegendset_pkey PRIMARY KEY (maplegendsetid);


--
-- Name: maplegendsettranslations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.maplegendsettranslations
    ADD CONSTRAINT maplegendsettranslations_pkey PRIMARY KEY (maplegendsetid, objecttranslationid);


--
-- Name: maplegendtranslations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.maplegendtranslations
    ADD CONSTRAINT maplegendtranslations_pkey PRIMARY KEY (maplegendid, objecttranslationid);


--
-- Name: mapmapviews_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.mapmapviews
    ADD CONSTRAINT mapmapviews_pkey PRIMARY KEY (mapid, sort_order);


--
-- Name: mapuseraccesses_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.mapuseraccesses
    ADD CONSTRAINT mapuseraccesses_pkey PRIMARY KEY (mapid, useraccessid);


--
-- Name: mapusergroupaccesses_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.mapusergroupaccesses
    ADD CONSTRAINT mapusergroupaccesses_pkey PRIMARY KEY (mapid, usergroupaccessid);


--
-- Name: mapview_attributedimensions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.mapview_attributedimensions
    ADD CONSTRAINT mapview_attributedimensions_pkey PRIMARY KEY (mapviewid, sort_order);


--
-- Name: mapview_columns_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.mapview_columns
    ADD CONSTRAINT mapview_columns_pkey PRIMARY KEY (mapviewid, sort_order);


--
-- Name: mapview_datadimensionitems_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.mapview_datadimensionitems
    ADD CONSTRAINT mapview_datadimensionitems_pkey PRIMARY KEY (mapviewid, sort_order);


--
-- Name: mapview_dataelementdimensions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.mapview_dataelementdimensions
    ADD CONSTRAINT mapview_dataelementdimensions_pkey PRIMARY KEY (mapviewid, sort_order);


--
-- Name: mapview_itemorgunitgroups_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.mapview_itemorgunitgroups
    ADD CONSTRAINT mapview_itemorgunitgroups_pkey PRIMARY KEY (mapviewid, sort_order);


--
-- Name: mapview_organisationunits_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.mapview_organisationunits
    ADD CONSTRAINT mapview_organisationunits_pkey PRIMARY KEY (mapviewid, sort_order);


--
-- Name: mapview_orgunitlevels_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.mapview_orgunitlevels
    ADD CONSTRAINT mapview_orgunitlevels_pkey PRIMARY KEY (mapviewid, sort_order);


--
-- Name: mapview_periods_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.mapview_periods
    ADD CONSTRAINT mapview_periods_pkey PRIMARY KEY (mapviewid, sort_order);


--
-- Name: mapview_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.mapview
    ADD CONSTRAINT mapview_pkey PRIMARY KEY (mapviewid);


--
-- Name: mapviewtranslations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.mapviewtranslations
    ADD CONSTRAINT mapviewtranslations_pkey PRIMARY KEY (mapviewid, objecttranslationid);


--
-- Name: message_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.message
    ADD CONSTRAINT message_pkey PRIMARY KEY (messageid);


--
-- Name: messageconversation_messages_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.messageconversation_messages
    ADD CONSTRAINT messageconversation_messages_pkey PRIMARY KEY (messageconversationid, sort_order);


--
-- Name: messageconversation_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.messageconversation
    ADD CONSTRAINT messageconversation_pkey PRIMARY KEY (messageconversationid);


--
-- Name: messageconversation_usermessages_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.messageconversation_usermessages
    ADD CONSTRAINT messageconversation_usermessages_pkey PRIMARY KEY (messageconversationid, usermessageid);


--
-- Name: metadataaudit_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.metadataaudit
    ADD CONSTRAINT metadataaudit_pkey PRIMARY KEY (metadataauditid);


--
-- Name: metadataversion_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.metadataversion
    ADD CONSTRAINT metadataversion_pkey PRIMARY KEY (versionid);


--
-- Name: minmaxdataelement_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.minmaxdataelement
    ADD CONSTRAINT minmaxdataelement_pkey PRIMARY KEY (minmaxdataelementid);


--
-- Name: minmaxdataelement_unique_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.minmaxdataelement
    ADD CONSTRAINT minmaxdataelement_unique_key UNIQUE (sourceid, dataelementid, categoryoptioncomboid);


--
-- Name: oauth2client_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.oauth2client
    ADD CONSTRAINT oauth2client_pkey PRIMARY KEY (oauth2clientid);


--
-- Name: oauth2clientgranttypes_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.oauth2clientgranttypes
    ADD CONSTRAINT oauth2clientgranttypes_pkey PRIMARY KEY (oauth2clientid, sort_order);


--
-- Name: oauth2clientredirecturis_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.oauth2clientredirecturis
    ADD CONSTRAINT oauth2clientredirecturis_pkey PRIMARY KEY (oauth2clientid, sort_order);


--
-- Name: oauth_access_token_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.oauth_access_token
    ADD CONSTRAINT oauth_access_token_pkey PRIMARY KEY (authentication_id);


--
-- Name: objecttranslation_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.objecttranslation
    ADD CONSTRAINT objecttranslation_pkey PRIMARY KEY (objecttranslationid);


--
-- Name: optionattributevalues_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.optionattributevalues
    ADD CONSTRAINT optionattributevalues_pkey PRIMARY KEY (optionvalueid, attributevalueid);


--
-- Name: optiongroup_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.optiongroup
    ADD CONSTRAINT optiongroup_pkey PRIMARY KEY (optiongroupid);


--
-- Name: optiongroupattributevalues_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.optiongroupattributevalues
    ADD CONSTRAINT optiongroupattributevalues_pkey PRIMARY KEY (optiongroupid, attributevalueid);


--
-- Name: optiongroupmembers_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.optiongroupmembers
    ADD CONSTRAINT optiongroupmembers_pkey PRIMARY KEY (optiongroupid, optionid);


--
-- Name: optiongroupset_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.optiongroupset
    ADD CONSTRAINT optiongroupset_pkey PRIMARY KEY (optiongroupsetid);


--
-- Name: optiongroupsetmembers_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.optiongroupsetmembers
    ADD CONSTRAINT optiongroupsetmembers_pkey PRIMARY KEY (optiongroupsetid, sort_order);


--
-- Name: optiongroupsettranslations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.optiongroupsettranslations
    ADD CONSTRAINT optiongroupsettranslations_pkey PRIMARY KEY (optiongroupsetid, objecttranslationid);


--
-- Name: optiongroupsetuseraccesses_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.optiongroupsetuseraccesses
    ADD CONSTRAINT optiongroupsetuseraccesses_pkey PRIMARY KEY (optiongroupsetid, useraccessid);


--
-- Name: optiongroupsetusergroupaccesses_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.optiongroupsetusergroupaccesses
    ADD CONSTRAINT optiongroupsetusergroupaccesses_pkey PRIMARY KEY (optiongroupsetid, usergroupaccessid);


--
-- Name: optiongrouptranslations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.optiongrouptranslations
    ADD CONSTRAINT optiongrouptranslations_pkey PRIMARY KEY (optiongroupid, objecttranslationid);


--
-- Name: optiongroupuseraccesses_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.optiongroupuseraccesses
    ADD CONSTRAINT optiongroupuseraccesses_pkey PRIMARY KEY (optiongroupid, useraccessid);


--
-- Name: optiongroupusergroupaccesses_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.optiongroupusergroupaccesses
    ADD CONSTRAINT optiongroupusergroupaccesses_pkey PRIMARY KEY (optiongroupid, usergroupaccessid);


--
-- Name: optionset_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.optionset
    ADD CONSTRAINT optionset_pkey PRIMARY KEY (optionsetid);


--
-- Name: optionsetattributevalues_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.optionsetattributevalues
    ADD CONSTRAINT optionsetattributevalues_pkey PRIMARY KEY (optionsetid, attributevalueid);


--
-- Name: optionsettranslations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.optionsettranslations
    ADD CONSTRAINT optionsettranslations_pkey PRIMARY KEY (optionsetid, objecttranslationid);


--
-- Name: optionsetuseraccesses_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.optionsetuseraccesses
    ADD CONSTRAINT optionsetuseraccesses_pkey PRIMARY KEY (optionsetid, useraccessid);


--
-- Name: optionsetusergroupaccesses_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.optionsetusergroupaccesses
    ADD CONSTRAINT optionsetusergroupaccesses_pkey PRIMARY KEY (optionsetid, usergroupaccessid);


--
-- Name: optionvalue_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.optionvalue
    ADD CONSTRAINT optionvalue_pkey PRIMARY KEY (optionvalueid);


--
-- Name: optionvaluetranslations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.optionvaluetranslations
    ADD CONSTRAINT optionvaluetranslations_pkey PRIMARY KEY (optionvalueid, objecttranslationid);


--
-- Name: organisationunit_code_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.organisationunit
    ADD CONSTRAINT organisationunit_code_key UNIQUE (code);


--
-- Name: organisationunit_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.organisationunit
    ADD CONSTRAINT organisationunit_pkey PRIMARY KEY (organisationunitid);


--
-- Name: organisationunitattributevalues_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.organisationunitattributevalues
    ADD CONSTRAINT organisationunitattributevalues_pkey PRIMARY KEY (organisationunitid, attributevalueid);


--
-- Name: organisationunittranslations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.organisationunittranslations
    ADD CONSTRAINT organisationunittranslations_pkey PRIMARY KEY (organisationunitid, objecttranslationid);


--
-- Name: orgunitgroup_name_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.orgunitgroup
    ADD CONSTRAINT orgunitgroup_name_key UNIQUE (name);


--
-- Name: orgunitgroup_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.orgunitgroup
    ADD CONSTRAINT orgunitgroup_pkey PRIMARY KEY (orgunitgroupid);


--
-- Name: orgunitgroupattributevalues_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.orgunitgroupattributevalues
    ADD CONSTRAINT orgunitgroupattributevalues_pkey PRIMARY KEY (orgunitgroupid, attributevalueid);


--
-- Name: orgunitgroupmembers_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.orgunitgroupmembers
    ADD CONSTRAINT orgunitgroupmembers_pkey PRIMARY KEY (orgunitgroupid, organisationunitid);


--
-- Name: orgunitgroupset_name_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.orgunitgroupset
    ADD CONSTRAINT orgunitgroupset_name_key UNIQUE (name);


--
-- Name: orgunitgroupset_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.orgunitgroupset
    ADD CONSTRAINT orgunitgroupset_pkey PRIMARY KEY (orgunitgroupsetid);


--
-- Name: orgunitgroupsetattributevalues_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.orgunitgroupsetattributevalues
    ADD CONSTRAINT orgunitgroupsetattributevalues_pkey PRIMARY KEY (orgunitgroupsetid, attributevalueid);


--
-- Name: orgunitgroupsetdimension_items_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.orgunitgroupsetdimension_items
    ADD CONSTRAINT orgunitgroupsetdimension_items_pkey PRIMARY KEY (orgunitgroupsetdimensionid, sort_order);


--
-- Name: orgunitgroupsetdimension_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.orgunitgroupsetdimension
    ADD CONSTRAINT orgunitgroupsetdimension_pkey PRIMARY KEY (orgunitgroupsetdimensionid);


--
-- Name: orgunitgroupsetmembers_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.orgunitgroupsetmembers
    ADD CONSTRAINT orgunitgroupsetmembers_pkey PRIMARY KEY (orgunitgroupsetid, orgunitgroupid);


--
-- Name: orgunitgroupsettranslations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.orgunitgroupsettranslations
    ADD CONSTRAINT orgunitgroupsettranslations_pkey PRIMARY KEY (orgunitgroupsetid, objecttranslationid);


--
-- Name: orgunitgroupsetuseraccesses_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.orgunitgroupsetuseraccesses
    ADD CONSTRAINT orgunitgroupsetuseraccesses_pkey PRIMARY KEY (orgunitgroupsetid, useraccessid);


--
-- Name: orgunitgroupsetusergroupaccesses_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.orgunitgroupsetusergroupaccesses
    ADD CONSTRAINT orgunitgroupsetusergroupaccesses_pkey PRIMARY KEY (orgunitgroupsetid, usergroupaccessid);


--
-- Name: orgunitgrouptranslations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.orgunitgrouptranslations
    ADD CONSTRAINT orgunitgrouptranslations_pkey PRIMARY KEY (orgunitgroupid, objecttranslationid);


--
-- Name: orgunitgroupuseraccesses_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.orgunitgroupuseraccesses
    ADD CONSTRAINT orgunitgroupuseraccesses_pkey PRIMARY KEY (orgunitgroupid, useraccessid);


--
-- Name: orgunitgroupusergroupaccesses_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.orgunitgroupusergroupaccesses
    ADD CONSTRAINT orgunitgroupusergroupaccesses_pkey PRIMARY KEY (orgunitgroupid, usergroupaccessid);


--
-- Name: orgunitlevel_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.orgunitlevel
    ADD CONSTRAINT orgunitlevel_pkey PRIMARY KEY (orgunitlevelid);


--
-- Name: orgunitleveltranslations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.orgunitleveltranslations
    ADD CONSTRAINT orgunitleveltranslations_pkey PRIMARY KEY (orgunitlevelid, objecttranslationid);


--
-- Name: outbound_sms_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.outbound_sms
    ADD CONSTRAINT outbound_sms_pkey PRIMARY KEY (id);


--
-- Name: period_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.period
    ADD CONSTRAINT period_pkey PRIMARY KEY (periodid);


--
-- Name: periodtype_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.periodtype
    ADD CONSTRAINT periodtype_pkey PRIMARY KEY (periodtypeid);


--
-- Name: predictor_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.predictor
    ADD CONSTRAINT predictor_pkey PRIMARY KEY (predictorid);


--
-- Name: predictororgunitlevels_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.predictororgunitlevels
    ADD CONSTRAINT predictororgunitlevels_pkey PRIMARY KEY (predictorid, orgunitlevelid);


--
-- Name: previouspasswords_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.previouspasswords
    ADD CONSTRAINT previouspasswords_pkey PRIMARY KEY (userid, list_index);


--
-- Name: program_attribute_group_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.program_attribute_group
    ADD CONSTRAINT program_attribute_group_pkey PRIMARY KEY (programtrackedentityattributegroupid);


--
-- Name: program_attributes_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.program_attributes
    ADD CONSTRAINT program_attributes_pkey PRIMARY KEY (programtrackedentityattributeid);


--
-- Name: program_criteria_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.program_criteria
    ADD CONSTRAINT program_criteria_pkey PRIMARY KEY (programid, validationcriteriaid);


--
-- Name: program_organisationunits_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.program_organisationunits
    ADD CONSTRAINT program_organisationunits_pkey PRIMARY KEY (programid, organisationunitid);


--
-- Name: program_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.program
    ADD CONSTRAINT program_pkey PRIMARY KEY (programid);


--
-- Name: programattributevalues_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.programattributevalues
    ADD CONSTRAINT programattributevalues_pkey PRIMARY KEY (programid, attributevalueid);


--
-- Name: programexpression_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.programexpression
    ADD CONSTRAINT programexpression_pkey PRIMARY KEY (programexpressionid);


--
-- Name: programindicator_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.programindicator
    ADD CONSTRAINT programindicator_pkey PRIMARY KEY (programindicatorid);


--
-- Name: programindicatorattributevalues_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.programindicatorattributevalues
    ADD CONSTRAINT programindicatorattributevalues_pkey PRIMARY KEY (programindicatorid, attributevalueid);


--
-- Name: programindicatorgroup_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.programindicatorgroup
    ADD CONSTRAINT programindicatorgroup_pkey PRIMARY KEY (programindicatorgroupid);


--
-- Name: programindicatorgroupattributevalues_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.programindicatorgroupattributevalues
    ADD CONSTRAINT programindicatorgroupattributevalues_pkey PRIMARY KEY (programindicatorgroupid, attributevalueid);


--
-- Name: programindicatorgroupmembers_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.programindicatorgroupmembers
    ADD CONSTRAINT programindicatorgroupmembers_pkey PRIMARY KEY (programindicatorgroupid, programindicatorid);


--
-- Name: programindicatorgrouptranslations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.programindicatorgrouptranslations
    ADD CONSTRAINT programindicatorgrouptranslations_pkey PRIMARY KEY (programindicatorgroupid, objecttranslationid);


--
-- Name: programindicatorgroupuseraccesses_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.programindicatorgroupuseraccesses
    ADD CONSTRAINT programindicatorgroupuseraccesses_pkey PRIMARY KEY (programindicatorgroupid, useraccessid);


--
-- Name: programindicatorgroupusergroupaccesses_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.programindicatorgroupusergroupaccesses
    ADD CONSTRAINT programindicatorgroupusergroupaccesses_pkey PRIMARY KEY (programindicatorgroupid, usergroupaccessid);


--
-- Name: programindicatorlegendsets_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.programindicatorlegendsets
    ADD CONSTRAINT programindicatorlegendsets_pkey PRIMARY KEY (programindicatorid, sort_order);


--
-- Name: programindicatortranslations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.programindicatortranslations
    ADD CONSTRAINT programindicatortranslations_pkey PRIMARY KEY (programindicatorid, objecttranslationid);


--
-- Name: programindicatoruseraccesses_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.programindicatoruseraccesses
    ADD CONSTRAINT programindicatoruseraccesses_pkey PRIMARY KEY (programindicatorid, useraccessid);


--
-- Name: programindicatorusergroupaccesses_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.programindicatorusergroupaccesses
    ADD CONSTRAINT programindicatorusergroupaccesses_pkey PRIMARY KEY (programindicatorid, usergroupaccessid);


--
-- Name: programinstance_messageconversation_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.programinstance_messageconversation
    ADD CONSTRAINT programinstance_messageconversation_pkey PRIMARY KEY (programinstanceid, sort_order);


--
-- Name: programinstance_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.programinstance
    ADD CONSTRAINT programinstance_pkey PRIMARY KEY (programinstanceid);


--
-- Name: programinstancecomments_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.programinstancecomments
    ADD CONSTRAINT programinstancecomments_pkey PRIMARY KEY (programinstanceid, sort_order);


--
-- Name: programmessage_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.programmessage
    ADD CONSTRAINT programmessage_pkey PRIMARY KEY (id);


--
-- Name: programmessagetranslations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.programmessagetranslations
    ADD CONSTRAINT programmessagetranslations_pkey PRIMARY KEY (id, objecttranslationid);


--
-- Name: programnotificationtemplate_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.programnotificationtemplate
    ADD CONSTRAINT programnotificationtemplate_pkey PRIMARY KEY (programnotificationtemplateid);


--
-- Name: programrule_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.programrule
    ADD CONSTRAINT programrule_pkey PRIMARY KEY (programruleid);


--
-- Name: programruleaction_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.programruleaction
    ADD CONSTRAINT programruleaction_pkey PRIMARY KEY (programruleactionid);


--
-- Name: programruletranslations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.programruletranslations
    ADD CONSTRAINT programruletranslations_pkey PRIMARY KEY (programruleid, objecttranslationid);


--
-- Name: programrulevariable_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.programrulevariable
    ADD CONSTRAINT programrulevariable_pkey PRIMARY KEY (programrulevariableid);


--
-- Name: programsection_attributes_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.programsection_attributes
    ADD CONSTRAINT programsection_attributes_pkey PRIMARY KEY (programsectionid, sort_order);


--
-- Name: programsection_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.programsection
    ADD CONSTRAINT programsection_pkey PRIMARY KEY (programsectionid);


--
-- Name: programsectiontranslations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.programsectiontranslations
    ADD CONSTRAINT programsectiontranslations_pkey PRIMARY KEY (programsectionid, objecttranslationid);


--
-- Name: programstage_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.programstage
    ADD CONSTRAINT programstage_pkey PRIMARY KEY (programstageid);


--
-- Name: programstageattributevalues_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.programstageattributevalues
    ADD CONSTRAINT programstageattributevalues_pkey PRIMARY KEY (programstageid, attributevalueid);


--
-- Name: programstagedataelement_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.programstagedataelement
    ADD CONSTRAINT programstagedataelement_pkey PRIMARY KEY (programstagedataelementid);


--
-- Name: programstagedataelement_unique_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.programstagedataelement
    ADD CONSTRAINT programstagedataelement_unique_key UNIQUE (programstageid, dataelementid);


--
-- Name: programstageinstance_messageconversation_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.programstageinstance_messageconversation
    ADD CONSTRAINT programstageinstance_messageconversation_pkey PRIMARY KEY (programstageinstanceid, sort_order);


--
-- Name: programstageinstance_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.programstageinstance
    ADD CONSTRAINT programstageinstance_pkey PRIMARY KEY (programstageinstanceid);


--
-- Name: programstageinstancecomments_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.programstageinstancecomments
    ADD CONSTRAINT programstageinstancecomments_pkey PRIMARY KEY (programstageinstanceid, sort_order);


--
-- Name: programstagesection_dataelements_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.programstagesection_dataelements
    ADD CONSTRAINT programstagesection_dataelements_pkey PRIMARY KEY (programstagesectionid, sort_order);


--
-- Name: programstagesection_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.programstagesection
    ADD CONSTRAINT programstagesection_pkey PRIMARY KEY (programstagesectionid);


--
-- Name: programstagesection_programindicators_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.programstagesection_programindicators
    ADD CONSTRAINT programstagesection_programindicators_pkey PRIMARY KEY (programstagesectionid, sort_order);


--
-- Name: programstagesectiontranslations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.programstagesectiontranslations
    ADD CONSTRAINT programstagesectiontranslations_pkey PRIMARY KEY (programstagesectionid, objecttranslationid);


--
-- Name: programstagetranslations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.programstagetranslations
    ADD CONSTRAINT programstagetranslations_pkey PRIMARY KEY (programstageid, objecttranslationid);


--
-- Name: programstageuseraccesses_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.programstageuseraccesses
    ADD CONSTRAINT programstageuseraccesses_pkey PRIMARY KEY (programstageid, useraccessid);


--
-- Name: programstageusergroupaccesses_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.programstageusergroupaccesses
    ADD CONSTRAINT programstageusergroupaccesses_pkey PRIMARY KEY (programid, usergroupaccessid);


--
-- Name: programtrackedentityattribute_unique_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.program_attributes
    ADD CONSTRAINT programtrackedentityattribute_unique_key UNIQUE (programid, trackedentityattributeid);


--
-- Name: programtrackedentityattributegroupmembers_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.programtrackedentityattributegroupmembers
    ADD CONSTRAINT programtrackedentityattributegroupmembers_pkey PRIMARY KEY (programtrackedentityattributeid, programtrackedentityattributegroupid);


--
-- Name: programtrackedentityattributegrouptranslations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.programtrackedentityattributegrouptranslations
    ADD CONSTRAINT programtrackedentityattributegrouptranslations_pkey PRIMARY KEY (programtrackedentityattributegroupid, objecttranslationid);


--
-- Name: programtranslations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.programtranslations
    ADD CONSTRAINT programtranslations_pkey PRIMARY KEY (programid, objecttranslationid);


--
-- Name: programuseraccesses_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.programuseraccesses
    ADD CONSTRAINT programuseraccesses_pkey PRIMARY KEY (programid, useraccessid);


--
-- Name: programusergroupaccesses_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.programusergroupaccesses
    ADD CONSTRAINT programusergroupaccesses_pkey PRIMARY KEY (programid, usergroupaccessid);


--
-- Name: pushanalysis_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pushanalysis
    ADD CONSTRAINT pushanalysis_pkey PRIMARY KEY (pushanalysisid);


--
-- Name: pushanalysisrecipientusergroups_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pushanalysisrecipientusergroups
    ADD CONSTRAINT pushanalysisrecipientusergroups_pkey PRIMARY KEY (usergroupid, elt);


--
-- Name: relationship_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.relationship
    ADD CONSTRAINT relationship_pkey PRIMARY KEY (relationshipid);


--
-- Name: relationshiptype_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.relationshiptype
    ADD CONSTRAINT relationshiptype_pkey PRIMARY KEY (relationshiptypeid);


--
-- Name: relationshiptypetranslations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.relationshiptypetranslations
    ADD CONSTRAINT relationshiptypetranslations_pkey PRIMARY KEY (relationshiptypeid, objecttranslationid);


--
-- Name: relativeperiods_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.relativeperiods
    ADD CONSTRAINT relativeperiods_pkey PRIMARY KEY (relativeperiodsid);


--
-- Name: report_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.report
    ADD CONSTRAINT report_pkey PRIMARY KEY (reportid);


--
-- Name: reporttable_categorydimensions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.reporttable_categorydimensions
    ADD CONSTRAINT reporttable_categorydimensions_pkey PRIMARY KEY (reporttableid, sort_order);


--
-- Name: reporttable_categoryoptiongroupsetdimensions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.reporttable_categoryoptiongroupsetdimensions
    ADD CONSTRAINT reporttable_categoryoptiongroupsetdimensions_pkey PRIMARY KEY (reporttableid, sort_order);


--
-- Name: reporttable_columns_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.reporttable_columns
    ADD CONSTRAINT reporttable_columns_pkey PRIMARY KEY (reporttableid, sort_order);


--
-- Name: reporttable_datadimensionitems_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.reporttable_datadimensionitems
    ADD CONSTRAINT reporttable_datadimensionitems_pkey PRIMARY KEY (reporttableid, sort_order);


--
-- Name: reporttable_dataelementgroupsetdimensions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.reporttable_dataelementgroupsetdimensions
    ADD CONSTRAINT reporttable_dataelementgroupsetdimensions_pkey PRIMARY KEY (reporttableid, sort_order);


--
-- Name: reporttable_filters_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.reporttable_filters
    ADD CONSTRAINT reporttable_filters_pkey PRIMARY KEY (reporttableid, sort_order);


--
-- Name: reporttable_itemorgunitgroups_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.reporttable_itemorgunitgroups
    ADD CONSTRAINT reporttable_itemorgunitgroups_pkey PRIMARY KEY (reporttableid, sort_order);


--
-- Name: reporttable_organisationunits_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.reporttable_organisationunits
    ADD CONSTRAINT reporttable_organisationunits_pkey PRIMARY KEY (reporttableid, sort_order);


--
-- Name: reporttable_orgunitgroupsetdimensions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.reporttable_orgunitgroupsetdimensions
    ADD CONSTRAINT reporttable_orgunitgroupsetdimensions_pkey PRIMARY KEY (reporttableid, sort_order);


--
-- Name: reporttable_orgunitlevels_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.reporttable_orgunitlevels
    ADD CONSTRAINT reporttable_orgunitlevels_pkey PRIMARY KEY (reporttableid, sort_order);


--
-- Name: reporttable_periods_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.reporttable_periods
    ADD CONSTRAINT reporttable_periods_pkey PRIMARY KEY (reporttableid, sort_order);


--
-- Name: reporttable_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.reporttable
    ADD CONSTRAINT reporttable_pkey PRIMARY KEY (reporttableid);


--
-- Name: reporttable_rows_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.reporttable_rows
    ADD CONSTRAINT reporttable_rows_pkey PRIMARY KEY (reporttableid, sort_order);


--
-- Name: reporttabletranslations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.reporttabletranslations
    ADD CONSTRAINT reporttabletranslations_pkey PRIMARY KEY (reporttableid, objecttranslationid);


--
-- Name: reporttableuseraccesses_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.reporttableuseraccesses
    ADD CONSTRAINT reporttableuseraccesses_pkey PRIMARY KEY (reporttableid, useraccessid);


--
-- Name: reporttableusergroupaccesses_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.reporttableusergroupaccesses
    ADD CONSTRAINT reporttableusergroupaccesses_pkey PRIMARY KEY (reporttableid, usergroupaccessid);


--
-- Name: reporttranslations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.reporttranslations
    ADD CONSTRAINT reporttranslations_pkey PRIMARY KEY (reportid, objecttranslationid);


--
-- Name: reportuseraccesses_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.reportuseraccesses
    ADD CONSTRAINT reportuseraccesses_pkey PRIMARY KEY (reportid, useraccessid);


--
-- Name: reportusergroupaccesses_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.reportusergroupaccesses
    ADD CONSTRAINT reportusergroupaccesses_pkey PRIMARY KEY (reportid, usergroupaccessid);


--
-- Name: reservedvalue_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.reservedvalue
    ADD CONSTRAINT reservedvalue_pkey PRIMARY KEY (reservedvalueid);


--
-- Name: section_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.section
    ADD CONSTRAINT section_pkey PRIMARY KEY (sectionid);


--
-- Name: sectionattributevalues_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sectionattributevalues
    ADD CONSTRAINT sectionattributevalues_pkey PRIMARY KEY (sectionid, attributevalueid);


--
-- Name: sectiondataelements_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sectiondataelements
    ADD CONSTRAINT sectiondataelements_pkey PRIMARY KEY (sectionid, sort_order);


--
-- Name: sectiongreyedfields_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sectiongreyedfields
    ADD CONSTRAINT sectiongreyedfields_pkey PRIMARY KEY (sectionid, dataelementoperandid);


--
-- Name: sectionindicators_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sectionindicators
    ADD CONSTRAINT sectionindicators_pkey PRIMARY KEY (sectionid, sort_order);


--
-- Name: sequentialnumbercounter_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sequentialnumbercounter
    ADD CONSTRAINT sequentialnumbercounter_pkey PRIMARY KEY (id);


--
-- Name: smscodes_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.smscodes
    ADD CONSTRAINT smscodes_pkey PRIMARY KEY (smscodeid);


--
-- Name: smscommandcodes_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.smscommandcodes
    ADD CONSTRAINT smscommandcodes_pkey PRIMARY KEY (id, codeid);


--
-- Name: smscommands_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.smscommands
    ADD CONSTRAINT smscommands_pkey PRIMARY KEY (smscommandid);


--
-- Name: smscommandspecialcharacters_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.smscommandspecialcharacters
    ADD CONSTRAINT smscommandspecialcharacters_pkey PRIMARY KEY (smscommandid, specialcharacterid);


--
-- Name: smsspecialcharacter_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.smsspecialcharacter
    ADD CONSTRAINT smsspecialcharacter_pkey PRIMARY KEY (specialcharacterid);


--
-- Name: sqlview_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sqlview
    ADD CONSTRAINT sqlview_pkey PRIMARY KEY (sqlviewid);


--
-- Name: sqlviewattributevalues_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sqlviewattributevalues
    ADD CONSTRAINT sqlviewattributevalues_pkey PRIMARY KEY (sqlviewid, attributevalueid);


--
-- Name: sqlviewuseraccesses_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sqlviewuseraccesses
    ADD CONSTRAINT sqlviewuseraccesses_pkey PRIMARY KEY (sqlviewid, useraccessid);


--
-- Name: sqlviewusergroupaccesses_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sqlviewusergroupaccesses
    ADD CONSTRAINT sqlviewusergroupaccesses_pkey PRIMARY KEY (sqlviewid, usergroupaccessid);


--
-- Name: systemsetting_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.systemsetting
    ADD CONSTRAINT systemsetting_pkey PRIMARY KEY (systemsettingid);


--
-- Name: tablehook_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tablehook
    ADD CONSTRAINT tablehook_pkey PRIMARY KEY (analyticstablehookid);


--
-- Name: trackedentityattribute_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.trackedentityattribute
    ADD CONSTRAINT trackedentityattribute_pkey PRIMARY KEY (trackedentityattributeid);


--
-- Name: trackedentityattributeattributevalues_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.trackedentityattributeattributevalues
    ADD CONSTRAINT trackedentityattributeattributevalues_pkey PRIMARY KEY (trackedentityattributeid, attributevalueid);


--
-- Name: trackedentityattributedimension_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.trackedentityattributedimension
    ADD CONSTRAINT trackedentityattributedimension_pkey PRIMARY KEY (trackedentityattributedimensionid);


--
-- Name: trackedentityattributelegendsets_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.trackedentityattributelegendsets
    ADD CONSTRAINT trackedentityattributelegendsets_pkey PRIMARY KEY (trackedentityattributeid, sort_order);


--
-- Name: trackedentityattributetranslations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.trackedentityattributetranslations
    ADD CONSTRAINT trackedentityattributetranslations_pkey PRIMARY KEY (trackedentityattributeid, objecttranslationid);


--
-- Name: trackedentityattributeuseraccesses_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.trackedentityattributeuseraccesses
    ADD CONSTRAINT trackedentityattributeuseraccesses_pkey PRIMARY KEY (trackedentityattributeid, useraccessid);


--
-- Name: trackedentityattributeusergroupaccesses_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.trackedentityattributeusergroupaccesses
    ADD CONSTRAINT trackedentityattributeusergroupaccesses_pkey PRIMARY KEY (trackedentityattributeid, usergroupaccessid);


--
-- Name: trackedentityattributevalue_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.trackedentityattributevalue
    ADD CONSTRAINT trackedentityattributevalue_pkey PRIMARY KEY (trackedentityinstanceid, trackedentityattributeid);


--
-- Name: trackedentityattributevalueaudit_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.trackedentityattributevalueaudit
    ADD CONSTRAINT trackedentityattributevalueaudit_pkey PRIMARY KEY (trackedentityattributevalueauditid);


--
-- Name: trackedentitycomment_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.trackedentitycomment
    ADD CONSTRAINT trackedentitycomment_pkey PRIMARY KEY (trackedentitycommentid);


--
-- Name: trackedentitydataelementdimension_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.trackedentitydataelementdimension
    ADD CONSTRAINT trackedentitydataelementdimension_pkey PRIMARY KEY (trackedentitydataelementdimensionid);


--
-- Name: trackedentitydatavalue_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.trackedentitydatavalue
    ADD CONSTRAINT trackedentitydatavalue_pkey PRIMARY KEY (programstageinstanceid, dataelementid);


--
-- Name: trackedentitydatavalueaudit_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.trackedentitydatavalueaudit
    ADD CONSTRAINT trackedentitydatavalueaudit_pkey PRIMARY KEY (trackedentitydatavalueauditid);


--
-- Name: trackedentityinstance_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.trackedentityinstance
    ADD CONSTRAINT trackedentityinstance_pkey PRIMARY KEY (trackedentityinstanceid);


--
-- Name: trackedentityinstancefilter_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.trackedentityinstancefilter
    ADD CONSTRAINT trackedentityinstancefilter_pkey PRIMARY KEY (trackedentityinstancefilterid);


--
-- Name: trackedentityprogramindicatordimension_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.trackedentityprogramindicatordimension
    ADD CONSTRAINT trackedentityprogramindicatordimension_pkey PRIMARY KEY (trackedentityprogramindicatordimensionid);


--
-- Name: trackedentitytranslations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.trackedentitytranslations
    ADD CONSTRAINT trackedentitytranslations_pkey PRIMARY KEY (trackedentitytypeid, objecttranslationid);


--
-- Name: trackedentitytype_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.trackedentitytype
    ADD CONSTRAINT trackedentitytype_pkey PRIMARY KEY (trackedentitytypeid);


--
-- Name: trackedentitytypeattribute_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.trackedentitytypeattribute
    ADD CONSTRAINT trackedentitytypeattribute_pkey PRIMARY KEY (trackedentitytypeattributeid);


--
-- Name: trackedentitytypeattributevalues_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.trackedentitytypeattributevalues
    ADD CONSTRAINT trackedentitytypeattributevalues_pkey PRIMARY KEY (trackedentitytypeid, attributevalueid);


--
-- Name: trackedentitytypeuseraccesses_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.trackedentitytypeuseraccesses
    ADD CONSTRAINT trackedentitytypeuseraccesses_pkey PRIMARY KEY (trackedentitytypeid, useraccessid);


--
-- Name: trackedentitytypeusergroupaccesses_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.trackedentitytypeusergroupaccesses
    ADD CONSTRAINT trackedentitytypeusergroupaccesses_pkey PRIMARY KEY (trackedentitytypeid, usergroupaccessid);


--
-- Name: uk_10sblshxcb7dd4qi3s879u35h; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.trackedentitytypeattribute
    ADD CONSTRAINT uk_10sblshxcb7dd4qi3s879u35h UNIQUE (uid);


--
-- Name: uk_13x63e3skbl5qj4mc1qgq2xex; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.validationrule
    ADD CONSTRAINT uk_13x63e3skbl5qj4mc1qgq2xex UNIQUE (code);


--
-- Name: uk_15y1nx8cgycww2m802kwqqhp0; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.orgunitgrouptranslations
    ADD CONSTRAINT uk_15y1nx8cgycww2m802kwqqhp0 UNIQUE (objecttranslationid);


--
-- Name: uk_1774shfid1uaopl9tu8am19fq; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.attribute
    ADD CONSTRAINT uk_1774shfid1uaopl9tu8am19fq UNIQUE (code);


--
-- Name: uk_18b68rcofdwt1sbr6rf55poog; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.optionvalue
    ADD CONSTRAINT uk_18b68rcofdwt1sbr6rf55poog UNIQUE (uid);


--
-- Name: uk_191y3j7pfufwrenbd2h9q3pek; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.chartusergroupaccesses
    ADD CONSTRAINT uk_191y3j7pfufwrenbd2h9q3pek UNIQUE (usergroupaccessid);


--
-- Name: uk_1bfr83at04owfxcj0ihpju132; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.optiongroupuseraccesses
    ADD CONSTRAINT uk_1bfr83at04owfxcj0ihpju132 UNIQUE (useraccessid);


--
-- Name: uk_1dw8gju4leg7iud4gpsr5r1ng; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.mapview
    ADD CONSTRAINT uk_1dw8gju4leg7iud4gpsr5r1ng UNIQUE (uid);


--
-- Name: uk_1ev6xqtcsfr4wv6rel0lkg44n; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dataelementcategory
    ADD CONSTRAINT uk_1ev6xqtcsfr4wv6rel0lkg44n UNIQUE (uid);


--
-- Name: uk_1film7lsn5m1wyeku7yh5anfa; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.optiongroupsetmembers
    ADD CONSTRAINT uk_1film7lsn5m1wyeku7yh5anfa UNIQUE (optiongroupid);


--
-- Name: uk_1ho4mnbv5ukfj4i5cc01vytbc; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.programruletranslations
    ADD CONSTRAINT uk_1ho4mnbv5ukfj4i5cc01vytbc UNIQUE (objecttranslationid);


--
-- Name: uk_1ie06vhy3begtwuuvrv0f71se; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.report
    ADD CONSTRAINT uk_1ie06vhy3begtwuuvrv0f71se UNIQUE (uid);


--
-- Name: uk_1lvk8ftq028jrr28qouou9q3c; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.validationrulegroup
    ADD CONSTRAINT uk_1lvk8ftq028jrr28qouou9q3c UNIQUE (code);


--
-- Name: uk_1n7xvxj0jupob5f2v86cv8qer; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.programstageinstancecomments
    ADD CONSTRAINT uk_1n7xvxj0jupob5f2v86cv8qer UNIQUE (trackedentitycommentid);


--
-- Name: uk_1naq88t24viefq6h7lcx3lbx4; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.programusergroupaccesses
    ADD CONSTRAINT uk_1naq88t24viefq6h7lcx3lbx4 UNIQUE (usergroupaccessid);


--
-- Name: uk_1qlw3rts2pog96ye7r6fqd122; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.programmessage
    ADD CONSTRAINT uk_1qlw3rts2pog96ye7r6fqd122 UNIQUE (uid);


--
-- Name: uk_1sp445tglu49hyfwokjqn5bf6; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.chart
    ADD CONSTRAINT uk_1sp445tglu49hyfwokjqn5bf6 UNIQUE (uid);


--
-- Name: uk_1tcaydw2p91wi8ib0qqa1jcfs; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.program
    ADD CONSTRAINT uk_1tcaydw2p91wi8ib0qqa1jcfs UNIQUE (shortname);


--
-- Name: uk_1wvaptfvodonfldfc8cj1wosq; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dataelementgrouptranslations
    ADD CONSTRAINT uk_1wvaptfvodonfldfc8cj1wosq UNIQUE (objecttranslationid);


--
-- Name: uk_1xk8j7j0a3li8o0ukblanosky; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dataelementgroupset
    ADD CONSTRAINT uk_1xk8j7j0a3li8o0ukblanosky UNIQUE (name);


--
-- Name: uk_22wt9yk9idujmywno44v9qf66; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.programstagesection
    ADD CONSTRAINT uk_22wt9yk9idujmywno44v9qf66 UNIQUE (code);


--
-- Name: uk_284n4lyg7j1g56mab44dyikvx; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.documentuseraccesses
    ADD CONSTRAINT uk_284n4lyg7j1g56mab44dyikvx UNIQUE (useraccessid);


--
-- Name: uk_287ampe6pn4aepyn14hv71907; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.categoryoptiongroupattributevalues
    ADD CONSTRAINT uk_287ampe6pn4aepyn14hv71907 UNIQUE (attributevalueid);


--
-- Name: uk_2boebaetgus89t1k8nn4dac65; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.optiongroupset
    ADD CONSTRAINT uk_2boebaetgus89t1k8nn4dac65 UNIQUE (uid);


--
-- Name: uk_2dhynycj6yhlt3p2a4lfnxi1; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dataapprovalleveluseraccesses
    ADD CONSTRAINT uk_2dhynycj6yhlt3p2a4lfnxi1 UNIQUE (useraccessid);


--
-- Name: uk_2ejl9l5vm4rhtqj8eit31g0u6; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.programstagedataelement
    ADD CONSTRAINT uk_2ejl9l5vm4rhtqj8eit31g0u6 UNIQUE (code);


--
-- Name: uk_2l0ovv74pjtairmeyiwy4i2ui; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.i18nlocale
    ADD CONSTRAINT uk_2l0ovv74pjtairmeyiwy4i2ui UNIQUE (uid);


--
-- Name: uk_2nhc265rlfu3dlc3qouvjdprl; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dataelement
    ADD CONSTRAINT uk_2nhc265rlfu3dlc3qouvjdprl UNIQUE (name);


--
-- Name: uk_2oimlmrj216imks25sfkw6jh6; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.programsectiontranslations
    ADD CONSTRAINT uk_2oimlmrj216imks25sfkw6jh6 UNIQUE (objecttranslationid);


--
-- Name: uk_2p9x16ryxtek0g6bqwd49et0c; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.programindicatorgroup
    ADD CONSTRAINT uk_2p9x16ryxtek0g6bqwd49et0c UNIQUE (uid);


--
-- Name: uk_2pimmculf9ttu2dxquomb9ram; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.programnotificationtemplate
    ADD CONSTRAINT uk_2pimmculf9ttu2dxquomb9ram UNIQUE (uid);


--
-- Name: uk_2r18tvmbtksk69j35uxpwej44; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dataapprovallevel
    ADD CONSTRAINT uk_2r18tvmbtksk69j35uxpwej44 UNIQUE (code);


--
-- Name: uk_2rwitpm8stv7hpn3jlyc2sagd; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.indicatorgroupuseraccesses
    ADD CONSTRAINT uk_2rwitpm8stv7hpn3jlyc2sagd UNIQUE (useraccessid);


--
-- Name: uk_2ubxwwtgyqd0h2mvy46u3prfq; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.userkeyjsonvalue
    ADD CONSTRAINT uk_2ubxwwtgyqd0h2mvy46u3prfq UNIQUE (code);


--
-- Name: uk_2utuk3clxif3qi4icy859kdrb; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.reservedvalue
    ADD CONSTRAINT uk_2utuk3clxif3qi4icy859kdrb UNIQUE (ownerobject, owneruid, key, value);


--
-- Name: uk_30lywefwg093pjkat9w8gm84k; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.categoryoptiontranslations
    ADD CONSTRAINT uk_30lywefwg093pjkat9w8gm84k UNIQUE (objecttranslationid);


--
-- Name: uk_35yuroxg610mvtf39u4atl2wv; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.legendsetattributevalues
    ADD CONSTRAINT uk_35yuroxg610mvtf39u4atl2wv UNIQUE (attributevalueid);


--
-- Name: uk_37l2m3o1xfuagpki90gfh5kqb; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.map
    ADD CONSTRAINT uk_37l2m3o1xfuagpki90gfh5kqb UNIQUE (code);


--
-- Name: uk_3a4ee92kxafw85hsopq4qle47; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.categorycombo
    ADD CONSTRAINT uk_3a4ee92kxafw85hsopq4qle47 UNIQUE (code);


--
-- Name: uk_3a80nwvpu461lotvp07fcnrnc; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.datasetsectiontranslations
    ADD CONSTRAINT uk_3a80nwvpu461lotvp07fcnrnc UNIQUE (objecttranslationid);


--
-- Name: uk_3c2n8db21er764e4skh3qg57w; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.programruleaction
    ADD CONSTRAINT uk_3c2n8db21er764e4skh3qg57w UNIQUE (uid);


--
-- Name: uk_3cl2o6ha8naw5w6my3q4el6gk; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.validationrulegroup
    ADD CONSTRAINT uk_3cl2o6ha8naw5w6my3q4el6gk UNIQUE (name);


--
-- Name: uk_3hp6444cqjtn6743ucvhb4e3f; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.categoryoptioncombotranslations
    ADD CONSTRAINT uk_3hp6444cqjtn6743ucvhb4e3f UNIQUE (objecttranslationid);


--
-- Name: uk_3i6ynfwrt35gl0moamcl5t958; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.orgunitgroupsettranslations
    ADD CONSTRAINT uk_3i6ynfwrt35gl0moamcl5t958 UNIQUE (objecttranslationid);


--
-- Name: uk_3idqsvkpmxpehxqv615s952vd; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dashboarditem
    ADD CONSTRAINT uk_3idqsvkpmxpehxqv615s952vd UNIQUE (uid);


--
-- Name: uk_3phvecdmy2msmcpitqifpcy3c; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.orgunitgroup
    ADD CONSTRAINT uk_3phvecdmy2msmcpitqifpcy3c UNIQUE (code);


--
-- Name: uk_3r6dr8m9qwa89afngtr43x9jh; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dataelement
    ADD CONSTRAINT uk_3r6dr8m9qwa89afngtr43x9jh UNIQUE (uid);


--
-- Name: uk_3svwn20y9qda34bmatesg5c0j; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dataapprovalworkflow
    ADD CONSTRAINT uk_3svwn20y9qda34bmatesg5c0j UNIQUE (code);


--
-- Name: uk_3tn4w8rs68lpvrdaksbsalta7; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.categoryoptiongroupsetusergroupaccesses
    ADD CONSTRAINT uk_3tn4w8rs68lpvrdaksbsalta7 UNIQUE (usergroupaccessid);


--
-- Name: uk_3uh2stfqjquour25m5gjfdroi; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.orgunitgroupsetusergroupaccesses
    ADD CONSTRAINT uk_3uh2stfqjquour25m5gjfdroi UNIQUE (usergroupaccessid);


--
-- Name: uk_3va2lo93o5x8of9r244sb0ini; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.trackedentityattributeusergroupaccesses
    ADD CONSTRAINT uk_3va2lo93o5x8of9r244sb0ini UNIQUE (usergroupaccessid);


--
-- Name: uk_3vgkycs0lsgpxaqtytfijr1ji; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.programmessage
    ADD CONSTRAINT uk_3vgkycs0lsgpxaqtytfijr1ji UNIQUE (code);


--
-- Name: uk_3wailhtvswifioim376gn0u9c; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.reporttableuseraccesses
    ADD CONSTRAINT uk_3wailhtvswifioim376gn0u9c UNIQUE (useraccessid);


--
-- Name: uk_4372w9f7asbu1ybpduj2xqjmt; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.programindicator
    ADD CONSTRAINT uk_4372w9f7asbu1ybpduj2xqjmt UNIQUE (shortname);


--
-- Name: uk_46w0ywaj13n29eoi9767grqyc; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.interpretationuseraccesses
    ADD CONSTRAINT uk_46w0ywaj13n29eoi9767grqyc UNIQUE (useraccessid);


--
-- Name: uk_478bg522jkn8460hkeshlw1j1; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.report
    ADD CONSTRAINT uk_478bg522jkn8460hkeshlw1j1 UNIQUE (relativeperiodsid);


--
-- Name: uk_48xfoqrfjnkuay28xeixjm0t0; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.program_attribute_group
    ADD CONSTRAINT uk_48xfoqrfjnkuay28xeixjm0t0 UNIQUE (code);


--
-- Name: uk_4b97sdsm2p477cc05eody10lm; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.predictor
    ADD CONSTRAINT uk_4b97sdsm2p477cc05eody10lm UNIQUE (name);


--
-- Name: uk_4bcigh7ivtiraxnhqrg72tldo; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tablehook
    ADD CONSTRAINT uk_4bcigh7ivtiraxnhqrg72tldo UNIQUE (code);


--
-- Name: uk_4dlqoc6s8ilws9yhacy5qkddb; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.fileresource
    ADD CONSTRAINT uk_4dlqoc6s8ilws9yhacy5qkddb UNIQUE (code);


--
-- Name: uk_4edmqjfna3lc6gyjkh1h2a5fo; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.validationruleusergroupaccesses
    ADD CONSTRAINT uk_4edmqjfna3lc6gyjkh1h2a5fo UNIQUE (usergroupaccessid);


--
-- Name: uk_4gmflcy6at9qdl8q6ae23e7ul; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.maplegendsettranslations
    ADD CONSTRAINT uk_4gmflcy6at9qdl8q6ae23e7ul UNIQUE (objecttranslationid);


--
-- Name: uk_4iylxmooa7ca562qvw4tjq5ys; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.trackedentitytype
    ADD CONSTRAINT uk_4iylxmooa7ca562qvw4tjq5ys UNIQUE (uid);


--
-- Name: uk_4k3a3mf7dgr4b2btftg5jkmt7; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.userkeyjsonvalue
    ADD CONSTRAINT uk_4k3a3mf7dgr4b2btftg5jkmt7 UNIQUE (uid);


--
-- Name: uk_4n6nev8dlydiyu5k8xyjtsasl; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.program_attribute_group
    ADD CONSTRAINT uk_4n6nev8dlydiyu5k8xyjtsasl UNIQUE (name);


--
-- Name: uk_4p7hvngancp6mtolp00nhgqy1; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.programindicatorgroupattributevalues
    ADD CONSTRAINT uk_4p7hvngancp6mtolp00nhgqy1 UNIQUE (attributevalueid);


--
-- Name: uk_4pi5lfmisrt8un89dnb17xrdy; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dataelementcategoryoption
    ADD CONSTRAINT uk_4pi5lfmisrt8un89dnb17xrdy UNIQUE (uid);


--
-- Name: uk_4sfn84gjcjre8ni3ofvhmkkvk; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.optionsetattributevalues
    ADD CONSTRAINT uk_4sfn84gjcjre8ni3ofvhmkkvk UNIQUE (attributevalueid);


--
-- Name: uk_4t108a6tjlba547s5i5j4vuhe; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.indicatorgroupsetuseraccesses
    ADD CONSTRAINT uk_4t108a6tjlba547s5i5j4vuhe UNIQUE (useraccessid);


--
-- Name: uk_4wluhhaibua3a52cts7jnrt5b; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.indicatorgroupusergroupaccesses
    ADD CONSTRAINT uk_4wluhhaibua3a52cts7jnrt5b UNIQUE (usergroupaccessid);


--
-- Name: uk_50aqn6tun6lt4u3ablvdxgoi6; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sqlview
    ADD CONSTRAINT uk_50aqn6tun6lt4u3ablvdxgoi6 UNIQUE (code);


--
-- Name: uk_50eq5f6ulswj595bxtbuaxa2x; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.programstagetranslations
    ADD CONSTRAINT uk_50eq5f6ulswj595bxtbuaxa2x UNIQUE (objecttranslationid);


--
-- Name: uk_5159yqcajy9bc6urj5fqpg8q6; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.categoryoptiongroupsetuseraccesses
    ADD CONSTRAINT uk_5159yqcajy9bc6urj5fqpg8q6 UNIQUE (useraccessid);


--
-- Name: uk_52uh95pqjaa2q952258f3yixr; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.eventreporttranslations
    ADD CONSTRAINT uk_52uh95pqjaa2q952258f3yixr UNIQUE (objecttranslationid);


--
-- Name: uk_579c6m0lb755obiwg8ahswans; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dataelementcategoryuseraccesses
    ADD CONSTRAINT uk_579c6m0lb755obiwg8ahswans UNIQUE (useraccessid);


--
-- Name: uk_57rc0c2r4unihva4dwydyixy6; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dataapprovalleveltranslations
    ADD CONSTRAINT uk_57rc0c2r4unihva4dwydyixy6 UNIQUE (objecttranslationid);


--
-- Name: uk_581ayy658kxytmijcfd2rxnq0; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.externalmaplayer
    ADD CONSTRAINT uk_581ayy658kxytmijcfd2rxnq0 UNIQUE (name);


--
-- Name: uk_59abitsfd3u0jx4ntrrblven0; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.programindicator
    ADD CONSTRAINT uk_59abitsfd3u0jx4ntrrblven0 UNIQUE (uid);


--
-- Name: uk_5gnagy6dnux0xeucxi4phuyb2; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.userroleuseraccesses
    ADD CONSTRAINT uk_5gnagy6dnux0xeucxi4phuyb2 UNIQUE (useraccessid);


--
-- Name: uk_5iwcc2c18pxom1nom9sxvo22f; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.documentattributevalues
    ADD CONSTRAINT uk_5iwcc2c18pxom1nom9sxvo22f UNIQUE (attributevalueid);


--
-- Name: uk_5km0xiwk0dg7pnoru5yfvqsdo; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.orgunitlevel
    ADD CONSTRAINT uk_5km0xiwk0dg7pnoru5yfvqsdo UNIQUE (uid);


--
-- Name: uk_5l04wpj6gft1c4w2qesxygahl; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dataelementcategorytranslations
    ADD CONSTRAINT uk_5l04wpj6gft1c4w2qesxygahl UNIQUE (objecttranslationid);


--
-- Name: uk_5mg3p351cswnu4jy7avcoqoo5; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.mapuseraccesses
    ADD CONSTRAINT uk_5mg3p351cswnu4jy7avcoqoo5 UNIQUE (useraccessid);


--
-- Name: uk_5mq4bmpyevmr1ddkkopweted1; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dataapprovallevel
    ADD CONSTRAINT uk_5mq4bmpyevmr1ddkkopweted1 UNIQUE (name);


--
-- Name: uk_5tawpr2nfe6985n4j6f72ic3d; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.constantattributevalues
    ADD CONSTRAINT uk_5tawpr2nfe6985n4j6f72ic3d UNIQUE (attributevalueid);


--
-- Name: uk_5umlmoegw88nokw32ya6aa7y7; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.categoryoptioncomboattributevalues
    ADD CONSTRAINT uk_5umlmoegw88nokw32ya6aa7y7 UNIQUE (attributevalueid);


--
-- Name: uk_5w429v9hdlvivan4a69x3ntx5; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.eventchart
    ADD CONSTRAINT uk_5w429v9hdlvivan4a69x3ntx5 UNIQUE (relativeperiodsid);


--
-- Name: uk_60p9gh2un0pb7l9tctfd4o3b3; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.categoryoptioncombo
    ADD CONSTRAINT uk_60p9gh2un0pb7l9tctfd4o3b3 UNIQUE (code);


--
-- Name: uk_61yelmsucg67isxc2habccq57; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.usergroupattributevalues
    ADD CONSTRAINT uk_61yelmsucg67isxc2habccq57 UNIQUE (attributevalueid);


--
-- Name: uk_64w4wa4oc3hkxo86hjo63cd1x; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.externalmaplayer
    ADD CONSTRAINT uk_64w4wa4oc3hkxo86hjo63cd1x UNIQUE (uid);


--
-- Name: uk_661n81nahaudw4061s1l5m93k; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.orgunitleveltranslations
    ADD CONSTRAINT uk_661n81nahaudw4061s1l5m93k UNIQUE (objecttranslationid);


--
-- Name: uk_668dyd20363ufr44a805inegm; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tablehook
    ADD CONSTRAINT uk_668dyd20363ufr44a805inegm UNIQUE (name);


--
-- Name: uk_679r4uoqpust6h694bed8nrh9; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.eventchart
    ADD CONSTRAINT uk_679r4uoqpust6h694bed8nrh9 UNIQUE (uid);


--
-- Name: uk_6d4hr4t1x8yyflsr8qo0addv0; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.externalmaplayerusergroupaccesses
    ADD CONSTRAINT uk_6d4hr4t1x8yyflsr8qo0addv0 UNIQUE (usergroupaccessid);


--
-- Name: uk_6dxu0gan4u81y3b6g53cyg79v; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dashboardtranslations
    ADD CONSTRAINT uk_6dxu0gan4u81y3b6g53cyg79v UNIQUE (objecttranslationid);


--
-- Name: uk_6dyim42vl218i9e9waqrvw36k; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.eventchart
    ADD CONSTRAINT uk_6dyim42vl218i9e9waqrvw36k UNIQUE (code);


--
-- Name: uk_6gnwbmpissx2s1manr6bwxriu; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.indicatorusergroupaccesses
    ADD CONSTRAINT uk_6gnwbmpissx2s1manr6bwxriu UNIQUE (usergroupaccessid);


--
-- Name: uk_6hh8abnhp5bf53rgf2r2maxgb; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dataapprovalworkflowusergroupaccesses
    ADD CONSTRAINT uk_6hh8abnhp5bf53rgf2r2maxgb UNIQUE (usergroupaccessid);


--
-- Name: uk_6ihtl75oib36uu3ga3k4ngg8p; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.optiongroupsetusergroupaccesses
    ADD CONSTRAINT uk_6ihtl75oib36uu3ga3k4ngg8p UNIQUE (usergroupaccessid);


--
-- Name: uk_6itpx2frqt3msln8p32rk7qta; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.categoryoptiongroupset
    ADD CONSTRAINT uk_6itpx2frqt3msln8p32rk7qta UNIQUE (uid);


--
-- Name: uk_6jn8xf8khu6rigqcqfqfyqds7; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.colorsettranslations
    ADD CONSTRAINT uk_6jn8xf8khu6rigqcqfqfyqds7 UNIQUE (objecttranslationid);


--
-- Name: uk_6lycqfymeu4sdi4t3cdh6ul1k; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.trackedentitytypeattribute
    ADD CONSTRAINT uk_6lycqfymeu4sdi4t3cdh6ul1k UNIQUE (code);


--
-- Name: uk_6ni8qsiimdcy626hwls002flo; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.optiongroup
    ADD CONSTRAINT uk_6ni8qsiimdcy626hwls002flo UNIQUE (name);


--
-- Name: uk_6nm3ynkrtuj01bpo1uwcryq06; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.mapview
    ADD CONSTRAINT uk_6nm3ynkrtuj01bpo1uwcryq06 UNIQUE (code);


--
-- Name: uk_6sq5y5hpb4kqf2fmas69rql3g; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.indicatorattributevalues
    ADD CONSTRAINT uk_6sq5y5hpb4kqf2fmas69rql3g UNIQUE (attributevalueid);


--
-- Name: uk_6x37lph70r5mh15a71pf1tj17; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dataelementgroup
    ADD CONSTRAINT uk_6x37lph70r5mh15a71pf1tj17 UNIQUE (shortname);


--
-- Name: uk_6yl4auyn51bnkw7d6spla6f8r; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dataelementtranslations
    ADD CONSTRAINT uk_6yl4auyn51bnkw7d6spla6f8r UNIQUE (objecttranslationid);


--
-- Name: uk_71vrxovabe8x9tom8xwefi3e7; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT uk_71vrxovabe8x9tom8xwefi3e7 UNIQUE (code);


--
-- Name: uk_75d35u3n0i5wea6bevn7v6t3l; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dashboardusergroupaccesses
    ADD CONSTRAINT uk_75d35u3n0i5wea6bevn7v6t3l UNIQUE (usergroupaccessid);


--
-- Name: uk_78x5lua91w1j6upu02wh8pfx9; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tablehook
    ADD CONSTRAINT uk_78x5lua91w1j6upu02wh8pfx9 UNIQUE (uid);


--
-- Name: uk_7carnwjb5dtsk6i5dn43wy9ck; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.programindicatorgroup
    ADD CONSTRAINT uk_7carnwjb5dtsk6i5dn43wy9ck UNIQUE (name);


--
-- Name: uk_7if26yibpw5hn2gjsrn2xst0m; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.reporttable
    ADD CONSTRAINT uk_7if26yibpw5hn2gjsrn2xst0m UNIQUE (uid);


--
-- Name: uk_7ltkihrowq1wgkwml7wbdt2c2; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.validationcriteriatranslations
    ADD CONSTRAINT uk_7ltkihrowq1wgkwml7wbdt2c2 UNIQUE (objecttranslationid);


--
-- Name: uk_7odx4uo6s5bg55kt1fxky4a8v; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.programrule
    ADD CONSTRAINT uk_7odx4uo6s5bg55kt1fxky4a8v UNIQUE (code);


--
-- Name: uk_7p4qi3acjaxl4e1n5sg457ukr; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.optionvaluetranslations
    ADD CONSTRAINT uk_7p4qi3acjaxl4e1n5sg457ukr UNIQUE (objecttranslationid);


--
-- Name: uk_7q3ox6ciav6meerfx8p810xq4; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.legendsetuseraccesses
    ADD CONSTRAINT uk_7q3ox6ciav6meerfx8p810xq4 UNIQUE (useraccessid);


--
-- Name: uk_7rnfvkitq6l0kr5ju2slxopfi; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.relationshiptype
    ADD CONSTRAINT uk_7rnfvkitq6l0kr5ju2slxopfi UNIQUE (uid);


--
-- Name: uk_7s9ykqwrxm1yj8gck13f3vusg; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.reportuseraccesses
    ADD CONSTRAINT uk_7s9ykqwrxm1yj8gck13f3vusg UNIQUE (useraccessid);


--
-- Name: uk_7udjng39j4ddafjn57r58v7oq; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.programindicator
    ADD CONSTRAINT uk_7udjng39j4ddafjn57r58v7oq UNIQUE (name);


--
-- Name: uk_81gfx3yt7ngwmkk0t8qgcovhi; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.optionset
    ADD CONSTRAINT uk_81gfx3yt7ngwmkk0t8qgcovhi UNIQUE (uid);


--
-- Name: uk_83m22cdu74a60w77dt7d5xc65; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.indicatorgrouptranslations
    ADD CONSTRAINT uk_83m22cdu74a60w77dt7d5xc65 UNIQUE (objecttranslationid);


--
-- Name: uk_842ips1xb81udqc3dw5uax7u5; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.maplegendset
    ADD CONSTRAINT uk_842ips1xb81udqc3dw5uax7u5 UNIQUE (name);


--
-- Name: uk_84a9xamm9l60e6179ehh35pqj; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.colorset_colors
    ADD CONSTRAINT uk_84a9xamm9l60e6179ehh35pqj UNIQUE (colorid);


--
-- Name: uk_84abcabq3so8ktgt726o5du9d; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.programsection
    ADD CONSTRAINT uk_84abcabq3so8ktgt726o5du9d UNIQUE (uid);


--
-- Name: uk_87wso1e1xtxsl34nxey6nr922; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.validationnotificationtemplate
    ADD CONSTRAINT uk_87wso1e1xtxsl34nxey6nr922 UNIQUE (code);


--
-- Name: uk_8alvmsgu0onl4i0a0sqb6mqx; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.validationrulegroup
    ADD CONSTRAINT uk_8alvmsgu0onl4i0a0sqb6mqx UNIQUE (uid);


--
-- Name: uk_8d4xrx2gygb4aivpcwrp613hj; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.relationshiptype
    ADD CONSTRAINT uk_8d4xrx2gygb4aivpcwrp613hj UNIQUE (name);


--
-- Name: uk_8dcmrupnoi7hiiom466aoa2y; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.indicatortype
    ADD CONSTRAINT uk_8dcmrupnoi7hiiom466aoa2y UNIQUE (code);


--
-- Name: uk_8eyremdx683wcd9owh1t5jufs; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.mapview
    ADD CONSTRAINT uk_8eyremdx683wcd9owh1t5jufs UNIQUE (relativeperiodsid);


--
-- Name: uk_8tntx482dq1xv37o2nurja8el; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.programindicatoruseraccesses
    ADD CONSTRAINT uk_8tntx482dq1xv37o2nurja8el UNIQUE (useraccessid);


--
-- Name: uk_8v1lxgqdnnocvm9ah6clxmjf; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.externalfileresource
    ADD CONSTRAINT uk_8v1lxgqdnnocvm9ah6clxmjf UNIQUE (code);


--
-- Name: uk_90celfj5neh3vkjxvyrct48a8; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.programindicatorattributevalues
    ADD CONSTRAINT uk_90celfj5neh3vkjxvyrct48a8 UNIQUE (attributevalueid);


--
-- Name: uk_94srnunkibylfaxt4knxfn58e; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dataelement
    ADD CONSTRAINT uk_94srnunkibylfaxt4knxfn58e UNIQUE (code);


--
-- Name: uk_9a0eh0b7g9invjjs34nuvntkd; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.constantusergroupaccesses
    ADD CONSTRAINT uk_9a0eh0b7g9invjjs34nuvntkd UNIQUE (usergroupaccessid);


--
-- Name: uk_9an2md6lmqpube8hr0u3hie8c; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.eventchartuseraccesses
    ADD CONSTRAINT uk_9an2md6lmqpube8hr0u3hie8c UNIQUE (useraccessid);


--
-- Name: uk_9bk8wrffte75y236jgv1pmp81; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.optionsetusergroupaccesses
    ADD CONSTRAINT uk_9bk8wrffte75y236jgv1pmp81 UNIQUE (usergroupaccessid);


--
-- Name: uk_9csrw908a1fvfwbhjwm0jfl4e; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.maplegend
    ADD CONSTRAINT uk_9csrw908a1fvfwbhjwm0jfl4e UNIQUE (uid);


--
-- Name: uk_9edhf9afuedxl6qmdi1y9pin9; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.categoryoptiongroupsettranslations
    ADD CONSTRAINT uk_9edhf9afuedxl6qmdi1y9pin9 UNIQUE (objecttranslationid);


--
-- Name: uk_9hvlbsw019hscf35xb5behfx9; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.section
    ADD CONSTRAINT uk_9hvlbsw019hscf35xb5behfx9 UNIQUE (code);


--
-- Name: uk_9j6xjgegveyc0uqs506yy2wrp; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.i18nlocale
    ADD CONSTRAINT uk_9j6xjgegveyc0uqs506yy2wrp UNIQUE (locale);


--
-- Name: uk_9k7bv5o2ut4t0unxcwfyf1ay0; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.metadataversion
    ADD CONSTRAINT uk_9k7bv5o2ut4t0unxcwfyf1ay0 UNIQUE (code);


--
-- Name: uk_9llxa96leqj70jlbjtq03frt; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dataelementgroupsettranslations
    ADD CONSTRAINT uk_9llxa96leqj70jlbjtq03frt UNIQUE (objecttranslationid);


--
-- Name: uk_9mqbhximifdn1n8ru52lan3fw; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.attribute
    ADD CONSTRAINT uk_9mqbhximifdn1n8ru52lan3fw UNIQUE (uid);


--
-- Name: uk_9nbu5m63pd0n13liu13i3nvb5; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.chart
    ADD CONSTRAINT uk_9nbu5m63pd0n13liu13i3nvb5 UNIQUE (relativeperiodsid);


--
-- Name: uk_9up7rgxw54tb7oqm27geuwu5l; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dataelementuseraccesses
    ADD CONSTRAINT uk_9up7rgxw54tb7oqm27geuwu5l UNIQUE (useraccessid);


--
-- Name: uk_9ut6k8m3216v5kjcryy7d2y9w; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.validationrule
    ADD CONSTRAINT uk_9ut6k8m3216v5kjcryy7d2y9w UNIQUE (name);


--
-- Name: uk_9ydk6ypaj0xdjoyo1d5asap3m; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.programstageinstance
    ADD CONSTRAINT uk_9ydk6ypaj0xdjoyo1d5asap3m UNIQUE (code);


--
-- Name: uk_a50otc0l2chm0heii6scpit4k; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.section
    ADD CONSTRAINT uk_a50otc0l2chm0heii6scpit4k UNIQUE (uid);


--
-- Name: uk_a888yk2ttuq4bc23fegmew9l6; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.programuseraccesses
    ADD CONSTRAINT uk_a888yk2ttuq4bc23fegmew9l6 UNIQUE (useraccessid);


--
-- Name: uk_actuoxkkqulslxjpj5hagib9r; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.indicatorgroupset
    ADD CONSTRAINT uk_actuoxkkqulslxjpj5hagib9r UNIQUE (code);


--
-- Name: uk_acvg948kspicwqw3gmg4ehu8i; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.trackedentityinstancefilter
    ADD CONSTRAINT uk_acvg948kspicwqw3gmg4ehu8i UNIQUE (code);


--
-- Name: uk_aee54nmg1ci2cpitnpiwa845p; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.optiongroupset
    ADD CONSTRAINT uk_aee54nmg1ci2cpitnpiwa845p UNIQUE (name);


--
-- Name: uk_akmuehu0mwreltpnwm1u3fhx9; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.optiongroupattributevalues
    ADD CONSTRAINT uk_akmuehu0mwreltpnwm1u3fhx9 UNIQUE (attributevalueid);


--
-- Name: uk_aqbaj76r9qxmnylr6p8kj9g37; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dataelementgroup
    ADD CONSTRAINT uk_aqbaj76r9qxmnylr6p8kj9g37 UNIQUE (name);


--
-- Name: uk_asp8ntgg2muwvqbs60qnm1vq7; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.reportusergroupaccesses
    ADD CONSTRAINT uk_asp8ntgg2muwvqbs60qnm1vq7 UNIQUE (usergroupaccessid);


--
-- Name: uk_aukhdafc8vny241q4cbrs2wq6; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.optionsetuseraccesses
    ADD CONSTRAINT uk_aukhdafc8vny241q4cbrs2wq6 UNIQUE (useraccessid);


--
-- Name: uk_aygjfui3fpgrsxbj6qj782h6f; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.constant
    ADD CONSTRAINT uk_aygjfui3fpgrsxbj6qj782h6f UNIQUE (shortname);


--
-- Name: uk_ayk5ey2r1fh1akknxtpcpyp9r; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dataset
    ADD CONSTRAINT uk_ayk5ey2r1fh1akknxtpcpyp9r UNIQUE (uid);


--
-- Name: uk_b0ii4jdfy88pffbapohsr2lor; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dataelementcategory
    ADD CONSTRAINT uk_b0ii4jdfy88pffbapohsr2lor UNIQUE (name);


--
-- Name: uk_b39cpkfasrbt96274tbaedtmp; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.reporttable
    ADD CONSTRAINT uk_b39cpkfasrbt96274tbaedtmp UNIQUE (relativeperiodsid);


--
-- Name: uk_b3oan3noe4cj9dvyi0amofndv; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.programstage
    ADD CONSTRAINT uk_b3oan3noe4cj9dvyi0amofndv UNIQUE (uid);


--
-- Name: uk_b6xla21a6wx2wiqs3e6693kip; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.usergrouptranslations
    ADD CONSTRAINT uk_b6xla21a6wx2wiqs3e6693kip UNIQUE (objecttranslationid);


--
-- Name: uk_badofxhbq3oi2d4u7fj8w1kt8; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT uk_badofxhbq3oi2d4u7fj8w1kt8 UNIQUE (openid);


--
-- Name: uk_bjs0n874pj6eoag98jmeidy9a; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.categoryoptiongroupset
    ADD CONSTRAINT uk_bjs0n874pj6eoag98jmeidy9a UNIQUE (code);


--
-- Name: uk_bth82tx85qdsby613om1tsnr9; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.programindicatorgroupusergroupaccesses
    ADD CONSTRAINT uk_bth82tx85qdsby613om1tsnr9 UNIQUE (usergroupaccessid);


--
-- Name: uk_btl6l2mbri9q1u35dwai97tt0; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.externalmaplayeruseraccesses
    ADD CONSTRAINT uk_btl6l2mbri9q1u35dwai97tt0 UNIQUE (useraccessid);


--
-- Name: uk_bv71u83esume24hp4gsaj5p4f; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.maplegendset
    ADD CONSTRAINT uk_bv71u83esume24hp4gsaj5p4f UNIQUE (code);


--
-- Name: uk_bwcqkilt9khfpt811w9htm1b4; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dataelementcategoryoptionuseraccesses
    ADD CONSTRAINT uk_bwcqkilt9khfpt811w9htm1b4 UNIQUE (useraccessid);


--
-- Name: uk_by4pqq1ans00ffmrgqqh9ehog; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dataapprovalworkflow
    ADD CONSTRAINT uk_by4pqq1ans00ffmrgqqh9ehog UNIQUE (uid);


--
-- Name: uk_c7e1q9b728qh7iki2cvdbpfrb; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.organisationunitattributevalues
    ADD CONSTRAINT uk_c7e1q9b728qh7iki2cvdbpfrb UNIQUE (attributevalueid);


--
-- Name: uk_c8bnosb06cchme5sig7b54uot; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dashboarditem
    ADD CONSTRAINT uk_c8bnosb06cchme5sig7b54uot UNIQUE (code);


--
-- Name: uk_c8f7tvamlax65vajn6px3fync; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.programmessagetranslations
    ADD CONSTRAINT uk_c8f7tvamlax65vajn6px3fync UNIQUE (objecttranslationid);


--
-- Name: uk_c8uxqnygua12lrulfoquv3vd0; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.trackedentityattributeuseraccesses
    ADD CONSTRAINT uk_c8uxqnygua12lrulfoquv3vd0 UNIQUE (useraccessid);


--
-- Name: uk_cbnc5ktj6whhh690w32k8cyh8; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.color
    ADD CONSTRAINT uk_cbnc5ktj6whhh690w32k8cyh8 UNIQUE (code);


--
-- Name: uk_ccwoighljmk4fy165ipnwl5n4; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.externalfileresource
    ADD CONSTRAINT uk_ccwoighljmk4fy165ipnwl5n4 UNIQUE (uid);


--
-- Name: uk_cehuadg72kbcl4c7uofnyvpxp; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.trackedentitytranslations
    ADD CONSTRAINT uk_cehuadg72kbcl4c7uofnyvpxp UNIQUE (objecttranslationid);


--
-- Name: uk_cnegv6wpnnryw1xxn6mj8t6vn; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.constantuseraccesses
    ADD CONSTRAINT uk_cnegv6wpnnryw1xxn6mj8t6vn UNIQUE (useraccessid);


--
-- Name: uk_cnl1kh7cridrd0qiq14vjxnn0; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.indicatoruseraccesses
    ADD CONSTRAINT uk_cnl1kh7cridrd0qiq14vjxnn0 UNIQUE (useraccessid);


--
-- Name: uk_cqf1g88wg90e60s9cmxgi48w4; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.relationshiptypetranslations
    ADD CONSTRAINT uk_cqf1g88wg90e60s9cmxgi48w4 UNIQUE (objecttranslationid);


--
-- Name: uk_cqq1qrt93p7ek1ux7j60y15nx; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.programindicatorgroupuseraccesses
    ADD CONSTRAINT uk_cqq1qrt93p7ek1ux7j60y15nx UNIQUE (useraccessid);


--
-- Name: uk_csj1xy12uqpx5cuojxj4gg0ec; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.programtrackedentityattributegrouptranslations
    ADD CONSTRAINT uk_csj1xy12uqpx5cuojxj4gg0ec UNIQUE (objecttranslationid);


--
-- Name: uk_cswvqawieb2sfq5qsy5wpqp1k; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.datastatistics
    ADD CONSTRAINT uk_cswvqawieb2sfq5qsy5wpqp1k UNIQUE (code);


--
-- Name: uk_cto4jvd9q49voite13v0egy3i; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.programrulevariable
    ADD CONSTRAINT uk_cto4jvd9q49voite13v0egy3i UNIQUE (code);


--
-- Name: uk_cx8oyq6i72uyvbx6qtjol9t33; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sectionattributevalues
    ADD CONSTRAINT uk_cx8oyq6i72uyvbx6qtjol9t33 UNIQUE (attributevalueid);


--
-- Name: uk_d3lsa2h8me94ksyp53l6rpe3g; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.programinstance
    ADD CONSTRAINT uk_d3lsa2h8me94ksyp53l6rpe3g UNIQUE (uid);


--
-- Name: uk_d3pc3rtqnlkttpxoonieuawoe; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.maplegendtranslations
    ADD CONSTRAINT uk_d3pc3rtqnlkttpxoonieuawoe UNIQUE (objecttranslationid);


--
-- Name: uk_d3qpxp187x8t4c1rsn64crgqu; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.metadataversion
    ADD CONSTRAINT uk_d3qpxp187x8t4c1rsn64crgqu UNIQUE (hashcode);


--
-- Name: uk_d4gp8a84gn643g0r28hdnn4so; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.externalfileresource
    ADD CONSTRAINT uk_d4gp8a84gn643g0r28hdnn4so UNIQUE (fileresourceid);


--
-- Name: uk_d4l5rkqnmc6qdfa6hh11g3h74; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.validationcriteria
    ADD CONSTRAINT uk_d4l5rkqnmc6qdfa6hh11g3h74 UNIQUE (name);


--
-- Name: uk_dfbmp0sfgkcpxtwrfw2rejumg; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dataelementgroupusergroupaccesses
    ADD CONSTRAINT uk_dfbmp0sfgkcpxtwrfw2rejumg UNIQUE (usergroupaccessid);


--
-- Name: uk_dhl0qt8y7hht7krbiym1e9x3n; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dataentryform
    ADD CONSTRAINT uk_dhl0qt8y7hht7krbiym1e9x3n UNIQUE (code);


--
-- Name: uk_dkeswollqsyfxax1eo1yu8yn3; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.orgunitgroupuseraccesses
    ADD CONSTRAINT uk_dkeswollqsyfxax1eo1yu8yn3 UNIQUE (useraccessid);


--
-- Name: uk_dkimb3gxbm78pgq9b9k2alntp; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.datasettranslations
    ADD CONSTRAINT uk_dkimb3gxbm78pgq9b9k2alntp UNIQUE (objecttranslationid);


--
-- Name: uk_dlhi39gmt2e0dun73f04w7w7u; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.categorycombo
    ADD CONSTRAINT uk_dlhi39gmt2e0dun73f04w7w7u UNIQUE (uid);


--
-- Name: uk_do17h5nk71uvc3xjry6kgevj9; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.programindicator
    ADD CONSTRAINT uk_do17h5nk71uvc3xjry6kgevj9 UNIQUE (code);


--
-- Name: uk_do99wgsyk5wflbhb937u5av8m; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.systemsetting
    ADD CONSTRAINT uk_do99wgsyk5wflbhb937u5av8m UNIQUE (name);


--
-- Name: uk_dq1cneyi4cgarkqaspifgmjqn; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dataelementusergroupaccesses
    ADD CONSTRAINT uk_dq1cneyi4cgarkqaspifgmjqn UNIQUE (usergroupaccessid);


--
-- Name: uk_dt8m81o2pw5p9ttid369e92bg; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.optiongroup
    ADD CONSTRAINT uk_dt8m81o2pw5p9ttid369e92bg UNIQUE (code);


--
-- Name: uk_du8kbb8cr3d31en3uhhdkp2qn; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.reporttranslations
    ADD CONSTRAINT uk_du8kbb8cr3d31en3uhhdkp2qn UNIQUE (objecttranslationid);


--
-- Name: uk_dvxv0mw5bonk4pb38o8rctku3; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.validationcriteria
    ADD CONSTRAINT uk_dvxv0mw5bonk4pb38o8rctku3 UNIQUE (uid);


--
-- Name: uk_e5mhmtj1h7xdfiio2panhapgg; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.programrulevariable
    ADD CONSTRAINT uk_e5mhmtj1h7xdfiio2panhapgg UNIQUE (uid);


--
-- Name: uk_e5my51xi9bhly2d21ra5w1ir6; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.validationruleuseraccesses
    ADD CONSTRAINT uk_e5my51xi9bhly2d21ra5w1ir6 UNIQUE (useraccessid);


--
-- Name: uk_e6s6o9jau6tx04m62t7ey4i81; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.programstage
    ADD CONSTRAINT uk_e6s6o9jau6tx04m62t7ey4i81 UNIQUE (code);


--
-- Name: uk_eb7jbyiwhse2kd64y3ufee977; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.trackedentityattributeattributevalues
    ADD CONSTRAINT uk_eb7jbyiwhse2kd64y3ufee977 UNIQUE (attributevalueid);


--
-- Name: uk_ec7ehyocpresxxhm7yjstdnwt; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.maplegendset
    ADD CONSTRAINT uk_ec7ehyocpresxxhm7yjstdnwt UNIQUE (uid);


--
-- Name: uk_edy7cktu2fqg01r3n0fjyk1kk; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.constant
    ADD CONSTRAINT uk_edy7cktu2fqg01r3n0fjyk1kk UNIQUE (code);


--
-- Name: uk_efqukogbk7i0poucwoy2qie74; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT uk_efqukogbk7i0poucwoy2qie74 UNIQUE (uid);


--
-- Name: uk_eh2epuhchf9mci86ihl06i31g; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.fileresource
    ADD CONSTRAINT uk_eh2epuhchf9mci86ihl06i31g UNIQUE (uid);


--
-- Name: uk_eh4c3whbwi94nhh772q6l5t7m; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.trackedentityattribute
    ADD CONSTRAINT uk_eh4c3whbwi94nhh772q6l5t7m UNIQUE (code);


--
-- Name: uk_ehl4v33tq7hlkmc28vbno1b4n; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.organisationunit
    ADD CONSTRAINT uk_ehl4v33tq7hlkmc28vbno1b4n UNIQUE (code);


--
-- Name: uk_ej46fagundmv2qkhh2hdpn6nt; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.organisationunittranslations
    ADD CONSTRAINT uk_ej46fagundmv2qkhh2hdpn6nt UNIQUE (objecttranslationid);


--
-- Name: uk_ekb018cvmpvll5dgtn97leerj; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.usergroup
    ADD CONSTRAINT uk_ekb018cvmpvll5dgtn97leerj UNIQUE (uid);


--
-- Name: uk_elt3kiqdmmm5fwqfxsxk9lvh0; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document
    ADD CONSTRAINT uk_elt3kiqdmmm5fwqfxsxk9lvh0 UNIQUE (code);


--
-- Name: uk_em6b7qxcas7dn6y506i3nd2x6; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.keyjsonvalue
    ADD CONSTRAINT uk_em6b7qxcas7dn6y506i3nd2x6 UNIQUE (uid);


--
-- Name: uk_emoyyyy114ofh6cwo6do8xsi0; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.version
    ADD CONSTRAINT uk_emoyyyy114ofh6cwo6do8xsi0 UNIQUE (versionkey);


--
-- Name: uk_emyh4fed0f1kknqhimmrhnek8; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dashboard
    ADD CONSTRAINT uk_emyh4fed0f1kknqhimmrhnek8 UNIQUE (code);


--
-- Name: uk_en3k8g2rnmf5telm4y4ofoo5t; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.optiongrouptranslations
    ADD CONSTRAINT uk_en3k8g2rnmf5telm4y4ofoo5t UNIQUE (objecttranslationid);


--
-- Name: uk_enhquk04unrpri78inaske3jq; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.predictor
    ADD CONSTRAINT uk_enhquk04unrpri78inaske3jq UNIQUE (uid);


--
-- Name: uk_eol69wovoy6rdsf83affs376e; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dataapprovallevelusergroupaccesses
    ADD CONSTRAINT uk_eol69wovoy6rdsf83affs376e UNIQUE (usergroupaccessid);


--
-- Name: uk_eqd95mucf5pd856dqlwe6y36c; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.eventreport
    ADD CONSTRAINT uk_eqd95mucf5pd856dqlwe6y36c UNIQUE (code);


--
-- Name: uk_etm1elt7pbwyia8e0kfnrvqo3; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.smscommandspecialcharacters
    ADD CONSTRAINT uk_etm1elt7pbwyia8e0kfnrvqo3 UNIQUE (specialcharacterid);


--
-- Name: uk_evgeam7stb1pn3flp6dsdcu1n; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.mapviewtranslations
    ADD CONSTRAINT uk_evgeam7stb1pn3flp6dsdcu1n UNIQUE (objecttranslationid);


--
-- Name: uk_evp7d8obarxt3kewepigkwahc; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.trackedentityattribute
    ADD CONSTRAINT uk_evp7d8obarxt3kewepigkwahc UNIQUE (name);


--
-- Name: uk_eyke73kujhkth5elabmkpy4ca; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.chart
    ADD CONSTRAINT uk_eyke73kujhkth5elabmkpy4ca UNIQUE (code);


--
-- Name: uk_f7wfef3jx1yl73stqs7b45ewb; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.programindicatorgroup
    ADD CONSTRAINT uk_f7wfef3jx1yl73stqs7b45ewb UNIQUE (code);


--
-- Name: uk_f93o7l4afmkassm3t4f2op9ps; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.metadataversion
    ADD CONSTRAINT uk_f93o7l4afmkassm3t4f2op9ps UNIQUE (name);


--
-- Name: uk_fbferisvig2o4f5owb5lnygf3; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.programruleaction
    ADD CONSTRAINT uk_fbferisvig2o4f5owb5lnygf3 UNIQUE (code);


--
-- Name: uk_fead4ax5fg22afjqi0sqld54y; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.eventcharttranslations
    ADD CONSTRAINT uk_fead4ax5fg22afjqi0sqld54y UNIQUE (objecttranslationid);


--
-- Name: uk_ff1da38in40mg91rlgqhw02ff; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.userrole
    ADD CONSTRAINT uk_ff1da38in40mg91rlgqhw02ff UNIQUE (uid);


--
-- Name: uk_ficc46qh952uupa5o04svktv2; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dataelementcategoryoptionattributevalues
    ADD CONSTRAINT uk_ficc46qh952uupa5o04svktv2 UNIQUE (attributevalueid);


--
-- Name: uk_fokuy0yq9krttmqaf95ne7ql7; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dataelementgroupattributevalues
    ADD CONSTRAINT uk_fokuy0yq9krttmqaf95ne7ql7 UNIQUE (attributevalueid);


--
-- Name: uk_fps2ja521pudngaitlp0805du; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sqlview
    ADD CONSTRAINT uk_fps2ja521pudngaitlp0805du UNIQUE (uid);


--
-- Name: uk_fuentbuhbbr0ix49td9jqlfe5; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.orgunitgroupset
    ADD CONSTRAINT uk_fuentbuhbbr0ix49td9jqlfe5 UNIQUE (uid);


--
-- Name: uk_fuq6kda6folarp19oggaf02vb; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.program
    ADD CONSTRAINT uk_fuq6kda6folarp19oggaf02vb UNIQUE (code);


--
-- Name: uk_fvgc7isaflcan55g51ysm9df2; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.orgunitlevel
    ADD CONSTRAINT uk_fvgc7isaflcan55g51ysm9df2 UNIQUE (code);


--
-- Name: uk_fwso2d10icu8j6720w82tywmq; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.colorset
    ADD CONSTRAINT uk_fwso2d10icu8j6720w82tywmq UNIQUE (code);


--
-- Name: uk_fx3xx9xe0xpurjt6v5p7rv8da; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.oauth2client
    ADD CONSTRAINT uk_fx3xx9xe0xpurjt6v5p7rv8da UNIQUE (uid);


--
-- Name: uk_fyh1cv8231vhm61keusxjw2ao; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.indicatortranslations
    ADD CONSTRAINT uk_fyh1cv8231vhm61keusxjw2ao UNIQUE (objecttranslationid);


--
-- Name: uk_g1nrfjv5x04ap1ceohiwah380; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.organisationunit
    ADD CONSTRAINT uk_g1nrfjv5x04ap1ceohiwah380 UNIQUE (uid);


--
-- Name: uk_g54lkp9a8q5qp4wsfwxg4c7xc; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.chartuseraccesses
    ADD CONSTRAINT uk_g54lkp9a8q5qp4wsfwxg4c7xc UNIQUE (useraccessid);


--
-- Name: uk_g6tmqvpobbl4krf8vew12mtbx; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.categorycombotranslations
    ADD CONSTRAINT uk_g6tmqvpobbl4krf8vew12mtbx UNIQUE (objecttranslationid);


--
-- Name: uk_g7h35wi1pucccmk84x4swrpan; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.validationrulegrouptranslations
    ADD CONSTRAINT uk_g7h35wi1pucccmk84x4swrpan UNIQUE (objecttranslationid);


--
-- Name: uk_g7l1v9ghhdmxbyagk6s61ym27; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dataelementgroupsetusergroupaccesses
    ADD CONSTRAINT uk_g7l1v9ghhdmxbyagk6s61ym27 UNIQUE (usergroupaccessid);


--
-- Name: uk_gaecdwlqfpvdu516lhl8pu6mk; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sqlviewattributevalues
    ADD CONSTRAINT uk_gaecdwlqfpvdu516lhl8pu6mk UNIQUE (attributevalueid);


--
-- Name: uk_gdawhakuh5sgetn8agy2y8iqs; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dataelementcategoryoptionusergroupaccesses
    ADD CONSTRAINT uk_gdawhakuh5sgetn8agy2y8iqs UNIQUE (usergroupaccessid);


--
-- Name: uk_gdfuf3j66jxnvwwnksjxqysac; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.oauth2client
    ADD CONSTRAINT uk_gdfuf3j66jxnvwwnksjxqysac UNIQUE (code);


--
-- Name: uk_ge3y4pf6qlne9p7rfmhlvg941; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.categoryoptiongroup
    ADD CONSTRAINT uk_ge3y4pf6qlne9p7rfmhlvg941 UNIQUE (code);


--
-- Name: uk_gg9gc0pyaqjuxi8mr4y93i03w; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.trackedentityattribute
    ADD CONSTRAINT uk_gg9gc0pyaqjuxi8mr4y93i03w UNIQUE (shortname);


--
-- Name: uk_gi1od6nead01u7wxu6h10k76j; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dataelementcategoryusergroupaccesses
    ADD CONSTRAINT uk_gi1od6nead01u7wxu6h10k76j UNIQUE (usergroupaccessid);


--
-- Name: uk_gio4nn8l23jikmebud3jwql43; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.relationshiptype
    ADD CONSTRAINT uk_gio4nn8l23jikmebud3jwql43 UNIQUE (code);


--
-- Name: uk_gky85ptfkcumyuqhr5yvjxwsa; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.userinfo
    ADD CONSTRAINT uk_gky85ptfkcumyuqhr5yvjxwsa UNIQUE (code);


--
-- Name: uk_go48ntpyqbmgwa6k6h7756dwv; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.categoryoptiongroupuseraccesses
    ADD CONSTRAINT uk_go48ntpyqbmgwa6k6h7756dwv UNIQUE (useraccessid);


--
-- Name: uk_grp9b5jne53f806pc92sfd5s8; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.map
    ADD CONSTRAINT uk_grp9b5jne53f806pc92sfd5s8 UNIQUE (uid);


--
-- Name: uk_grvgb8y374npfr8m0h33madyb; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.indicatortypetranslations
    ADD CONSTRAINT uk_grvgb8y374npfr8m0h33madyb UNIQUE (objecttranslationid);


--
-- Name: uk_gv9f38ln4a6g59681smmlb0pe; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.trackedentityattributetranslations
    ADD CONSTRAINT uk_gv9f38ln4a6g59681smmlb0pe UNIQUE (objecttranslationid);


--
-- Name: uk_gy44hufdeduoma7eeh3j6abm7; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.programstageinstance
    ADD CONSTRAINT uk_gy44hufdeduoma7eeh3j6abm7 UNIQUE (uid);


--
-- Name: uk_h3qgkg0gvi3c0ohs07y00c96p; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.userroleusergroupaccesses
    ADD CONSTRAINT uk_h3qgkg0gvi3c0ohs07y00c96p UNIQUE (usergroupaccessid);


--
-- Name: uk_h4omjcs2ktifdrf2m36u886ae; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.program
    ADD CONSTRAINT uk_h4omjcs2ktifdrf2m36u886ae UNIQUE (uid);


--
-- Name: uk_h97pko7n41oky8pfptkflp8l6; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.categorycombo
    ADD CONSTRAINT uk_h97pko7n41oky8pfptkflp8l6 UNIQUE (name);


--
-- Name: uk_hbpqcltj8paday3y0yystbw6p; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dataelementattributevalues
    ADD CONSTRAINT uk_hbpqcltj8paday3y0yystbw6p UNIQUE (attributevalueid);


--
-- Name: uk_hebhkhm8gpwg9xsp8q4f7wlx1; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.userrole
    ADD CONSTRAINT uk_hebhkhm8gpwg9xsp8q4f7wlx1 UNIQUE (code);


--
-- Name: uk_hjocbvo9fla04bgj7ku32vwsn; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.userrole
    ADD CONSTRAINT uk_hjocbvo9fla04bgj7ku32vwsn UNIQUE (name);


--
-- Name: uk_hpwum0iq12fs4ej5d0tgy6wsn; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.attribute
    ADD CONSTRAINT uk_hpwum0iq12fs4ej5d0tgy6wsn UNIQUE (name);


--
-- Name: uk_hqekpuhjg3g4k4t7xdnu10jy4; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dataapprovallevel
    ADD CONSTRAINT uk_hqekpuhjg3g4k4t7xdnu10jy4 UNIQUE (orgunitlevel, categoryoptiongroupsetid);


--
-- Name: uk_hs57i9hma97ps6jpsrbb24lm9; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.orgunitgroupset
    ADD CONSTRAINT uk_hs57i9hma97ps6jpsrbb24lm9 UNIQUE (code);


--
-- Name: uk_huqnx8f8tmew3v4c6k8r3krpa; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.attributeusergroupaccesses
    ADD CONSTRAINT uk_huqnx8f8tmew3v4c6k8r3krpa UNIQUE (usergroupaccessid);


--
-- Name: uk_i1uhc0c8jgxkhlswl9fujsicf; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dataapprovallevel
    ADD CONSTRAINT uk_i1uhc0c8jgxkhlswl9fujsicf UNIQUE (uid);


--
-- Name: uk_id4stsb5slq35axmjeojnjnoa; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.maplegend
    ADD CONSTRAINT uk_id4stsb5slq35axmjeojnjnoa UNIQUE (code);


--
-- Name: uk_iedn1e511sbiosnic2nb8n6lk; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.programindicatorusergroupaccesses
    ADD CONSTRAINT uk_iedn1e511sbiosnic2nb8n6lk UNIQUE (usergroupaccessid);


--
-- Name: uk_iedy6hh42wl3gr3m87ntd6so8; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sqlview
    ADD CONSTRAINT uk_iedy6hh42wl3gr3m87ntd6so8 UNIQUE (name);


--
-- Name: uk_igo4gx1d74k7m93vxnn4n77jf; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.jobconfiguration
    ADD CONSTRAINT uk_igo4gx1d74k7m93vxnn4n77jf UNIQUE (code);


--
-- Name: uk_imfu1rtsu3sh3o0rdkxv0ur6e; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.validationrulegroupuseraccesses
    ADD CONSTRAINT uk_imfu1rtsu3sh3o0rdkxv0ur6e UNIQUE (useraccessid);


--
-- Name: uk_it367g8v93jni2b0i1k5gh42u; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.validationruletranslations
    ADD CONSTRAINT uk_it367g8v93jni2b0i1k5gh42u UNIQUE (objecttranslationid);


--
-- Name: uk_j5pi1qwi2m228qrsxql48o61s; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.messageconversation_usermessages
    ADD CONSTRAINT uk_j5pi1qwi2m228qrsxql48o61s UNIQUE (usermessageid);


--
-- Name: uk_j9oya1t1tvj8yn5h8fega4ltr; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.categoryoptiongroup
    ADD CONSTRAINT uk_j9oya1t1tvj8yn5h8fega4ltr UNIQUE (name);


--
-- Name: uk_jc27pe1xeptws5xprct7mgxrj; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dataelement
    ADD CONSTRAINT uk_jc27pe1xeptws5xprct7mgxrj UNIQUE (shortname);


--
-- Name: uk_jga8ebd6t2nkrfcapucx1wcbq; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.orgunitgroupattributevalues
    ADD CONSTRAINT uk_jga8ebd6t2nkrfcapucx1wcbq UNIQUE (attributevalueid);


--
-- Name: uk_jjt6ctp2xi4d7vtv4pwkkdhh0; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.datasetnotificationtemplate
    ADD CONSTRAINT uk_jjt6ctp2xi4d7vtv4pwkkdhh0 UNIQUE (uid);


--
-- Name: uk_jkg0r5akwcxtamstsq9kv4t4p; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT uk_jkg0r5akwcxtamstsq9kv4t4p UNIQUE (ldapid);


--
-- Name: uk_jo0xmsdymh9tk882hy994wbce; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.categorycombouseraccesses
    ADD CONSTRAINT uk_jo0xmsdymh9tk882hy994wbce UNIQUE (useraccessid);


--
-- Name: uk_jo65jc3wyrxfekiu3upk80mtr; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dataelementgroup
    ADD CONSTRAINT uk_jo65jc3wyrxfekiu3upk80mtr UNIQUE (code);


--
-- Name: uk_ju40npt2p0kglya4e5041b4qc; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.program_attribute_group
    ADD CONSTRAINT uk_ju40npt2p0kglya4e5041b4qc UNIQUE (uid);


--
-- Name: uk_ju4gh1mla6t217iucr66lx8xp; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sqlviewuseraccesses
    ADD CONSTRAINT uk_ju4gh1mla6t217iucr66lx8xp UNIQUE (useraccessid);


--
-- Name: uk_jxodv1lvot26euasttk021jio; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document
    ADD CONSTRAINT uk_jxodv1lvot26euasttk021jio UNIQUE (uid);


--
-- Name: uk_jxqj907hbrng860p6mypvl63k; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.fileresource
    ADD CONSTRAINT uk_jxqj907hbrng860p6mypvl63k UNIQUE (storagekey);


--
-- Name: uk_k48tayhxu52jiq782pikev9d9; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.interpretation_comments
    ADD CONSTRAINT uk_k48tayhxu52jiq782pikev9d9 UNIQUE (interpretationcommentid);


--
-- Name: uk_kbqnrdakcjfooofmti30d4p8x; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.trackedentityattribute
    ADD CONSTRAINT uk_kbqnrdakcjfooofmti30d4p8x UNIQUE (uid);


--
-- Name: uk_kc1wmcky1ooleovi36oqcqmqe; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.report
    ADD CONSTRAINT uk_kc1wmcky1ooleovi36oqcqmqe UNIQUE (code);


--
-- Name: uk_ke8p30sy68dl7fggednkimdb6; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.categoryoptiongroupset
    ADD CONSTRAINT uk_ke8p30sy68dl7fggednkimdb6 UNIQUE (name);


--
-- Name: uk_kjp8xjq10d0oknphxqmcmev7l; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.optiongroupsetuseraccesses
    ADD CONSTRAINT uk_kjp8xjq10d0oknphxqmcmev7l UNIQUE (useraccessid);


--
-- Name: uk_kk6o2c0eb5bex4sn1p5n7juu5; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.indicatorgroupsetusergroupaccesses
    ADD CONSTRAINT uk_kk6o2c0eb5bex4sn1p5n7juu5 UNIQUE (usergroupaccessid);


--
-- Name: uk_klp41jyfuo6kfe8akt58fk1am; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.validationrulegroupusergroupaccesses
    ADD CONSTRAINT uk_klp41jyfuo6kfe8akt58fk1am UNIQUE (usergroupaccessid);


--
-- Name: uk_kmpefoaw81v4bxpoey6y1y3xl; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.indicator
    ADD CONSTRAINT uk_kmpefoaw81v4bxpoey6y1y3xl UNIQUE (code);


--
-- Name: uk_kqbwxccoqctky1kdkimjya03s; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.indicatorgroup
    ADD CONSTRAINT uk_kqbwxccoqctky1kdkimjya03s UNIQUE (uid);


--
-- Name: uk_krfvmvcrf3agy0jlmbh7n2kvb; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.eventchartusergroupaccesses
    ADD CONSTRAINT uk_krfvmvcrf3agy0jlmbh7n2kvb UNIQUE (usergroupaccessid);


--
-- Name: uk_krm9w69donjqsejkmfw17jbcx; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.i18nlocale
    ADD CONSTRAINT uk_krm9w69donjqsejkmfw17jbcx UNIQUE (code);


--
-- Name: uk_ktwf16f728hce9ahtpmm7w5lx; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.metadataversion
    ADD CONSTRAINT uk_ktwf16f728hce9ahtpmm7w5lx UNIQUE (uid);


--
-- Name: uk_kw8ong945syafd2310ahwfu9l; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.categoryoptiongroupusergroupaccesses
    ADD CONSTRAINT uk_kw8ong945syafd2310ahwfu9l UNIQUE (usergroupaccessid);


--
-- Name: uk_l1cufoqirp2onveti3bpuyo92; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.orgunitgroupsetattributevalues
    ADD CONSTRAINT uk_l1cufoqirp2onveti3bpuyo92 UNIQUE (attributevalueid);


--
-- Name: uk_l78emlqkgkcw0fjtxr7qw3b2u; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.attributeuseraccesses
    ADD CONSTRAINT uk_l78emlqkgkcw0fjtxr7qw3b2u UNIQUE (useraccessid);


--
-- Name: uk_la7y8af5ivhtn0atpwu9x4a92; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dataapprovalworkflowtranslations
    ADD CONSTRAINT uk_la7y8af5ivhtn0atpwu9x4a92 UNIQUE (objecttranslationid);


--
-- Name: uk_ldbbgacwc69ab5tha0u7dhg82; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.programattributevalues
    ADD CONSTRAINT uk_ldbbgacwc69ab5tha0u7dhg82 UNIQUE (attributevalueid);


--
-- Name: uk_lgju00pi2jk7y6sl4dkhaykux; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.program_attributes
    ADD CONSTRAINT uk_lgju00pi2jk7y6sl4dkhaykux UNIQUE (uid);


--
-- Name: uk_lgs65dnblcvu4g58r0h4c6fnb; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.reporttabletranslations
    ADD CONSTRAINT uk_lgs65dnblcvu4g58r0h4c6fnb UNIQUE (objecttranslationid);


--
-- Name: uk_lner1ovmrqr5qrwn8gwfuhhhn; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.externalnotificationlogentry
    ADD CONSTRAINT uk_lner1ovmrqr5qrwn8gwfuhhhn UNIQUE (uid);


--
-- Name: uk_lnnx8vmalkhkmneryv1ytjq68; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.eventreport
    ADD CONSTRAINT uk_lnnx8vmalkhkmneryv1ytjq68 UNIQUE (uid);


--
-- Name: uk_lplte6sid32779w3o6fv26n7t; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.constanttranslations
    ADD CONSTRAINT uk_lplte6sid32779w3o6fv26n7t UNIQUE (objecttranslationid);


--
-- Name: uk_lrnagoy2wi83nwmataolh7t6d; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.categoryoptiongroup
    ADD CONSTRAINT uk_lrnagoy2wi83nwmataolh7t6d UNIQUE (shortname);


--
-- Name: uk_lswbn93sime7vmdqqe9lks7ge; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.orgunitgroup
    ADD CONSTRAINT uk_lswbn93sime7vmdqqe9lks7ge UNIQUE (uid);


--
-- Name: uk_ltwhby0s0iwayxrcdu6yefeqt; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.orgunitlevel
    ADD CONSTRAINT uk_ltwhby0s0iwayxrcdu6yefeqt UNIQUE (level);


--
-- Name: uk_lu295rc1y01c7p7t76y6ajaas; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dataelementgroupset
    ADD CONSTRAINT uk_lu295rc1y01c7p7t76y6ajaas UNIQUE (uid);


--
-- Name: uk_lvk31hlxg4sl301nxyt1iupd6; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.reporttable
    ADD CONSTRAINT uk_lvk31hlxg4sl301nxyt1iupd6 UNIQUE (code);


--
-- Name: uk_lwep604j10w1ey7vunqdmotx2; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.programinstancecomments
    ADD CONSTRAINT uk_lwep604j10w1ey7vunqdmotx2 UNIQUE (trackedentitycommentid);


--
-- Name: uk_lycal9jdw3cs0wwebxciswwgr; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.programstagesection
    ADD CONSTRAINT uk_lycal9jdw3cs0wwebxciswwgr UNIQUE (uid);


--
-- Name: uk_m5k30j5e93n1no82gye7jgf25; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.trackedentityinstancefilter
    ADD CONSTRAINT uk_m5k30j5e93n1no82gye7jgf25 UNIQUE (uid);


--
-- Name: uk_mbt1vxa5exs9cbqqs5px2mopx; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.validationnotificationtemplate
    ADD CONSTRAINT uk_mbt1vxa5exs9cbqqs5px2mopx UNIQUE (uid);


--
-- Name: uk_mcn0op3hsf5ajqg5k4oli4xkc; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.externalnotificationlogentry
    ADD CONSTRAINT uk_mcn0op3hsf5ajqg5k4oli4xkc UNIQUE (key);


--
-- Name: uk_mihkls5oq503326b4dvvf2vas; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.optiongroupsettranslations
    ADD CONSTRAINT uk_mihkls5oq503326b4dvvf2vas UNIQUE (objecttranslationid);


--
-- Name: uk_mkmh30sqxkifqkjihsosae8rm; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.documenttranslations
    ADD CONSTRAINT uk_mkmh30sqxkifqkjihsosae8rm UNIQUE (objecttranslationid);


--
-- Name: uk_mlop2afk26fwowa69lr9a138y; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dataelementcategoryoption
    ADD CONSTRAINT uk_mlop2afk26fwowa69lr9a138y UNIQUE (code);


--
-- Name: uk_mn4yowauiafr72rvtkc9kql0; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dataapprovalworkflowuseraccesses
    ADD CONSTRAINT uk_mn4yowauiafr72rvtkc9kql0 UNIQUE (useraccessid);


--
-- Name: uk_mq0y6uuq2erprg2siebo2mk1o; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.datasetnotificationtemplate
    ADD CONSTRAINT uk_mq0y6uuq2erprg2siebo2mk1o UNIQUE (code);


--
-- Name: uk_mrxaf7d00g0p3onf48h0buu49; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.trackedentitytypeattributevalues
    ADD CONSTRAINT uk_mrxaf7d00g0p3onf48h0buu49 UNIQUE (attributevalueid);


--
-- Name: uk_my7leeuqstyx0vtwqtrq4le1c; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dataentryformtranslations
    ADD CONSTRAINT uk_my7leeuqstyx0vtwqtrq4le1c UNIQUE (objecttranslationid);


--
-- Name: uk_mykebcm6fpe3o1wtpfgo9tudn; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.attributetranslations
    ADD CONSTRAINT uk_mykebcm6fpe3o1wtpfgo9tudn UNIQUE (objecttranslationid);


--
-- Name: uk_myox13mr8r27oxl7ts33ntpd5; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dashboard
    ADD CONSTRAINT uk_myox13mr8r27oxl7ts33ntpd5 UNIQUE (uid);


--
-- Name: uk_n18s4feicujvngv2ajoesdgio; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dataapprovalworkflow
    ADD CONSTRAINT uk_n18s4feicujvngv2ajoesdgio UNIQUE (name);


--
-- Name: uk_n22yq0eqvsg1n7gug43w66udv; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.indicatorgroupsettranslations
    ADD CONSTRAINT uk_n22yq0eqvsg1n7gug43w66udv UNIQUE (objecttranslationid);


--
-- Name: uk_n3kddotvpw0biusai8obu86vn; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.legendsetusergroupaccesses
    ADD CONSTRAINT uk_n3kddotvpw0biusai8obu86vn UNIQUE (usergroupaccessid);


--
-- Name: uk_n3y61d1yoemd783r8mkntt3k1; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.charttranslations
    ADD CONSTRAINT uk_n3y61d1yoemd783r8mkntt3k1 UNIQUE (objecttranslationid);


--
-- Name: uk_n4xputyk31femiaxls6lbl2rw; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.indicatorgroupset
    ADD CONSTRAINT uk_n4xputyk31femiaxls6lbl2rw UNIQUE (uid);


--
-- Name: uk_n5ax669vkj63nx3rrvlushqdm; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pushanalysis
    ADD CONSTRAINT uk_n5ax669vkj63nx3rrvlushqdm UNIQUE (code);


--
-- Name: uk_n8mbmryeksa80ucyxj0vg6p9b; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.indicatortype
    ADD CONSTRAINT uk_n8mbmryeksa80ucyxj0vg6p9b UNIQUE (name);


--
-- Name: uk_nagn6joav6kgodhdcwirqoklf; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.userroletranslations
    ADD CONSTRAINT uk_nagn6joav6kgodhdcwirqoklf UNIQUE (objecttranslationid);


--
-- Name: uk_nbkvt8dj4ocmbv8okga2nvop2; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.usergroupuseraccesses
    ADD CONSTRAINT uk_nbkvt8dj4ocmbv8okga2nvop2 UNIQUE (useraccessid);


--
-- Name: uk_ni7epmbxtn4jcax3ya324ff9w; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.oauth2client
    ADD CONSTRAINT uk_ni7epmbxtn4jcax3ya324ff9w UNIQUE (cid);


--
-- Name: uk_nipo7t010a80osh7okxswav2g; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.optiongroup
    ADD CONSTRAINT uk_nipo7t010a80osh7okxswav2g UNIQUE (uid);


--
-- Name: uk_nl4hw4ti986dje72b6csrmh3v; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dataelementgroupsetuseraccesses
    ADD CONSTRAINT uk_nl4hw4ti986dje72b6csrmh3v UNIQUE (useraccessid);


--
-- Name: uk_nqdtggpr548q0tnbu919puw0p; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.messageconversation_messages
    ADD CONSTRAINT uk_nqdtggpr548q0tnbu919puw0p UNIQUE (messageid);


--
-- Name: uk_nwgvrevv2slj1bvc9m01p89lf; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.oauth2client
    ADD CONSTRAINT uk_nwgvrevv2slj1bvc9m01p89lf UNIQUE (name);


--
-- Name: uk_nwq3y4xqct21tdl0l77bvmpoe; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.optiongroup
    ADD CONSTRAINT uk_nwq3y4xqct21tdl0l77bvmpoe UNIQUE (shortname);


--
-- Name: uk_nywvip5682tuvxrnwjomeyg6y; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.constant
    ADD CONSTRAINT uk_nywvip5682tuvxrnwjomeyg6y UNIQUE (uid);


--
-- Name: uk_o0v1fdqiyte40ffm9q3nhcj4v; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.predictor
    ADD CONSTRAINT uk_o0v1fdqiyte40ffm9q3nhcj4v UNIQUE (code);


--
-- Name: uk_o2xbcli806eba6dkdfco0o3kc; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.constant
    ADD CONSTRAINT uk_o2xbcli806eba6dkdfco0o3kc UNIQUE (name);


--
-- Name: uk_oeni5ndit5g033f1s1j08bdry; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dataset
    ADD CONSTRAINT uk_oeni5ndit5g033f1s1j08bdry UNIQUE (code);


--
-- Name: uk_ofc2a89rccimogdp9ownwcuy1; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.colorset
    ADD CONSTRAINT uk_ofc2a89rccimogdp9ownwcuy1 UNIQUE (name);


--
-- Name: uk_ofw2gg6ghv4rkqo24rm9yhpdt; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.optionattributevalues
    ADD CONSTRAINT uk_ofw2gg6ghv4rkqo24rm9yhpdt UNIQUE (attributevalueid);


--
-- Name: uk_og1fdqhhylbk69fxpoth4bd36; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sqlviewusergroupaccesses
    ADD CONSTRAINT uk_og1fdqhhylbk69fxpoth4bd36 UNIQUE (usergroupaccessid);


--
-- Name: uk_oith7i266qbjggmij30psueoo; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.eventreportusergroupaccesses
    ADD CONSTRAINT uk_oith7i266qbjggmij30psueoo UNIQUE (usergroupaccessid);


--
-- Name: uk_oj2bhkjfgcl9rcwlf579dl1d6; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.colorset
    ADD CONSTRAINT uk_oj2bhkjfgcl9rcwlf579dl1d6 UNIQUE (uid);


--
-- Name: uk_ol8n7oq6clgxvqjedlpn85aqo; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.categoryoptiongroup
    ADD CONSTRAINT uk_ol8n7oq6clgxvqjedlpn85aqo UNIQUE (uid);


--
-- Name: uk_ootm3uj9gtw6csbv71esyrxfv; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.optionsettranslations
    ADD CONSTRAINT uk_ootm3uj9gtw6csbv71esyrxfv UNIQUE (objecttranslationid);


--
-- Name: uk_opmqksrjv8o98p5bwfhhfapwr; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dataelementgroupuseraccesses
    ADD CONSTRAINT uk_opmqksrjv8o98p5bwfhhfapwr UNIQUE (useraccessid);


--
-- Name: uk_oqfck0kamahjps18dep2ogcw1; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.orgunitgroupsetuseraccesses
    ADD CONSTRAINT uk_oqfck0kamahjps18dep2ogcw1 UNIQUE (useraccessid);


--
-- Name: uk_orq3pwtro2yu9yydh046bn40j; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.trackedentityinstance
    ADD CONSTRAINT uk_orq3pwtro2yu9yydh046bn40j UNIQUE (code);


--
-- Name: uk_os4r1umsvtmbuqm2bo25s5ej0; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.programstagedataelement
    ADD CONSTRAINT uk_os4r1umsvtmbuqm2bo25s5ej0 UNIQUE (uid);


--
-- Name: uk_oso7fghriw7yliyriqw5o9io3; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.datasetuseraccesses
    ADD CONSTRAINT uk_oso7fghriw7yliyriqw5o9io3 UNIQUE (useraccessid);


--
-- Name: uk_ot8a05g9d4k5l67xi062xx5w6; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.programnotificationtemplate
    ADD CONSTRAINT uk_ot8a05g9d4k5l67xi062xx5w6 UNIQUE (code);


--
-- Name: uk_otvwcgv4bxjtqfj3flhrnmgf7; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dataelementgroup
    ADD CONSTRAINT uk_otvwcgv4bxjtqfj3flhrnmgf7 UNIQUE (uid);


--
-- Name: uk_ow5b3iks1dgs1hqimo59fgegl; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dashboarduseraccesses
    ADD CONSTRAINT uk_ow5b3iks1dgs1hqimo59fgegl UNIQUE (useraccessid);


--
-- Name: uk_owox8geab5xje0ujlsetcaxj4; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.colortranslations
    ADD CONSTRAINT uk_owox8geab5xje0ujlsetcaxj4 UNIQUE (objecttranslationid);


--
-- Name: uk_p0p3bwhgbsdemu14v23p47qne; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.indicatortype
    ADD CONSTRAINT uk_p0p3bwhgbsdemu14v23p47qne UNIQUE (uid);


--
-- Name: uk_p0rvldurcmk0x3mx39lt5uvsd; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.optionset
    ADD CONSTRAINT uk_p0rvldurcmk0x3mx39lt5uvsd UNIQUE (name);


--
-- Name: uk_p7arcbl58mmcrj2didtr0ruqh; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.programrule
    ADD CONSTRAINT uk_p7arcbl58mmcrj2didtr0ruqh UNIQUE (uid);


--
-- Name: uk_p7egnv3sj4ugyl23mk4vga40k; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dataelementgroupset
    ADD CONSTRAINT uk_p7egnv3sj4ugyl23mk4vga40k UNIQUE (code);


--
-- Name: uk_p8tvo9tqrdn5tb45d0g5cko5o; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dataentryform
    ADD CONSTRAINT uk_p8tvo9tqrdn5tb45d0g5cko5o UNIQUE (name);


--
-- Name: uk_p95o4dnytx8vxb7yugxlu2hhf; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.categorycombousergroupaccesses
    ADD CONSTRAINT uk_p95o4dnytx8vxb7yugxlu2hhf UNIQUE (usergroupaccessid);


--
-- Name: uk_pag45qp5gr17svxsntj5tjw66; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.mapusergroupaccesses
    ADD CONSTRAINT uk_pag45qp5gr17svxsntj5tjw66 UNIQUE (usergroupaccessid);


--
-- Name: uk_pbj3u1nk9vnuof8f47utvowmv; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dataelementcategoryoption
    ADD CONSTRAINT uk_pbj3u1nk9vnuof8f47utvowmv UNIQUE (name);


--
-- Name: uk_ppi146eky8fodu97t1o21vkd8; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.datastatistics
    ADD CONSTRAINT uk_ppi146eky8fodu97t1o21vkd8 UNIQUE (uid);


--
-- Name: uk_pw2bgc9ykjad2obefeqha28t4; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.organisationunit
    ADD CONSTRAINT uk_pw2bgc9ykjad2obefeqha28t4 UNIQUE (path);


--
-- Name: uk_pw87bi64e3ev11k7dwrmljo78; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dataelementcategory
    ADD CONSTRAINT uk_pw87bi64e3ev11k7dwrmljo78 UNIQUE (code);


--
-- Name: uk_q0obvr5rvxhlnjs367y1f0bav; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dataentryform
    ADD CONSTRAINT uk_q0obvr5rvxhlnjs367y1f0bav UNIQUE (uid);


--
-- Name: uk_q0oyainj1lis9c8kkh5sky2ri; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.eventreport
    ADD CONSTRAINT uk_q0oyainj1lis9c8kkh5sky2ri UNIQUE (relativeperiodsid);


--
-- Name: uk_q20sh82vk885ooi7fekwtboej; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.usergroup
    ADD CONSTRAINT uk_q20sh82vk885ooi7fekwtboej UNIQUE (code);


--
-- Name: uk_q2mhld3431cikld8ocnognnl3; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.userattributevalues
    ADD CONSTRAINT uk_q2mhld3431cikld8ocnognnl3 UNIQUE (attributevalueid);


--
-- Name: uk_q5kj01mnv9vystj3dax3a4vc0; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.optiongroupusergroupaccesses
    ADD CONSTRAINT uk_q5kj01mnv9vystj3dax3a4vc0 UNIQUE (usergroupaccessid);


--
-- Name: uk_q9jv2e3fy49hc1havuwnr0res; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.optiongroupset
    ADD CONSTRAINT uk_q9jv2e3fy49hc1havuwnr0res UNIQUE (code);


--
-- Name: uk_qa5c4eva4rxafw5b7eyddp64m; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.usergroupusergroupaccesses
    ADD CONSTRAINT uk_qa5c4eva4rxafw5b7eyddp64m UNIQUE (usergroupaccessid);


--
-- Name: uk_qaqvbi3rmqrmsesdwr2dkltwd; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.indicatorgroupattributevalues
    ADD CONSTRAINT uk_qaqvbi3rmqrmsesdwr2dkltwd UNIQUE (attributevalueid);


--
-- Name: uk_qat66cbfwvsqh51auos3ktk0p; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.programstagesectiontranslations
    ADD CONSTRAINT uk_qat66cbfwvsqh51auos3ktk0p UNIQUE (objecttranslationid);


--
-- Name: uk_qba465kdmkyxal2f05g3f1f94; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.interpretationusergroupaccesses
    ADD CONSTRAINT uk_qba465kdmkyxal2f05g3f1f94 UNIQUE (usergroupaccessid);


--
-- Name: uk_qki43s9vdndg15c9tyv718u1j; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.categoryoptioncombo
    ADD CONSTRAINT uk_qki43s9vdndg15c9tyv718u1j UNIQUE (uid);


--
-- Name: uk_qogg9a7yy4qconomxt4j4upql; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.i18nlocale
    ADD CONSTRAINT uk_qogg9a7yy4qconomxt4j4upql UNIQUE (name);


--
-- Name: uk_qp9201a4m6jl53sei0huh4l6s; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dataelementcategoryoption
    ADD CONSTRAINT uk_qp9201a4m6jl53sei0huh4l6s UNIQUE (shortname);


--
-- Name: uk_qunv1hucv9wi5pt92tur929mr; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pushanalysis
    ADD CONSTRAINT uk_qunv1hucv9wi5pt92tur929mr UNIQUE (uid);


--
-- Name: uk_qwk9qdapql867enp5r7fa0uic; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.orgunitgroup
    ADD CONSTRAINT uk_qwk9qdapql867enp5r7fa0uic UNIQUE (name);


--
-- Name: uk_qxhx7vgarh0v2w1dxv211knmq; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.trackedentitytypeuseraccesses
    ADD CONSTRAINT uk_qxhx7vgarh0v2w1dxv211knmq UNIQUE (useraccessid);


--
-- Name: uk_r0njvkxgdxior87ay09qxvd4g; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.orgunitgroupusergroupaccesses
    ADD CONSTRAINT uk_r0njvkxgdxior87ay09qxvd4g UNIQUE (usergroupaccessid);


--
-- Name: uk_r2f9o8i6th2w8vqdexdfo72ui; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.program_attributes
    ADD CONSTRAINT uk_r2f9o8i6th2w8vqdexdfo72ui UNIQUE (code);


--
-- Name: uk_r3ugbbibdsyn234isip3346v4; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.externalmaplayer
    ADD CONSTRAINT uk_r3ugbbibdsyn234isip3346v4 UNIQUE (code);


--
-- Name: uk_r43af9ap4edm43mmtq01oddj6; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT uk_r43af9ap4edm43mmtq01oddj6 UNIQUE (username);


--
-- Name: uk_r6ebedjcac8c49c53aa1mpa8e; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.validationresult
    ADD CONSTRAINT uk_r6ebedjcac8c49c53aa1mpa8e UNIQUE (validationruleid, periodid, organisationunitid, attributeoptioncomboid, dayinperiod);


--
-- Name: uk_r6o97x370i5t9lbcico61kxaf; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.programstageuseraccesses
    ADD CONSTRAINT uk_r6o97x370i5t9lbcico61kxaf UNIQUE (useraccessid);


--
-- Name: uk_r7rsiyfyy01l2i21s4y2o6s4i; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.categoryoptiongrouptranslations
    ADD CONSTRAINT uk_r7rsiyfyy01l2i21s4y2o6s4i UNIQUE (objecttranslationid);


--
-- Name: uk_rbr4kyuk4s0kb4jo1r77cuaq9; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.trackedentityinstance
    ADD CONSTRAINT uk_rbr4kyuk4s0kb4jo1r77cuaq9 UNIQUE (uid);


--
-- Name: uk_rh1jwubao1t728iys0662k7go; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.datasetattributevalues
    ADD CONSTRAINT uk_rh1jwubao1t728iys0662k7go UNIQUE (attributevalueid);


--
-- Name: uk_rqkhk3ebvk1kflf7qigbaxeyp; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.jobconfiguration
    ADD CONSTRAINT uk_rqkhk3ebvk1kflf7qigbaxeyp UNIQUE (name);


--
-- Name: uk_rrv70c7ej18sptdwj7h6ac5rv; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.color
    ADD CONSTRAINT uk_rrv70c7ej18sptdwj7h6ac5rv UNIQUE (uid);


--
-- Name: uk_rtty45gvm30id8sglrlmacatq; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.documentusergroupaccesses
    ADD CONSTRAINT uk_rtty45gvm30id8sglrlmacatq UNIQUE (usergroupaccessid);


--
-- Name: uk_rvfiukug5ui7qidoiln3el3aa; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.optionset
    ADD CONSTRAINT uk_rvfiukug5ui7qidoiln3el3aa UNIQUE (code);


--
-- Name: uk_s0mt3w36ir8v1ikcmcn1lptxt; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.trackedentitytypeusergroupaccesses
    ADD CONSTRAINT uk_s0mt3w36ir8v1ikcmcn1lptxt UNIQUE (usergroupaccessid);


--
-- Name: uk_sc8477b26totcch3j096m2n2y; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.datasetusergroupaccesses
    ADD CONSTRAINT uk_sc8477b26totcch3j096m2n2y UNIQUE (usergroupaccessid);


--
-- Name: uk_sdng31h9qjawcikcllry8a8a5; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.jobconfiguration
    ADD CONSTRAINT uk_sdng31h9qjawcikcllry8a8a5 UNIQUE (uid);


--
-- Name: uk_skg9d1lewqm1qjaduqb3ly1bk; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.eventreportuseraccesses
    ADD CONSTRAINT uk_skg9d1lewqm1qjaduqb3ly1bk UNIQUE (useraccessid);


--
-- Name: uk_skin40axv0jcme3bhsbb7156i; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.validationcriteria
    ADD CONSTRAINT uk_skin40axv0jcme3bhsbb7156i UNIQUE (code);


--
-- Name: uk_sp03w6tda9gyq1724bnm1rdfn; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dashboarditemtranslations
    ADD CONSTRAINT uk_sp03w6tda9gyq1724bnm1rdfn UNIQUE (objecttranslationid);


--
-- Name: uk_sspviu4m0l0lf7ef3t3cagfxd; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.indicatorgroup
    ADD CONSTRAINT uk_sspviu4m0l0lf7ef3t3cagfxd UNIQUE (code);


--
-- Name: uk_swp8dipq45oxtu0ykp3x36frc; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.programindicatortranslations
    ADD CONSTRAINT uk_swp8dipq45oxtu0ykp3x36frc UNIQUE (objecttranslationid);


--
-- Name: uk_t0dg39dopew9f6y64ucsx7194; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.validationrule
    ADD CONSTRAINT uk_t0dg39dopew9f6y64ucsx7194 UNIQUE (uid);


--
-- Name: uk_t0srkng3akwg3pcp5qlwcx06n; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.orgunitgroup
    ADD CONSTRAINT uk_t0srkng3akwg3pcp5qlwcx06n UNIQUE (shortname);


--
-- Name: uk_t5lxvc1km3ylon5st1fuabsgl; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.orgunitgroupset
    ADD CONSTRAINT uk_t5lxvc1km3ylon5st1fuabsgl UNIQUE (name);


--
-- Name: uk_t8f0bvwyn7re1pl2cqiqbo5l4; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.programindicatorgrouptranslations
    ADD CONSTRAINT uk_t8f0bvwyn7re1pl2cqiqbo5l4 UNIQUE (objecttranslationid);


--
-- Name: uk_t9e1mnpydje0rsvinxq68q1i6; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.smscommandcodes
    ADD CONSTRAINT uk_t9e1mnpydje0rsvinxq68q1i6 UNIQUE (codeid);


--
-- Name: uk_ta80keoi67443tkvvmx8l872x; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.indicator
    ADD CONSTRAINT uk_ta80keoi67443tkvvmx8l872x UNIQUE (uid);


--
-- Name: uk_tbkbjga8h4j5u33d7hbcuk66t; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.period
    ADD CONSTRAINT uk_tbkbjga8h4j5u33d7hbcuk66t UNIQUE (periodtypeid, startdate, enddate);


--
-- Name: uk_tbro727eo15qmn3ghlhoyifih; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.reporttableusergroupaccesses
    ADD CONSTRAINT uk_tbro727eo15qmn3ghlhoyifih UNIQUE (usergroupaccessid);


--
-- Name: uk_tcggvcb1rsd9tlnd1ub7mt0e0; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.programstageusergroupaccesses
    ADD CONSTRAINT uk_tcggvcb1rsd9tlnd1ub7mt0e0 UNIQUE (usergroupaccessid);


--
-- Name: uk_tcx1w0yoc6k0h8qnagg18eqs6; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.programstageattributevalues
    ADD CONSTRAINT uk_tcx1w0yoc6k0h8qnagg18eqs6 UNIQUE (attributevalueid);


--
-- Name: uk_tglbwfy1e3ubt5x5hab46qbh6; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.programsection
    ADD CONSTRAINT uk_tglbwfy1e3ubt5x5hab46qbh6 UNIQUE (code);


--
-- Name: uk_thb8irn2kmm7jay3vcogqxy3x; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.trackedentitytype
    ADD CONSTRAINT uk_thb8irn2kmm7jay3vcogqxy3x UNIQUE (name);


--
-- Name: uk_tikknlgl0im3w68yvlb0swrgd; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.keyjsonvalue
    ADD CONSTRAINT uk_tikknlgl0im3w68yvlb0swrgd UNIQUE (code);


--
-- Name: uk_to3d8d23u9behgh9acdu2wjvl; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.trackedentitytype
    ADD CONSTRAINT uk_to3d8d23u9behgh9acdu2wjvl UNIQUE (code);


--
-- Name: uk_wlnk52s02wyg234ugfkngjf5; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.programtranslations
    ADD CONSTRAINT uk_wlnk52s02wyg234ugfkngjf5 UNIQUE (objecttranslationid);


--
-- Name: useraccess_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.useraccess
    ADD CONSTRAINT useraccess_pkey PRIMARY KEY (useraccessid);


--
-- Name: userapps_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.userapps
    ADD CONSTRAINT userapps_pkey PRIMARY KEY (userinfoid, sort_order);


--
-- Name: userattributevalues_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.userattributevalues
    ADD CONSTRAINT userattributevalues_pkey PRIMARY KEY (userinfoid, attributevalueid);


--
-- Name: userdatavieworgunits_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.userdatavieworgunits
    ADD CONSTRAINT userdatavieworgunits_pkey PRIMARY KEY (userinfoid, organisationunitid);


--
-- Name: usergroup_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.usergroup
    ADD CONSTRAINT usergroup_pkey PRIMARY KEY (usergroupid);


--
-- Name: usergroupaccess_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.usergroupaccess
    ADD CONSTRAINT usergroupaccess_pkey PRIMARY KEY (usergroupaccessid);


--
-- Name: usergroupattributevalues_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.usergroupattributevalues
    ADD CONSTRAINT usergroupattributevalues_pkey PRIMARY KEY (usergroupid, attributevalueid);


--
-- Name: usergroupmanaged_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.usergroupmanaged
    ADD CONSTRAINT usergroupmanaged_pkey PRIMARY KEY (managedbygroupid, managedgroupid);


--
-- Name: usergroupmembers_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.usergroupmembers
    ADD CONSTRAINT usergroupmembers_pkey PRIMARY KEY (usergroupid, userid);


--
-- Name: usergrouptranslations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.usergrouptranslations
    ADD CONSTRAINT usergrouptranslations_pkey PRIMARY KEY (usergroupid, objecttranslationid);


--
-- Name: usergroupuseraccesses_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.usergroupuseraccesses
    ADD CONSTRAINT usergroupuseraccesses_pkey PRIMARY KEY (usergroupid, useraccessid);


--
-- Name: usergroupusergroupaccesses_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.usergroupusergroupaccesses
    ADD CONSTRAINT usergroupusergroupaccesses_pkey PRIMARY KEY (usergroupid, usergroupaccessid);


--
-- Name: userinfo_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.userinfo
    ADD CONSTRAINT userinfo_pkey PRIMARY KEY (userinfoid);


--
-- Name: userkeyjsonvalue_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.userkeyjsonvalue
    ADD CONSTRAINT userkeyjsonvalue_pkey PRIMARY KEY (userkeyjsonvalueid);


--
-- Name: userkeyjsonvalue_unique_key_on_user_and_namespace; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.userkeyjsonvalue
    ADD CONSTRAINT userkeyjsonvalue_unique_key_on_user_and_namespace UNIQUE (userid, namespace, userkey);


--
-- Name: usermembership_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.usermembership
    ADD CONSTRAINT usermembership_pkey PRIMARY KEY (userinfoid, organisationunitid);


--
-- Name: usermessage_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.usermessage
    ADD CONSTRAINT usermessage_pkey PRIMARY KEY (usermessageid);


--
-- Name: userrole_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.userrole
    ADD CONSTRAINT userrole_pkey PRIMARY KEY (userroleid);


--
-- Name: userrolemembers_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.userrolemembers
    ADD CONSTRAINT userrolemembers_pkey PRIMARY KEY (userid, userroleid);


--
-- Name: userroletranslations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.userroletranslations
    ADD CONSTRAINT userroletranslations_pkey PRIMARY KEY (userroleid, objecttranslationid);


--
-- Name: userroleuseraccesses_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.userroleuseraccesses
    ADD CONSTRAINT userroleuseraccesses_pkey PRIMARY KEY (userroleid, useraccessid);


--
-- Name: userroleusergroupaccesses_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.userroleusergroupaccesses
    ADD CONSTRAINT userroleusergroupaccesses_pkey PRIMARY KEY (userroleid, usergroupaccessid);


--
-- Name: users_catdimensionconstraints_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users_catdimensionconstraints
    ADD CONSTRAINT users_catdimensionconstraints_pkey PRIMARY KEY (userid, dataelementcategoryid);


--
-- Name: users_cogsdimensionconstraints_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users_cogsdimensionconstraints
    ADD CONSTRAINT users_cogsdimensionconstraints_pkey PRIMARY KEY (userid, categoryoptiongroupsetid);


--
-- Name: users_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (userid);


--
-- Name: usersetting_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.usersetting
    ADD CONSTRAINT usersetting_pkey PRIMARY KEY (userinfoid, name);


--
-- Name: userteisearchorgunits_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.userteisearchorgunits
    ADD CONSTRAINT userteisearchorgunits_pkey PRIMARY KEY (userinfoid, organisationunitid);


--
-- Name: validationcriteria_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.validationcriteria
    ADD CONSTRAINT validationcriteria_pkey PRIMARY KEY (validationcriteriaid);


--
-- Name: validationcriteriatranslations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.validationcriteriatranslations
    ADD CONSTRAINT validationcriteriatranslations_pkey PRIMARY KEY (validationcriteriaid, objecttranslationid);


--
-- Name: validationnotificationtemplate_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.validationnotificationtemplate
    ADD CONSTRAINT validationnotificationtemplate_pkey PRIMARY KEY (validationnotificationtemplateid);


--
-- Name: validationnotificationtemplate_recipientusergroups_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.validationnotificationtemplate_recipientusergroups
    ADD CONSTRAINT validationnotificationtemplate_recipientusergroups_pkey PRIMARY KEY (validationnotificationtemplateid, usergroupid);


--
-- Name: validationnotificationtemplatevalidationrules_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.validationnotificationtemplatevalidationrules
    ADD CONSTRAINT validationnotificationtemplatevalidationrules_pkey PRIMARY KEY (validationnotificationtemplateid, validationruleid);


--
-- Name: validationresult_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.validationresult
    ADD CONSTRAINT validationresult_pkey PRIMARY KEY (validationresultid);


--
-- Name: validationrule_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.validationrule
    ADD CONSTRAINT validationrule_pkey PRIMARY KEY (validationruleid);


--
-- Name: validationrulegroup_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.validationrulegroup
    ADD CONSTRAINT validationrulegroup_pkey PRIMARY KEY (validationrulegroupid);


--
-- Name: validationrulegroupmembers_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.validationrulegroupmembers
    ADD CONSTRAINT validationrulegroupmembers_pkey PRIMARY KEY (validationgroupid, validationruleid);


--
-- Name: validationrulegrouptranslations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.validationrulegrouptranslations
    ADD CONSTRAINT validationrulegrouptranslations_pkey PRIMARY KEY (validationrulegroupid, objecttranslationid);


--
-- Name: validationrulegroupuseraccesses_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.validationrulegroupuseraccesses
    ADD CONSTRAINT validationrulegroupuseraccesses_pkey PRIMARY KEY (validationrulegroupid, useraccessid);


--
-- Name: validationrulegroupusergroupaccesses_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.validationrulegroupusergroupaccesses
    ADD CONSTRAINT validationrulegroupusergroupaccesses_pkey PRIMARY KEY (validationrulegroupid, usergroupaccessid);


--
-- Name: validationruletranslations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.validationruletranslations
    ADD CONSTRAINT validationruletranslations_pkey PRIMARY KEY (validationruleid, objecttranslationid);


--
-- Name: validationruleuseraccesses_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.validationruleuseraccesses
    ADD CONSTRAINT validationruleuseraccesses_pkey PRIMARY KEY (validationruleid, useraccessid);


--
-- Name: validationruleusergroupaccesses_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.validationruleusergroupaccesses
    ADD CONSTRAINT validationruleusergroupaccesses_pkey PRIMARY KEY (validationruleid, usergroupaccessid);


--
-- Name: version_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.version
    ADD CONSTRAINT version_pkey PRIMARY KEY (versionid);


--
-- Name: version_versionkey_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.version
    ADD CONSTRAINT version_versionkey_key UNIQUE (versionkey);


--
-- Name: id_datavalueaudit_created; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX id_datavalueaudit_created ON public.datavalueaudit USING btree (created);


--
-- Name: in_categoryoptioncombo_name; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX in_categoryoptioncombo_name ON public.categoryoptioncombo USING btree (name);


--
-- Name: in_dataapprovallevel_level; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX in_dataapprovallevel_level ON public.dataapprovallevel USING btree (level);


--
-- Name: in_datavalue_deleted; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX in_datavalue_deleted ON public.datavalue USING btree (deleted);


--
-- Name: in_datavalue_lastupdated; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX in_datavalue_lastupdated ON public.datavalue USING btree (lastupdated);


--
-- Name: in_datavalueaudit; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX in_datavalueaudit ON public.datavalueaudit USING btree (dataelementid, periodid, organisationunitid, categoryoptioncomboid, attributeoptioncomboid);


--
-- Name: in_organisationunit_hierarchylevel; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX in_organisationunit_hierarchylevel ON public.organisationunit USING btree (hierarchylevel);


--
-- Name: in_organisationunit_path; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX in_organisationunit_path ON public.organisationunit USING btree (path);


--
-- Name: in_parentid; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX in_parentid ON public.organisationunit USING btree (parentid);


--
-- Name: in_programinstance_deleted; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX in_programinstance_deleted ON public.programinstance USING btree (deleted);


--
-- Name: in_trackedentityattributevalue_attributeid; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX in_trackedentityattributevalue_attributeid ON public.trackedentityattributevalue USING btree (trackedentityattributeid);


--
-- Name: in_trackedentityinstance_deleted; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX in_trackedentityinstance_deleted ON public.trackedentityinstance USING btree (deleted);


--
-- Name: index_programinstance; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_programinstance ON public.programinstance USING btree (programinstanceid);


--
-- Name: index_trackedentitydatavalue_programstageinstanceid; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_trackedentitydatavalue_programstageinstanceid ON public.trackedentitydatavalue USING btree (programstageinstanceid);


--
-- Name: index_trackedentitydatavalueaudit_programstageinstanceid; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_trackedentitydatavalueaudit_programstageinstanceid ON public.trackedentitydatavalueaudit USING btree (programstageinstanceid);


--
-- Name: interpretation_lastupdated; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX interpretation_lastupdated ON public.interpretation USING btree (lastupdated);


--
-- Name: maplegend_endvalue; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX maplegend_endvalue ON public.maplegend USING btree (endvalue);


--
-- Name: maplegend_startvalue; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX maplegend_startvalue ON public.maplegend USING btree (startvalue);


--
-- Name: messageconversation_lastmessage; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX messageconversation_lastmessage ON public.messageconversation USING btree (lastmessage);


--
-- Name: outbound_sms_status_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX outbound_sms_status_index ON public.outbound_sms USING btree (status);


--
-- Name: programstageinstance_executiondate; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX programstageinstance_executiondate ON public.programstageinstance USING btree (executiondate);


--
-- Name: programstageinstance_organisationunitid; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX programstageinstance_organisationunitid ON public.programstageinstance USING btree (organisationunitid);


--
-- Name: programstageinstance_programinstanceid; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX programstageinstance_programinstanceid ON public.programstageinstance USING btree (programinstanceid);


--
-- Name: sms_originator_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX sms_originator_index ON public.incomingsms USING btree (originator);


--
-- Name: sms_status_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX sms_status_index ON public.incomingsms USING btree (status);


--
-- Name: userkeyjsonvalue_user; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX userkeyjsonvalue_user ON public.userkeyjsonvalue USING btree (userid);


--
-- Name: usermessage_isread; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX usermessage_isread ON public.usermessage USING btree (isread);


--
-- Name: usermessage_userid; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX usermessage_userid ON public.usermessage USING btree (userid);


--
-- Name: fk14vlc8tv4kna36p6qonceo8ma; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.datasetattributevalues
    ADD CONSTRAINT fk14vlc8tv4kna36p6qonceo8ma FOREIGN KEY (datasetid) REFERENCES public.dataset(datasetid);


--
-- Name: fk169bwamdcwh0lg6aps61gvmlk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.programstageuseraccesses
    ADD CONSTRAINT fk169bwamdcwh0lg6aps61gvmlk FOREIGN KEY (programstageid) REFERENCES public.programstage(programstageid);


--
-- Name: fk17dg8ly2uqt4ia9s9r2n3ujdw; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.externalmaplayeruseraccesses
    ADD CONSTRAINT fk17dg8ly2uqt4ia9s9r2n3ujdw FOREIGN KEY (useraccessid) REFERENCES public.useraccess(useraccessid);


--
-- Name: fk1nlm1116kc90wbuo78notvb9v; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dataelementgroupusergroupaccesses
    ADD CONSTRAINT fk1nlm1116kc90wbuo78notvb9v FOREIGN KEY (usergroupaccessid) REFERENCES public.usergroupaccess(usergroupaccessid);


--
-- Name: fk1ps7mt73qi3wnt6f5g6w6flga; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.indicatorlegendsets
    ADD CONSTRAINT fk1ps7mt73qi3wnt6f5g6w6flga FOREIGN KEY (indicatorid) REFERENCES public.indicator(indicatorid);


--
-- Name: fk1swcppe8kkvl6xbm4q47r0gal; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.programstagesectiontranslations
    ADD CONSTRAINT fk1swcppe8kkvl6xbm4q47r0gal FOREIGN KEY (objecttranslationid) REFERENCES public.objecttranslation(objecttranslationid);


--
-- Name: fk1ucfah0si2drvdg2k3j9nj2e9; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.programindicatorgroupattributevalues
    ADD CONSTRAINT fk1ucfah0si2drvdg2k3j9nj2e9 FOREIGN KEY (programindicatorgroupid) REFERENCES public.programindicatorgroup(programindicatorgroupid);


--
-- Name: fk25i3g1nx0hyjsim5cybdi73ly; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.usergroupattributevalues
    ADD CONSTRAINT fk25i3g1nx0hyjsim5cybdi73ly FOREIGN KEY (usergroupid) REFERENCES public.usergroup(usergroupid);


--
-- Name: fk25krkr877ipngidd8k4qkpb38; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.reporttableusergroupaccesses
    ADD CONSTRAINT fk25krkr877ipngidd8k4qkpb38 FOREIGN KEY (reporttableid) REFERENCES public.reporttable(reporttableid);


--
-- Name: fk261naj7ctjaktanyq0hv5j9ec; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.reportuseraccesses
    ADD CONSTRAINT fk261naj7ctjaktanyq0hv5j9ec FOREIGN KEY (useraccessid) REFERENCES public.useraccess(useraccessid);


--
-- Name: fk27ph3jnjpt5qvqp5xy7adfehn; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.categoryoptiongroupsetuseraccesses
    ADD CONSTRAINT fk27ph3jnjpt5qvqp5xy7adfehn FOREIGN KEY (useraccessid) REFERENCES public.useraccess(useraccessid);


--
-- Name: fk2en3xn8maci4icitadrfn0paq; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dataelementcategoryoptionuseraccesses
    ADD CONSTRAINT fk2en3xn8maci4icitadrfn0paq FOREIGN KEY (categoryoptionid) REFERENCES public.dataelementcategoryoption(categoryoptionid);


--
-- Name: fk2hy76oam582siq2tjq2n1dyya; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.programuseraccesses
    ADD CONSTRAINT fk2hy76oam582siq2tjq2n1dyya FOREIGN KEY (useraccessid) REFERENCES public.useraccess(useraccessid);


--
-- Name: fk2ks20e418jsxjhn02ljypa9tq; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.constanttranslations
    ADD CONSTRAINT fk2ks20e418jsxjhn02ljypa9tq FOREIGN KEY (objecttranslationid) REFERENCES public.objecttranslation(objecttranslationid);


--
-- Name: fk2n7d98hdtlwjacpfd8f7bnpgy; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sqlviewattributevalues
    ADD CONSTRAINT fk2n7d98hdtlwjacpfd8f7bnpgy FOREIGN KEY (sqlviewid) REFERENCES public.sqlview(sqlviewid);


--
-- Name: fk2n9ay939q2uwmieldeypms4cq; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.charttranslations
    ADD CONSTRAINT fk2n9ay939q2uwmieldeypms4cq FOREIGN KEY (objecttranslationid) REFERENCES public.objecttranslation(objecttranslationid);


--
-- Name: fk2sd8w7egccvxbau38rraunkri; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.usergrouptranslations
    ADD CONSTRAINT fk2sd8w7egccvxbau38rraunkri FOREIGN KEY (objecttranslationid) REFERENCES public.objecttranslation(objecttranslationid);


--
-- Name: fk2tjsnauyet9p1qwk3nnbo7tm3; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.programindicatorgroupusergroupaccesses
    ADD CONSTRAINT fk2tjsnauyet9p1qwk3nnbo7tm3 FOREIGN KEY (usergroupaccessid) REFERENCES public.usergroupaccess(usergroupaccessid);


--
-- Name: fk2vbi3ug5jo15ao7pql8ap283j; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.categorycombousergroupaccesses
    ADD CONSTRAINT fk2vbi3ug5jo15ao7pql8ap283j FOREIGN KEY (categorycomboid) REFERENCES public.categorycombo(categorycomboid);


--
-- Name: fk2wqhml4htbnncy911df1io95h; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.optiongroupusergroupaccesses
    ADD CONSTRAINT fk2wqhml4htbnncy911df1io95h FOREIGN KEY (usergroupaccessid) REFERENCES public.usergroupaccess(usergroupaccessid);


--
-- Name: fk2y3uap3vg76fuvmg2mit64y70; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.categoryoptiongroupattributevalues
    ADD CONSTRAINT fk2y3uap3vg76fuvmg2mit64y70 FOREIGN KEY (categoryoptiongroupid) REFERENCES public.categoryoptiongroup(categoryoptiongroupid);


--
-- Name: fk3408hwfswvwfqyfngk1tf5ju8; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.programmessage_phonenumbers
    ADD CONSTRAINT fk3408hwfswvwfqyfngk1tf5ju8 FOREIGN KEY (programmessagephonenumberid) REFERENCES public.programmessage(id);


--
-- Name: fk3b6oymmmc1kscrruinyqpdev8; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dataelementcategoryuseraccesses
    ADD CONSTRAINT fk3b6oymmmc1kscrruinyqpdev8 FOREIGN KEY (categoryid) REFERENCES public.dataelementcategory(categoryid);


--
-- Name: fk3ewb5ew4m1rarec33519cwcsq; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.programmessagetranslations
    ADD CONSTRAINT fk3ewb5ew4m1rarec33519cwcsq FOREIGN KEY (objecttranslationid) REFERENCES public.objecttranslation(objecttranslationid);


--
-- Name: fk3isuwff5den8kdikhctgye0eo; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dataapprovalworkflowtranslations
    ADD CONSTRAINT fk3isuwff5den8kdikhctgye0eo FOREIGN KEY (objecttranslationid) REFERENCES public.objecttranslation(objecttranslationid);


--
-- Name: fk3knplmujf5s9xim8b0ji5krt7; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.datasetuseraccesses
    ADD CONSTRAINT fk3knplmujf5s9xim8b0ji5krt7 FOREIGN KEY (datasetid) REFERENCES public.dataset(datasetid);


--
-- Name: fk3ko28qvx8nwkvmsvyijpswt6s; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.orgunitgroupuseraccesses
    ADD CONSTRAINT fk3ko28qvx8nwkvmsvyijpswt6s FOREIGN KEY (useraccessid) REFERENCES public.useraccess(useraccessid);


--
-- Name: fk3ln0aibaca9diedgu5s8mohbb; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.programindicatortranslations
    ADD CONSTRAINT fk3ln0aibaca9diedgu5s8mohbb FOREIGN KEY (objecttranslationid) REFERENCES public.objecttranslation(objecttranslationid);


--
-- Name: fk3s1raibq34uci95vn5fqihjbs; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.trackedentityattributeattributevalues
    ADD CONSTRAINT fk3s1raibq34uci95vn5fqihjbs FOREIGN KEY (attributevalueid) REFERENCES public.attributevalue(attributevalueid);


--
-- Name: fk3tej1kap633bf97p6qdrd7ivi; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.trackedentityattributeusergroupaccesses
    ADD CONSTRAINT fk3tej1kap633bf97p6qdrd7ivi FOREIGN KEY (trackedentityattributeid) REFERENCES public.trackedentityattribute(trackedentityattributeid);


--
-- Name: fk3x7f8b9rivyb7mrc7nf2wgn6v; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.orgunitgroupattributevalues
    ADD CONSTRAINT fk3x7f8b9rivyb7mrc7nf2wgn6v FOREIGN KEY (attributevalueid) REFERENCES public.attributevalue(attributevalueid);


--
-- Name: fk40ivchljqy3lak45vpxj1spvq; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.optiongroupsetusergroupaccesses
    ADD CONSTRAINT fk40ivchljqy3lak45vpxj1spvq FOREIGN KEY (optiongroupsetid) REFERENCES public.optiongroupset(optiongroupsetid);


--
-- Name: fk445gf30dsp88q10ukoktc675d; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sqlviewattributevalues
    ADD CONSTRAINT fk445gf30dsp88q10ukoktc675d FOREIGN KEY (attributevalueid) REFERENCES public.attributevalue(attributevalueid);


--
-- Name: fk45uc7wfpi4u5gunpl127ehkn2; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.programnotificationtemplate_deliverychannel
    ADD CONSTRAINT fk45uc7wfpi4u5gunpl127ehkn2 FOREIGN KEY (programnotificationtemplatedeliverychannelid) REFERENCES public.programnotificationtemplate(programnotificationtemplateid);


--
-- Name: fk46kfj29g8ql52esjjwvfkelas; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dataelementgrouptranslations
    ADD CONSTRAINT fk46kfj29g8ql52esjjwvfkelas FOREIGN KEY (objecttranslationid) REFERENCES public.objecttranslation(objecttranslationid);


--
-- Name: fk48oqounwggpawxkgo97qgq42m; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.trackedentitytranslations
    ADD CONSTRAINT fk48oqounwggpawxkgo97qgq42m FOREIGN KEY (objecttranslationid) REFERENCES public.objecttranslation(objecttranslationid);


--
-- Name: fk48rkjqk7sell3prjhvgb2wcu0; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.datasetsectiontranslations
    ADD CONSTRAINT fk48rkjqk7sell3prjhvgb2wcu0 FOREIGN KEY (objecttranslationid) REFERENCES public.objecttranslation(objecttranslationid);


--
-- Name: fk4ddpmtxupf3k972xqi2jmwcnb; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.indicatortypetranslations
    ADD CONSTRAINT fk4ddpmtxupf3k972xqi2jmwcnb FOREIGN KEY (objecttranslationid) REFERENCES public.objecttranslation(objecttranslationid);


--
-- Name: fk4hgup0pvaq2lnb5wl0iqrwty1; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dataelementtranslations
    ADD CONSTRAINT fk4hgup0pvaq2lnb5wl0iqrwty1 FOREIGN KEY (objecttranslationid) REFERENCES public.objecttranslation(objecttranslationid);


--
-- Name: fk4j6haj9rbsdi5mg4h2g9bp5f4; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.indicatorattributevalues
    ADD CONSTRAINT fk4j6haj9rbsdi5mg4h2g9bp5f4 FOREIGN KEY (attributevalueid) REFERENCES public.attributevalue(attributevalueid);


--
-- Name: fk4uq2bl31hdu2s4e07rltemk3d; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.programnotificationtemplate
    ADD CONSTRAINT fk4uq2bl31hdu2s4e07rltemk3d FOREIGN KEY (programstageid) REFERENCES public.programstage(programstageid);


--
-- Name: fk53xs445txmje6ydbb5lcsg3q2; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.externalmaplayeruseraccesses
    ADD CONSTRAINT fk53xs445txmje6ydbb5lcsg3q2 FOREIGN KEY (externalmaplayerid) REFERENCES public.externalmaplayer(externalmaplayerid);


--
-- Name: fk55kladmsl0xiqpe7b3kfus2kx; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.optionattributevalues
    ADD CONSTRAINT fk55kladmsl0xiqpe7b3kfus2kx FOREIGN KEY (attributevalueid) REFERENCES public.attributevalue(attributevalueid);


--
-- Name: fk57fqx6vjg8e4yxdr49rh4e2cg; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.interpretationusergroupaccesses
    ADD CONSTRAINT fk57fqx6vjg8e4yxdr49rh4e2cg FOREIGN KEY (interpretationid) REFERENCES public.interpretation(interpretationid);


--
-- Name: fk58p9nvj8c68sjfsc0q27a2xit; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.indicatorgroupuseraccesses
    ADD CONSTRAINT fk58p9nvj8c68sjfsc0q27a2xit FOREIGN KEY (useraccessid) REFERENCES public.useraccess(useraccessid);


--
-- Name: fk5lkioy2ni66gkhk1py1lg2ksk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dataapprovallevelusergroupaccesses
    ADD CONSTRAINT fk5lkioy2ni66gkhk1py1lg2ksk FOREIGN KEY (dataapprovallevelid) REFERENCES public.dataapprovallevel(dataapprovallevelid);


--
-- Name: fk5mc47seuei76yjk4pne9xco4y; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.categoryoptiongroupusergroupaccesses
    ADD CONSTRAINT fk5mc47seuei76yjk4pne9xco4y FOREIGN KEY (usergroupaccessid) REFERENCES public.usergroupaccess(usergroupaccessid);


--
-- Name: fk5s4d4l1e7unmm6gholgprl718; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.optiongroupsettranslations
    ADD CONSTRAINT fk5s4d4l1e7unmm6gholgprl718 FOREIGN KEY (objecttranslationid) REFERENCES public.objecttranslation(objecttranslationid);


--
-- Name: fk5ueo0ouvw1w8ym3bl5a4gy7jb; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dataapprovalworkflowusergroupaccesses
    ADD CONSTRAINT fk5ueo0ouvw1w8ym3bl5a4gy7jb FOREIGN KEY (usergroupaccessid) REFERENCES public.usergroupaccess(usergroupaccessid);


--
-- Name: fk5uw9e42m1bbvtvco3u05w7jtg; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.maplegendsettranslations
    ADD CONSTRAINT fk5uw9e42m1bbvtvco3u05w7jtg FOREIGN KEY (objecttranslationid) REFERENCES public.objecttranslation(objecttranslationid);


--
-- Name: fk670e2rtv9vmfavfqhvew7sq1m; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.orgunitgroupuseraccesses
    ADD CONSTRAINT fk670e2rtv9vmfavfqhvew7sq1m FOREIGN KEY (orgunitgroupid) REFERENCES public.orgunitgroup(orgunitgroupid);


--
-- Name: fk68hlhkbcb70p0241g1jb98iay; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.trackedentitytypeattributevalues
    ADD CONSTRAINT fk68hlhkbcb70p0241g1jb98iay FOREIGN KEY (attributevalueid) REFERENCES public.attributevalue(attributevalueid);


--
-- Name: fk6ai10kbk2id10jrjljspsrwsx; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.organisationunittranslations
    ADD CONSTRAINT fk6ai10kbk2id10jrjljspsrwsx FOREIGN KEY (objecttranslationid) REFERENCES public.objecttranslation(objecttranslationid);


--
-- Name: fk6eqh97iasvtf9f786haw0fne; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.orgunitgroupsetattributevalues
    ADD CONSTRAINT fk6eqh97iasvtf9f786haw0fne FOREIGN KEY (orgunitgroupsetid) REFERENCES public.orgunitgroupset(orgunitgroupsetid);


--
-- Name: fk6hw4ynygmiti256ythmeebnub; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.programindicatorgroupuseraccesses
    ADD CONSTRAINT fk6hw4ynygmiti256ythmeebnub FOREIGN KEY (programindicatorgroupid) REFERENCES public.programindicatorgroup(programindicatorgroupid);


--
-- Name: fk6irf8ungs18rk05t3whhoqsyn; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.validationruleusergroupaccesses
    ADD CONSTRAINT fk6irf8ungs18rk05t3whhoqsyn FOREIGN KEY (validationruleid) REFERENCES public.validationrule(validationruleid);


--
-- Name: fk6l06lsyo0l0d2clfc32fv0n98; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.programindicatoruseraccesses
    ADD CONSTRAINT fk6l06lsyo0l0d2clfc32fv0n98 FOREIGN KEY (programindicatorid) REFERENCES public.programindicator(programindicatorid);


--
-- Name: fk6oepnl7prbw10034c5vot1jii; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.validationnotificationtemplatevalidationrules
    ADD CONSTRAINT fk6oepnl7prbw10034c5vot1jii FOREIGN KEY (validationnotificationtemplateid) REFERENCES public.validationnotificationtemplate(validationnotificationtemplateid);


--
-- Name: fk6q6o2a3x04ku7vfng6c08dl6m; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.legendsetusergroupaccesses
    ADD CONSTRAINT fk6q6o2a3x04ku7vfng6c08dl6m FOREIGN KEY (usergroupaccessid) REFERENCES public.usergroupaccess(usergroupaccessid);


--
-- Name: fk6uqjm4icdf9d4j2tjaj7qbkku; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.trackedentityattributeuseraccesses
    ADD CONSTRAINT fk6uqjm4icdf9d4j2tjaj7qbkku FOREIGN KEY (trackedentityattributeid) REFERENCES public.trackedentityattribute(trackedentityattributeid);


--
-- Name: fk6xa8m39mn0dpitxo4eehwikla; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.relationshiptypetranslations
    ADD CONSTRAINT fk6xa8m39mn0dpitxo4eehwikla FOREIGN KEY (objecttranslationid) REFERENCES public.objecttranslation(objecttranslationid);


--
-- Name: fk6yw6wg9dpo1x48nh29ch85ipl; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.mapuseraccesses
    ADD CONSTRAINT fk6yw6wg9dpo1x48nh29ch85ipl FOREIGN KEY (mapid) REFERENCES public.map(mapid);


--
-- Name: fk73nohma99yprhk24ffqvbxm4p; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.orgunitgroupsetuseraccesses
    ADD CONSTRAINT fk73nohma99yprhk24ffqvbxm4p FOREIGN KEY (useraccessid) REFERENCES public.useraccess(useraccessid);


--
-- Name: fk73om9vfg9ar4dyb74g57g6uq8; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.programindicatorgroupuseraccesses
    ADD CONSTRAINT fk73om9vfg9ar4dyb74g57g6uq8 FOREIGN KEY (useraccessid) REFERENCES public.useraccess(useraccessid);


--
-- Name: fk73s68ejvih451uf1vo0w8wny; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.programtrackedentityattributegrouptranslations
    ADD CONSTRAINT fk73s68ejvih451uf1vo0w8wny FOREIGN KEY (objecttranslationid) REFERENCES public.objecttranslation(objecttranslationid);


--
-- Name: fk78yso1e1xehykrg7kunk5xhdr; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.usergroupuseraccesses
    ADD CONSTRAINT fk78yso1e1xehykrg7kunk5xhdr FOREIGN KEY (usergroupid) REFERENCES public.usergroup(usergroupid);


--
-- Name: fk7a1b7xygd4kd7364syo7igha; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.indicatorgroupusergroupaccesses
    ADD CONSTRAINT fk7a1b7xygd4kd7364syo7igha FOREIGN KEY (indicatorgroupid) REFERENCES public.indicatorgroup(indicatorgroupid);


--
-- Name: fk7aq28bhq2xnps53lpjrgchpoo; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.indicatorgroupattributevalues
    ADD CONSTRAINT fk7aq28bhq2xnps53lpjrgchpoo FOREIGN KEY (attributevalueid) REFERENCES public.attributevalue(attributevalueid);


--
-- Name: fk7f289ja52ca48pnmc2are4k2k; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dataentryformtranslations
    ADD CONSTRAINT fk7f289ja52ca48pnmc2are4k2k FOREIGN KEY (objecttranslationid) REFERENCES public.objecttranslation(objecttranslationid);


--
-- Name: fk7foo7k55ee6dko9a0a0jtxavx; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.programindicatorattributevalues
    ADD CONSTRAINT fk7foo7k55ee6dko9a0a0jtxavx FOREIGN KEY (programindicatorid) REFERENCES public.programindicator(programindicatorid);


--
-- Name: fk7gxwqyqxq8cdxbwpl7unmmi9j; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.constantattributevalues
    ADD CONSTRAINT fk7gxwqyqxq8cdxbwpl7unmmi9j FOREIGN KEY (constantid) REFERENCES public.constant(constantid);


--
-- Name: fk7log6kkhhxdl8wbqirtw7rfbg; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dataapprovalworkflowuseraccesses
    ADD CONSTRAINT fk7log6kkhhxdl8wbqirtw7rfbg FOREIGN KEY (useraccessid) REFERENCES public.useraccess(useraccessid);


--
-- Name: fk7onryyh9j4cl5xif3evbji9oo; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dataelementuseraccesses
    ADD CONSTRAINT fk7onryyh9j4cl5xif3evbji9oo FOREIGN KEY (useraccessid) REFERENCES public.useraccess(useraccessid);


--
-- Name: fk7utgogpv8n5r4yxm41lhd70i0; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.organisationunitattributevalues
    ADD CONSTRAINT fk7utgogpv8n5r4yxm41lhd70i0 FOREIGN KEY (organisationunitid) REFERENCES public.organisationunit(organisationunitid);


--
-- Name: fk804hp0os62rpdtroxhrrio76v; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.validationnotificationtemplate_recipientusergroups
    ADD CONSTRAINT fk804hp0os62rpdtroxhrrio76v FOREIGN KEY (usergroupid) REFERENCES public.usergroup(usergroupid);


--
-- Name: fk8eefwcsoitkehdl4qbpslnejb; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.programattributevalues
    ADD CONSTRAINT fk8eefwcsoitkehdl4qbpslnejb FOREIGN KEY (programid) REFERENCES public.program(programid);


--
-- Name: fk8o4ix9ywdk0gexesm549n4w2e; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dataelementcategoryoptionuseraccesses
    ADD CONSTRAINT fk8o4ix9ywdk0gexesm549n4w2e FOREIGN KEY (useraccessid) REFERENCES public.useraccess(useraccessid);


--
-- Name: fk8uk4v6qlon9hw0wlqsnrqj1wy; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dataelementcategoryusergroupaccesses
    ADD CONSTRAINT fk8uk4v6qlon9hw0wlqsnrqj1wy FOREIGN KEY (usergroupaccessid) REFERENCES public.usergroupaccess(usergroupaccessid);


--
-- Name: fk8vhnmg1g2etu7mbiqjj0f6ajg; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.optionsettranslations
    ADD CONSTRAINT fk8vhnmg1g2etu7mbiqjj0f6ajg FOREIGN KEY (objecttranslationid) REFERENCES public.objecttranslation(objecttranslationid);


--
-- Name: fk90tm9l2djy6bjuimlggl6p2x4; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dataapprovalworkflowuseraccesses
    ADD CONSTRAINT fk90tm9l2djy6bjuimlggl6p2x4 FOREIGN KEY (workflowid) REFERENCES public.dataapprovalworkflow(workflowid);


--
-- Name: fk99kbmh5vouduw7bf7sm6buvbm; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.legendsetusergroupaccesses
    ADD CONSTRAINT fk99kbmh5vouduw7bf7sm6buvbm FOREIGN KEY (maplegendsetid) REFERENCES public.maplegendset(maplegendsetid);


--
-- Name: fk9bekfhcd0225ip2lu83ub6hb8; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.validationrulegroupusergroupaccesses
    ADD CONSTRAINT fk9bekfhcd0225ip2lu83ub6hb8 FOREIGN KEY (usergroupaccessid) REFERENCES public.usergroupaccess(usergroupaccessid);


--
-- Name: fk9f6ich22mw6be835i07khg9ld; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.datasetlegendsets
    ADD CONSTRAINT fk9f6ich22mw6be835i07khg9ld FOREIGN KEY (datasetid) REFERENCES public.dataset(datasetid);


--
-- Name: fk9guu2s1eedfk6du56ouxuvl6m; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.validationrulegroupuseraccesses
    ADD CONSTRAINT fk9guu2s1eedfk6du56ouxuvl6m FOREIGN KEY (validationrulegroupid) REFERENCES public.validationrulegroup(validationrulegroupid);


--
-- Name: fk9h3291piptvo283t9lblgnavo; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.programuseraccesses
    ADD CONSTRAINT fk9h3291piptvo283t9lblgnavo FOREIGN KEY (programid) REFERENCES public.program(programid);


--
-- Name: fk9jqvlhax7y8ea3i2q1qg4m08o; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.programstageattributevalues
    ADD CONSTRAINT fk9jqvlhax7y8ea3i2q1qg4m08o FOREIGN KEY (programstageid) REFERENCES public.programstage(programstageid);


--
-- Name: fk9m9l857b29r9ic86qm04sjlmx; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.userroletranslations
    ADD CONSTRAINT fk9m9l857b29r9ic86qm04sjlmx FOREIGN KEY (objecttranslationid) REFERENCES public.objecttranslation(objecttranslationid);


--
-- Name: fk9tpnab44tsrxexa47qvr6dnq2; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.programattributevalues
    ADD CONSTRAINT fk9tpnab44tsrxexa47qvr6dnq2 FOREIGN KEY (attributevalueid) REFERENCES public.attributevalue(attributevalueid);


--
-- Name: fk9whlsdwfojxbp8yclqolqwm9; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.programnotificationtemplate
    ADD CONSTRAINT fk9whlsdwfojxbp8yclqolqwm9 FOREIGN KEY (programid) REFERENCES public.program(programid);


--
-- Name: fk9y8t03jswqlpw5w6v6en2lgnf; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.datasettranslations
    ADD CONSTRAINT fk9y8t03jswqlpw5w6v6en2lgnf FOREIGN KEY (objecttranslationid) REFERENCES public.objecttranslation(objecttranslationid);


--
-- Name: fk9ylyd0xaehcn0gqr8d2stlr5q; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.eventchartusergroupaccesses
    ADD CONSTRAINT fk9ylyd0xaehcn0gqr8d2stlr5q FOREIGN KEY (eventchartid) REFERENCES public.eventchart(eventchartid);


--
-- Name: fk_attribute_optionsetid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.attribute
    ADD CONSTRAINT fk_attribute_optionsetid FOREIGN KEY (optionsetid) REFERENCES public.optionset(optionsetid);


--
-- Name: fk_attribute_userid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.attribute
    ADD CONSTRAINT fk_attribute_userid FOREIGN KEY (userid) REFERENCES public.userinfo(userinfoid);


--
-- Name: fk_attributevalue_attributeid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.attributevalue
    ADD CONSTRAINT fk_attributevalue_attributeid FOREIGN KEY (attributeid) REFERENCES public.attribute(attributeid);


--
-- Name: fk_attributevalue_trackedentityattributeid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.trackedentityattributevalue
    ADD CONSTRAINT fk_attributevalue_trackedentityattributeid FOREIGN KEY (trackedentityattributeid) REFERENCES public.trackedentityattribute(trackedentityattributeid);


--
-- Name: fk_attributevalue_trackedentityinstanceid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.trackedentityattributevalue
    ADD CONSTRAINT fk_attributevalue_trackedentityinstanceid FOREIGN KEY (trackedentityinstanceid) REFERENCES public.trackedentityinstance(trackedentityinstanceid);


--
-- Name: fk_attributevalueaudit_trackedentityattributeid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.trackedentityattributevalueaudit
    ADD CONSTRAINT fk_attributevalueaudit_trackedentityattributeid FOREIGN KEY (trackedentityattributeid) REFERENCES public.trackedentityattribute(trackedentityattributeid);


--
-- Name: fk_attributevalueaudit_trackedentityinstanceid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.trackedentityattributevalueaudit
    ADD CONSTRAINT fk_attributevalueaudit_trackedentityinstanceid FOREIGN KEY (trackedentityinstanceid) REFERENCES public.trackedentityinstance(trackedentityinstanceid);


--
-- Name: fk_categories_categoryoptions_categoryid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.categories_categoryoptions
    ADD CONSTRAINT fk_categories_categoryoptions_categoryid FOREIGN KEY (categoryid) REFERENCES public.dataelementcategory(categoryid);


--
-- Name: fk_category_categoryoptionid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.categories_categoryoptions
    ADD CONSTRAINT fk_category_categoryoptionid FOREIGN KEY (categoryoptionid) REFERENCES public.dataelementcategoryoption(categoryoptionid);


--
-- Name: fk_categorycombo_categoryid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.categorycombos_categories
    ADD CONSTRAINT fk_categorycombo_categoryid FOREIGN KEY (categoryid) REFERENCES public.dataelementcategory(categoryid);


--
-- Name: fk_categorycombo_categoryoptioncomboid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.categorycombos_optioncombos
    ADD CONSTRAINT fk_categorycombo_categoryoptioncomboid FOREIGN KEY (categoryoptioncomboid) REFERENCES public.categoryoptioncombo(categoryoptioncomboid);


--
-- Name: fk_categorycombo_userid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.categorycombo
    ADD CONSTRAINT fk_categorycombo_userid FOREIGN KEY (userid) REFERENCES public.userinfo(userinfoid);


--
-- Name: fk_categorycombos_categories_categorycomboid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.categorycombos_categories
    ADD CONSTRAINT fk_categorycombos_categories_categorycomboid FOREIGN KEY (categorycomboid) REFERENCES public.categorycombo(categorycomboid);


--
-- Name: fk_categorycombos_optioncombos_categorycomboid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.categorycombos_optioncombos
    ADD CONSTRAINT fk_categorycombos_optioncombos_categorycomboid FOREIGN KEY (categorycomboid) REFERENCES public.categorycombo(categorycomboid);


--
-- Name: fk_categorydimension_category; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.categorydimension
    ADD CONSTRAINT fk_categorydimension_category FOREIGN KEY (categoryid) REFERENCES public.dataelementcategory(categoryid);


--
-- Name: fk_categorydimension_items_categorydimensionid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.categorydimension_items
    ADD CONSTRAINT fk_categorydimension_items_categorydimensionid FOREIGN KEY (categorydimensionid) REFERENCES public.categorydimension(categorydimensionid);


--
-- Name: fk_categorydimension_items_categoryoptionid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.categorydimension_items
    ADD CONSTRAINT fk_categorydimension_items_categoryoptionid FOREIGN KEY (categoryoptionid) REFERENCES public.dataelementcategoryoption(categoryoptionid);


--
-- Name: fk_categoryoption_organisationunits_categoryoptionid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.categoryoption_organisationunits
    ADD CONSTRAINT fk_categoryoption_organisationunits_categoryoptionid FOREIGN KEY (categoryoptionid) REFERENCES public.dataelementcategoryoption(categoryoptionid);


--
-- Name: fk_categoryoption_organisationunits_organisationunitid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.categoryoption_organisationunits
    ADD CONSTRAINT fk_categoryoption_organisationunits_organisationunitid FOREIGN KEY (organisationunitid) REFERENCES public.organisationunit(organisationunitid);


--
-- Name: fk_categoryoptioncombo_categoryoptionid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.categoryoptioncombos_categoryoptions
    ADD CONSTRAINT fk_categoryoptioncombo_categoryoptionid FOREIGN KEY (categoryoptionid) REFERENCES public.dataelementcategoryoption(categoryoptionid);


--
-- Name: fk_categoryoptioncombos_categoryoptions_categoryoptioncomboid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.categoryoptioncombos_categoryoptions
    ADD CONSTRAINT fk_categoryoptioncombos_categoryoptions_categoryoptioncomboid FOREIGN KEY (categoryoptioncomboid) REFERENCES public.categoryoptioncombo(categoryoptioncomboid);


--
-- Name: fk_categoryoptiongroup_userid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.categoryoptiongroup
    ADD CONSTRAINT fk_categoryoptiongroup_userid FOREIGN KEY (userid) REFERENCES public.userinfo(userinfoid);


--
-- Name: fk_categoryoptiongroupmembers_categoryoptiongroupid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.categoryoptiongroupmembers
    ADD CONSTRAINT fk_categoryoptiongroupmembers_categoryoptiongroupid FOREIGN KEY (categoryoptionid) REFERENCES public.dataelementcategoryoption(categoryoptionid);


--
-- Name: fk_categoryoptiongroupmembers_categoryoptionid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.categoryoptiongroupmembers
    ADD CONSTRAINT fk_categoryoptiongroupmembers_categoryoptionid FOREIGN KEY (categoryoptiongroupid) REFERENCES public.categoryoptiongroup(categoryoptiongroupid);


--
-- Name: fk_categoryoptiongroupset_userid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.categoryoptiongroupset
    ADD CONSTRAINT fk_categoryoptiongroupset_userid FOREIGN KEY (userid) REFERENCES public.userinfo(userinfoid);


--
-- Name: fk_categoryoptiongroupsetmembers_categoryoptiongroupid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.categoryoptiongroupsetmembers
    ADD CONSTRAINT fk_categoryoptiongroupsetmembers_categoryoptiongroupid FOREIGN KEY (categoryoptiongroupid) REFERENCES public.categoryoptiongroup(categoryoptiongroupid);


--
-- Name: fk_categoryoptiongroupsetmembers_categoryoptiongroupsetid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.categoryoptiongroupsetmembers
    ADD CONSTRAINT fk_categoryoptiongroupsetmembers_categoryoptiongroupsetid FOREIGN KEY (categoryoptiongroupsetid) REFERENCES public.categoryoptiongroupset(categoryoptiongroupsetid);


--
-- Name: fk_chart_categorydimensions_categorydimensionid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.chart_categorydimensions
    ADD CONSTRAINT fk_chart_categorydimensions_categorydimensionid FOREIGN KEY (categorydimensionid) REFERENCES public.categorydimension(categorydimensionid);


--
-- Name: fk_chart_categorydimensions_chartid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.chart_categorydimensions
    ADD CONSTRAINT fk_chart_categorydimensions_chartid FOREIGN KEY (chartid) REFERENCES public.chart(chartid);


--
-- Name: fk_chart_catoptiongroupsetdimensions_chartid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.chart_categoryoptiongroupsetdimensions
    ADD CONSTRAINT fk_chart_catoptiongroupsetdimensions_chartid FOREIGN KEY (chart) REFERENCES public.chart(chartid);


--
-- Name: fk_chart_colorsetid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.chart
    ADD CONSTRAINT fk_chart_colorsetid FOREIGN KEY (colorsetid) REFERENCES public.colorset(colorsetid);


--
-- Name: fk_chart_datadimensionitems_chartid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.chart_datadimensionitems
    ADD CONSTRAINT fk_chart_datadimensionitems_chartid FOREIGN KEY (chartid) REFERENCES public.chart(chartid);


--
-- Name: fk_chart_datadimensionitems_datadimensionitemid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.chart_datadimensionitems
    ADD CONSTRAINT fk_chart_datadimensionitems_datadimensionitemid FOREIGN KEY (datadimensionitemid) REFERENCES public.datadimensionitem(datadimensionitemid);


--
-- Name: fk_chart_dimensions_catoptiongroupsetdimensionid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.chart_categoryoptiongroupsetdimensions
    ADD CONSTRAINT fk_chart_dimensions_catoptiongroupsetdimensionid FOREIGN KEY (categoryoptiongroupsetdimensionid) REFERENCES public.categoryoptiongroupsetdimension(categoryoptiongroupsetdimensionid);


--
-- Name: fk_chart_dimensions_chartid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.chart_dataelementgroupsetdimensions
    ADD CONSTRAINT fk_chart_dimensions_chartid FOREIGN KEY (chartid) REFERENCES public.chart(chartid);


--
-- Name: fk_chart_dimensions_dataelementgroupsetdimensionid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.chart_dataelementgroupsetdimensions
    ADD CONSTRAINT fk_chart_dimensions_dataelementgroupsetdimensionid FOREIGN KEY (dataelementgroupsetdimensionid) REFERENCES public.dataelementgroupsetdimension(dataelementgroupsetdimensionid);


--
-- Name: fk_chart_dimensions_ogunitgroupsetdimensionid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.chart_orgunitgroupsetdimensions
    ADD CONSTRAINT fk_chart_dimensions_ogunitgroupsetdimensionid FOREIGN KEY (orgunitgroupsetdimensionid) REFERENCES public.orgunitgroupsetdimension(orgunitgroupsetdimensionid);


--
-- Name: fk_chart_itemorgunitgroups_orgunitgroupid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.chart_itemorgunitgroups
    ADD CONSTRAINT fk_chart_itemorgunitgroups_orgunitgroupid FOREIGN KEY (orgunitgroupid) REFERENCES public.orgunitgroup(orgunitgroupid);


--
-- Name: fk_chart_itemorgunitunitgroups_chartid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.chart_itemorgunitgroups
    ADD CONSTRAINT fk_chart_itemorgunitunitgroups_chartid FOREIGN KEY (chartid) REFERENCES public.chart(chartid);


--
-- Name: fk_chart_legendsetid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.chart
    ADD CONSTRAINT fk_chart_legendsetid FOREIGN KEY (legendsetid) REFERENCES public.maplegendset(maplegendsetid);


--
-- Name: fk_chart_organisationunits_chartid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.chart_organisationunits
    ADD CONSTRAINT fk_chart_organisationunits_chartid FOREIGN KEY (chartid) REFERENCES public.chart(chartid);


--
-- Name: fk_chart_organisationunits_organisationunitid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.chart_organisationunits
    ADD CONSTRAINT fk_chart_organisationunits_organisationunitid FOREIGN KEY (organisationunitid) REFERENCES public.organisationunit(organisationunitid);


--
-- Name: fk_chart_orgunitgroupsetdimensions_chartid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.chart_orgunitgroupsetdimensions
    ADD CONSTRAINT fk_chart_orgunitgroupsetdimensions_chartid FOREIGN KEY (chartid) REFERENCES public.chart(chartid);


--
-- Name: fk_chart_orgunitlevels_chartid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.chart_orgunitlevels
    ADD CONSTRAINT fk_chart_orgunitlevels_chartid FOREIGN KEY (chartid) REFERENCES public.chart(chartid);


--
-- Name: fk_chart_periods_chartid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.chart_periods
    ADD CONSTRAINT fk_chart_periods_chartid FOREIGN KEY (chartid) REFERENCES public.chart(chartid);


--
-- Name: fk_chart_periods_periodid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.chart_periods
    ADD CONSTRAINT fk_chart_periods_periodid FOREIGN KEY (periodid) REFERENCES public.period(periodid);


--
-- Name: fk_chart_relativeperiodsid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.chart
    ADD CONSTRAINT fk_chart_relativeperiodsid FOREIGN KEY (relativeperiodsid) REFERENCES public.relativeperiods(relativeperiodsid);


--
-- Name: fk_chart_userid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.chart
    ADD CONSTRAINT fk_chart_userid FOREIGN KEY (userid) REFERENCES public.userinfo(userinfoid);


--
-- Name: fk_colorset_colors_colorid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.colorset_colors
    ADD CONSTRAINT fk_colorset_colors_colorid FOREIGN KEY (colorid) REFERENCES public.color(colorid);


--
-- Name: fk_colorset_colors_colorsetid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.colorset_colors
    ADD CONSTRAINT fk_colorset_colors_colorsetid FOREIGN KEY (colorsetid) REFERENCES public.colorset(colorsetid);


--
-- Name: fk_completedatasetregistration_attributeoptioncomboid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.completedatasetregistration
    ADD CONSTRAINT fk_completedatasetregistration_attributeoptioncomboid FOREIGN KEY (attributeoptioncomboid) REFERENCES public.categoryoptioncombo(categoryoptioncomboid);


--
-- Name: fk_completedatasetregistration_organisationunitid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.completedatasetregistration
    ADD CONSTRAINT fk_completedatasetregistration_organisationunitid FOREIGN KEY (sourceid) REFERENCES public.organisationunit(organisationunitid);


--
-- Name: fk_configuration_corswhitelist; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.configuration_corswhitelist
    ADD CONSTRAINT fk_configuration_corswhitelist FOREIGN KEY (configurationid) REFERENCES public.configuration(configurationid);


--
-- Name: fk_configuration_feedback_recipients; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.configuration
    ADD CONSTRAINT fk_configuration_feedback_recipients FOREIGN KEY (feedbackrecipientsid) REFERENCES public.usergroup(usergroupid);


--
-- Name: fk_configuration_infrastructural_dataelements; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.configuration
    ADD CONSTRAINT fk_configuration_infrastructural_dataelements FOREIGN KEY (infrastructuraldataelementsid) REFERENCES public.dataelementgroup(dataelementgroupid);


--
-- Name: fk_configuration_infrastructural_indicators; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.configuration
    ADD CONSTRAINT fk_configuration_infrastructural_indicators FOREIGN KEY (infrastructuralindicatorsid) REFERENCES public.indicatorgroup(indicatorgroupid);


--
-- Name: fk_configuration_infrastructural_periodtype; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.configuration
    ADD CONSTRAINT fk_configuration_infrastructural_periodtype FOREIGN KEY (infrastructuralperiodtypeid) REFERENCES public.periodtype(periodtypeid);


--
-- Name: fk_configuration_offline_orgunit_level; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.configuration
    ADD CONSTRAINT fk_configuration_offline_orgunit_level FOREIGN KEY (offlineorgunitlevelid) REFERENCES public.orgunitlevel(orgunitlevelid);


--
-- Name: fk_configuration_selfregistrationorgunit; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.configuration
    ADD CONSTRAINT fk_configuration_selfregistrationorgunit FOREIGN KEY (selfregistrationorgunit) REFERENCES public.organisationunit(organisationunitid);


--
-- Name: fk_configuration_selfregistrationrole; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.configuration
    ADD CONSTRAINT fk_configuration_selfregistrationrole FOREIGN KEY (selfregistrationrole) REFERENCES public.userrole(userroleid);


--
-- Name: fk_constant_userid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.constant
    ADD CONSTRAINT fk_constant_userid FOREIGN KEY (userid) REFERENCES public.userinfo(userinfoid);


--
-- Name: fk_dashboard_items_dashboardid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dashboard_items
    ADD CONSTRAINT fk_dashboard_items_dashboardid FOREIGN KEY (dashboardid) REFERENCES public.dashboard(dashboardid);


--
-- Name: fk_dashboard_items_dashboarditemid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dashboard_items
    ADD CONSTRAINT fk_dashboard_items_dashboarditemid FOREIGN KEY (dashboarditemid) REFERENCES public.dashboarditem(dashboarditemid);


--
-- Name: fk_dashboard_userid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dashboard
    ADD CONSTRAINT fk_dashboard_userid FOREIGN KEY (userid) REFERENCES public.userinfo(userinfoid);


--
-- Name: fk_dashboarditem_chartid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dashboarditem
    ADD CONSTRAINT fk_dashboarditem_chartid FOREIGN KEY (chartid) REFERENCES public.chart(chartid);


--
-- Name: fk_dashboarditem_eventchartid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dashboarditem
    ADD CONSTRAINT fk_dashboarditem_eventchartid FOREIGN KEY (eventchartid) REFERENCES public.eventchart(eventchartid);


--
-- Name: fk_dashboarditem_eventreportid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dashboarditem
    ADD CONSTRAINT fk_dashboarditem_eventreportid FOREIGN KEY (eventreport) REFERENCES public.eventreport(eventreportid);


--
-- Name: fk_dashboarditem_mapid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dashboarditem
    ADD CONSTRAINT fk_dashboarditem_mapid FOREIGN KEY (mapid) REFERENCES public.map(mapid);


--
-- Name: fk_dashboarditem_reports_dashboardid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dashboarditem_reports
    ADD CONSTRAINT fk_dashboarditem_reports_dashboardid FOREIGN KEY (dashboarditemid) REFERENCES public.dashboarditem(dashboarditemid);


--
-- Name: fk_dashboarditem_reports_reportid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dashboarditem_reports
    ADD CONSTRAINT fk_dashboarditem_reports_reportid FOREIGN KEY (reportid) REFERENCES public.report(reportid);


--
-- Name: fk_dashboarditem_reporttableid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dashboarditem
    ADD CONSTRAINT fk_dashboarditem_reporttableid FOREIGN KEY (reporttable) REFERENCES public.reporttable(reporttableid);


--
-- Name: fk_dashboarditem_resources_dashboardid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dashboarditem_resources
    ADD CONSTRAINT fk_dashboarditem_resources_dashboardid FOREIGN KEY (dashboarditemid) REFERENCES public.dashboarditem(dashboarditemid);


--
-- Name: fk_dashboarditem_resources_resourceid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dashboarditem_resources
    ADD CONSTRAINT fk_dashboarditem_resources_resourceid FOREIGN KEY (resourceid) REFERENCES public.document(documentid);


--
-- Name: fk_dashboarditem_users_dashboardid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dashboarditem_users
    ADD CONSTRAINT fk_dashboarditem_users_dashboardid FOREIGN KEY (dashboarditemid) REFERENCES public.dashboarditem(dashboarditemid);


--
-- Name: fk_dashboarditem_users_userinfoid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dashboarditem_users
    ADD CONSTRAINT fk_dashboarditem_users_userinfoid FOREIGN KEY (userid) REFERENCES public.userinfo(userinfoid);


--
-- Name: fk_dataapproval_attributeoptioncomboid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dataapproval
    ADD CONSTRAINT fk_dataapproval_attributeoptioncomboid FOREIGN KEY (attributeoptioncomboid) REFERENCES public.categoryoptioncombo(categoryoptioncomboid);


--
-- Name: fk_dataapproval_creator; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dataapproval
    ADD CONSTRAINT fk_dataapproval_creator FOREIGN KEY (creator) REFERENCES public.userinfo(userinfoid);


--
-- Name: fk_dataapproval_creator; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dataapprovalaudit
    ADD CONSTRAINT fk_dataapproval_creator FOREIGN KEY (creator) REFERENCES public.userinfo(userinfoid);


--
-- Name: fk_dataapproval_dataapprovallevel; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dataapproval
    ADD CONSTRAINT fk_dataapproval_dataapprovallevel FOREIGN KEY (dataapprovallevelid) REFERENCES public.dataapprovallevel(dataapprovallevelid);


--
-- Name: fk_dataapproval_organisationunitid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dataapproval
    ADD CONSTRAINT fk_dataapproval_organisationunitid FOREIGN KEY (organisationunitid) REFERENCES public.organisationunit(organisationunitid);


--
-- Name: fk_dataapproval_periodid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dataapproval
    ADD CONSTRAINT fk_dataapproval_periodid FOREIGN KEY (periodid) REFERENCES public.period(periodid);


--
-- Name: fk_dataapproval_workflowid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dataapproval
    ADD CONSTRAINT fk_dataapproval_workflowid FOREIGN KEY (workflowid) REFERENCES public.dataapprovalworkflow(workflowid);


--
-- Name: fk_dataapprovalaudit_attributeoptioncomboid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dataapprovalaudit
    ADD CONSTRAINT fk_dataapprovalaudit_attributeoptioncomboid FOREIGN KEY (attributeoptioncomboid) REFERENCES public.categoryoptioncombo(categoryoptioncomboid);


--
-- Name: fk_dataapprovalaudit_levelid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dataapprovalaudit
    ADD CONSTRAINT fk_dataapprovalaudit_levelid FOREIGN KEY (levelid) REFERENCES public.dataapprovallevel(dataapprovallevelid);


--
-- Name: fk_dataapprovalaudit_organisationunitid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dataapprovalaudit
    ADD CONSTRAINT fk_dataapprovalaudit_organisationunitid FOREIGN KEY (organisationunitid) REFERENCES public.organisationunit(organisationunitid);


--
-- Name: fk_dataapprovalaudit_periodid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dataapprovalaudit
    ADD CONSTRAINT fk_dataapprovalaudit_periodid FOREIGN KEY (periodid) REFERENCES public.period(periodid);


--
-- Name: fk_dataapprovalaudit_workflowid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dataapprovalaudit
    ADD CONSTRAINT fk_dataapprovalaudit_workflowid FOREIGN KEY (workflowid) REFERENCES public.dataapprovalworkflow(workflowid);


--
-- Name: fk_dataapprovallevel_categoryoptiongroupsetid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dataapprovallevel
    ADD CONSTRAINT fk_dataapprovallevel_categoryoptiongroupsetid FOREIGN KEY (categoryoptiongroupsetid) REFERENCES public.categoryoptiongroupset(categoryoptiongroupsetid);


--
-- Name: fk_dataapprovallevel_userid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dataapprovallevel
    ADD CONSTRAINT fk_dataapprovallevel_userid FOREIGN KEY (userid) REFERENCES public.userinfo(userinfoid);


--
-- Name: fk_dataapprovalworkflow_categorycomboid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dataapprovalworkflow
    ADD CONSTRAINT fk_dataapprovalworkflow_categorycomboid FOREIGN KEY (categorycomboid) REFERENCES public.categorycombo(categorycomboid);


--
-- Name: fk_dataapprovalworkflow_periodtypeid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dataapprovalworkflow
    ADD CONSTRAINT fk_dataapprovalworkflow_periodtypeid FOREIGN KEY (periodtypeid) REFERENCES public.periodtype(periodtypeid);


--
-- Name: fk_dataapprovalworkflow_userid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dataapprovalworkflow
    ADD CONSTRAINT fk_dataapprovalworkflow_userid FOREIGN KEY (userid) REFERENCES public.userinfo(userinfoid);


--
-- Name: fk_dataapprovalworkflowlevels_levelid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dataapprovalworkflowlevels
    ADD CONSTRAINT fk_dataapprovalworkflowlevels_levelid FOREIGN KEY (dataapprovallevelid) REFERENCES public.dataapprovallevel(dataapprovallevelid);


--
-- Name: fk_dataapprovalworkflowlevels_workflowid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dataapprovalworkflowlevels
    ADD CONSTRAINT fk_dataapprovalworkflowlevels_workflowid FOREIGN KEY (workflowid) REFERENCES public.dataapprovalworkflow(workflowid);


--
-- Name: fk_datadimensionitem_dataelementid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.datadimensionitem
    ADD CONSTRAINT fk_datadimensionitem_dataelementid FOREIGN KEY (dataelementid) REFERENCES public.dataelement(dataelementid);


--
-- Name: fk_datadimensionitem_dataelementoperand_categoryoptioncomboid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.datadimensionitem
    ADD CONSTRAINT fk_datadimensionitem_dataelementoperand_categoryoptioncomboid FOREIGN KEY (dataelementoperand_categoryoptioncomboid) REFERENCES public.categoryoptioncombo(categoryoptioncomboid);


--
-- Name: fk_datadimensionitem_dataelementoperand_dataelementid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.datadimensionitem
    ADD CONSTRAINT fk_datadimensionitem_dataelementoperand_dataelementid FOREIGN KEY (dataelementoperand_dataelementid) REFERENCES public.dataelement(dataelementid);


--
-- Name: fk_datadimensionitem_datasetid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.datadimensionitem
    ADD CONSTRAINT fk_datadimensionitem_datasetid FOREIGN KEY (datasetid) REFERENCES public.dataset(datasetid);


--
-- Name: fk_datadimensionitem_indicatorid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.datadimensionitem
    ADD CONSTRAINT fk_datadimensionitem_indicatorid FOREIGN KEY (indicatorid) REFERENCES public.indicator(indicatorid);


--
-- Name: fk_datadimensionitem_programattribute_attributeid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.datadimensionitem
    ADD CONSTRAINT fk_datadimensionitem_programattribute_attributeid FOREIGN KEY (programattribute_attributeid) REFERENCES public.trackedentityattribute(trackedentityattributeid);


--
-- Name: fk_datadimensionitem_programattribute_programid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.datadimensionitem
    ADD CONSTRAINT fk_datadimensionitem_programattribute_programid FOREIGN KEY (programattribute_programid) REFERENCES public.program(programid);


--
-- Name: fk_datadimensionitem_programdataelement_dataelementid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.datadimensionitem
    ADD CONSTRAINT fk_datadimensionitem_programdataelement_dataelementid FOREIGN KEY (programdataelement_dataelementid) REFERENCES public.dataelement(dataelementid);


--
-- Name: fk_datadimensionitem_programdataelement_programid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.datadimensionitem
    ADD CONSTRAINT fk_datadimensionitem_programdataelement_programid FOREIGN KEY (programdataelement_programid) REFERENCES public.program(programid);


--
-- Name: fk_datadimensionitem_programindicatorid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.datadimensionitem
    ADD CONSTRAINT fk_datadimensionitem_programindicatorid FOREIGN KEY (programindicatorid) REFERENCES public.programindicator(programindicatorid);


--
-- Name: fk_dataelement_categorycomboid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dataelement
    ADD CONSTRAINT fk_dataelement_categorycomboid FOREIGN KEY (categorycomboid) REFERENCES public.categorycombo(categorycomboid);


--
-- Name: fk_dataelement_commentoptionsetid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dataelement
    ADD CONSTRAINT fk_dataelement_commentoptionsetid FOREIGN KEY (commentoptionsetid) REFERENCES public.optionset(optionsetid);


--
-- Name: fk_dataelement_dataelementid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.smscodes
    ADD CONSTRAINT fk_dataelement_dataelementid FOREIGN KEY (dataelementid) REFERENCES public.dataelement(dataelementid);


--
-- Name: fk_dataelement_legendsetid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dataelementlegendsets
    ADD CONSTRAINT fk_dataelement_legendsetid FOREIGN KEY (legendsetid) REFERENCES public.maplegendset(maplegendsetid);


--
-- Name: fk_dataelement_optionsetid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dataelement
    ADD CONSTRAINT fk_dataelement_optionsetid FOREIGN KEY (optionsetid) REFERENCES public.optionset(optionsetid);


--
-- Name: fk_dataelement_userid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dataelement
    ADD CONSTRAINT fk_dataelement_userid FOREIGN KEY (userid) REFERENCES public.userinfo(userinfoid);


--
-- Name: fk_dataelementaggregationlevels_dataelementid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dataelementaggregationlevels
    ADD CONSTRAINT fk_dataelementaggregationlevels_dataelementid FOREIGN KEY (dataelementid) REFERENCES public.dataelement(dataelementid);


--
-- Name: fk_dataelementcategory_userid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dataelementcategory
    ADD CONSTRAINT fk_dataelementcategory_userid FOREIGN KEY (userid) REFERENCES public.userinfo(userinfoid);


--
-- Name: fk_dataelementcategoryoption_userid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dataelementcategoryoption
    ADD CONSTRAINT fk_dataelementcategoryoption_userid FOREIGN KEY (userid) REFERENCES public.userinfo(userinfoid);


--
-- Name: fk_dataelementgroup_dataelementid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dataelementgroupmembers
    ADD CONSTRAINT fk_dataelementgroup_dataelementid FOREIGN KEY (dataelementid) REFERENCES public.dataelement(dataelementid);


--
-- Name: fk_dataelementgroup_userid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dataelementgroup
    ADD CONSTRAINT fk_dataelementgroup_userid FOREIGN KEY (userid) REFERENCES public.userinfo(userinfoid);


--
-- Name: fk_dataelementgroupmembers_dataelementgroupid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dataelementgroupmembers
    ADD CONSTRAINT fk_dataelementgroupmembers_dataelementgroupid FOREIGN KEY (dataelementgroupid) REFERENCES public.dataelementgroup(dataelementgroupid);


--
-- Name: fk_dataelementgroupset_dataelementgroupid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dataelementgroupsetmembers
    ADD CONSTRAINT fk_dataelementgroupset_dataelementgroupid FOREIGN KEY (dataelementgroupid) REFERENCES public.dataelementgroup(dataelementgroupid);


--
-- Name: fk_dataelementgroupset_userid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dataelementgroupset
    ADD CONSTRAINT fk_dataelementgroupset_userid FOREIGN KEY (userid) REFERENCES public.userinfo(userinfoid);


--
-- Name: fk_dataelementgroupsetmembers_dataelementgroupsetid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dataelementgroupsetmembers
    ADD CONSTRAINT fk_dataelementgroupsetmembers_dataelementgroupsetid FOREIGN KEY (dataelementgroupsetid) REFERENCES public.dataelementgroupset(dataelementgroupsetid);


--
-- Name: fk_dataelementoperand_dataelement; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dataelementoperand
    ADD CONSTRAINT fk_dataelementoperand_dataelement FOREIGN KEY (dataelementid) REFERENCES public.dataelement(dataelementid);


--
-- Name: fk_dataelementoperand_dataelementcategoryoptioncombo; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dataelementoperand
    ADD CONSTRAINT fk_dataelementoperand_dataelementcategoryoptioncombo FOREIGN KEY (categoryoptioncomboid) REFERENCES public.categoryoptioncombo(categoryoptioncomboid);


--
-- Name: fk_datainputperiod_period; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.datainputperiod
    ADD CONSTRAINT fk_datainputperiod_period FOREIGN KEY (periodid) REFERENCES public.period(periodid);


--
-- Name: fk_dataset_categorycomboid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dataset
    ADD CONSTRAINT fk_dataset_categorycomboid FOREIGN KEY (categorycomboid) REFERENCES public.categorycombo(categorycomboid);


--
-- Name: fk_dataset_dataelementoperandid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.datasetoperands
    ADD CONSTRAINT fk_dataset_dataelementoperandid FOREIGN KEY (dataelementoperandid) REFERENCES public.dataelementoperand(dataelementoperandid);


--
-- Name: fk_dataset_dataentryform; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dataset
    ADD CONSTRAINT fk_dataset_dataentryform FOREIGN KEY (dataentryform) REFERENCES public.dataentryform(dataentryformid);


--
-- Name: fk_dataset_datasetid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.smscommands
    ADD CONSTRAINT fk_dataset_datasetid FOREIGN KEY (datasetid) REFERENCES public.dataset(datasetid);


--
-- Name: fk_dataset_indicatorid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.datasetindicators
    ADD CONSTRAINT fk_dataset_indicatorid FOREIGN KEY (indicatorid) REFERENCES public.indicator(indicatorid);


--
-- Name: fk_dataset_legendsetid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.datasetlegendsets
    ADD CONSTRAINT fk_dataset_legendsetid FOREIGN KEY (legendsetid) REFERENCES public.maplegendset(maplegendsetid);


--
-- Name: fk_dataset_notificationrecipients; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dataset
    ADD CONSTRAINT fk_dataset_notificationrecipients FOREIGN KEY (notificationrecipients) REFERENCES public.usergroup(usergroupid);


--
-- Name: fk_dataset_organisationunit; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.datasetsource
    ADD CONSTRAINT fk_dataset_organisationunit FOREIGN KEY (sourceid) REFERENCES public.organisationunit(organisationunitid);


--
-- Name: fk_dataset_periodtypeid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dataset
    ADD CONSTRAINT fk_dataset_periodtypeid FOREIGN KEY (periodtypeid) REFERENCES public.periodtype(periodtypeid);


--
-- Name: fk_dataset_userid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dataset
    ADD CONSTRAINT fk_dataset_userid FOREIGN KEY (userid) REFERENCES public.userinfo(userinfoid);


--
-- Name: fk_dataset_workflowid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dataset
    ADD CONSTRAINT fk_dataset_workflowid FOREIGN KEY (workflowid) REFERENCES public.dataapprovalworkflow(workflowid);


--
-- Name: fk_datasetcompleteregistration_datasetid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.completedatasetregistration
    ADD CONSTRAINT fk_datasetcompleteregistration_datasetid FOREIGN KEY (datasetid) REFERENCES public.dataset(datasetid);


--
-- Name: fk_datasetcompleteregistration_periodid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.completedatasetregistration
    ADD CONSTRAINT fk_datasetcompleteregistration_periodid FOREIGN KEY (periodid) REFERENCES public.period(periodid);


--
-- Name: fk_datasetdatainputperiods_datasetid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.datainputperiod
    ADD CONSTRAINT fk_datasetdatainputperiods_datasetid FOREIGN KEY (datasetid) REFERENCES public.dataset(datasetid);


--
-- Name: fk_datasetelement_categorycomboid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.datasetelement
    ADD CONSTRAINT fk_datasetelement_categorycomboid FOREIGN KEY (categorycomboid) REFERENCES public.categorycombo(categorycomboid);


--
-- Name: fk_datasetindicators_datasetid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.datasetindicators
    ADD CONSTRAINT fk_datasetindicators_datasetid FOREIGN KEY (datasetid) REFERENCES public.dataset(datasetid);


--
-- Name: fk_datasetmembers_dataelementid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.datasetelement
    ADD CONSTRAINT fk_datasetmembers_dataelementid FOREIGN KEY (dataelementid) REFERENCES public.dataelement(dataelementid);


--
-- Name: fk_datasetmembers_datasetid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.datasetelement
    ADD CONSTRAINT fk_datasetmembers_datasetid FOREIGN KEY (datasetid) REFERENCES public.dataset(datasetid);


--
-- Name: fk_datasetnotification_usergroup; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.datasetnotificationtemplate
    ADD CONSTRAINT fk_datasetnotification_usergroup FOREIGN KEY (usergroupid) REFERENCES public.usergroup(usergroupid);


--
-- Name: fk_datasetoperands_datasetid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.datasetoperands
    ADD CONSTRAINT fk_datasetoperands_datasetid FOREIGN KEY (datasetid) REFERENCES public.dataset(datasetid);


--
-- Name: fk_datasets_datasetnotificationtemplateid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.datasetnotification_datasets
    ADD CONSTRAINT fk_datasets_datasetnotificationtemplateid FOREIGN KEY (datasetnotificationtemplateid) REFERENCES public.datasetnotificationtemplate(datasetnotificationtemplateid);


--
-- Name: fk_datasetsource_datasetid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.datasetsource
    ADD CONSTRAINT fk_datasetsource_datasetid FOREIGN KEY (datasetid) REFERENCES public.dataset(datasetid);


--
-- Name: fk_datavalue_attributeoptioncomboid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.datavalue
    ADD CONSTRAINT fk_datavalue_attributeoptioncomboid FOREIGN KEY (attributeoptioncomboid) REFERENCES public.categoryoptioncombo(categoryoptioncomboid);


--
-- Name: fk_datavalue_categoryoptioncomboid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.datavalue
    ADD CONSTRAINT fk_datavalue_categoryoptioncomboid FOREIGN KEY (categoryoptioncomboid) REFERENCES public.categoryoptioncombo(categoryoptioncomboid);


--
-- Name: fk_datavalue_dataelementid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.datavalue
    ADD CONSTRAINT fk_datavalue_dataelementid FOREIGN KEY (dataelementid) REFERENCES public.dataelement(dataelementid);


--
-- Name: fk_datavalue_organisationunitid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.datavalue
    ADD CONSTRAINT fk_datavalue_organisationunitid FOREIGN KEY (sourceid) REFERENCES public.organisationunit(organisationunitid);


--
-- Name: fk_datavalue_periodid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.datavalue
    ADD CONSTRAINT fk_datavalue_periodid FOREIGN KEY (periodid) REFERENCES public.period(periodid);


--
-- Name: fk_datavalueaudit_attributeoptioncomboid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.datavalueaudit
    ADD CONSTRAINT fk_datavalueaudit_attributeoptioncomboid FOREIGN KEY (attributeoptioncomboid) REFERENCES public.categoryoptioncombo(categoryoptioncomboid);


--
-- Name: fk_datavalueaudit_categoryoptioncomboid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.datavalueaudit
    ADD CONSTRAINT fk_datavalueaudit_categoryoptioncomboid FOREIGN KEY (categoryoptioncomboid) REFERENCES public.categoryoptioncombo(categoryoptioncomboid);


--
-- Name: fk_datavalueaudit_dataelementid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.datavalueaudit
    ADD CONSTRAINT fk_datavalueaudit_dataelementid FOREIGN KEY (dataelementid) REFERENCES public.dataelement(dataelementid);


--
-- Name: fk_datavalueaudit_organisationunitid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.datavalueaudit
    ADD CONSTRAINT fk_datavalueaudit_organisationunitid FOREIGN KEY (organisationunitid) REFERENCES public.organisationunit(organisationunitid);


--
-- Name: fk_datavalueaudit_periodid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.datavalueaudit
    ADD CONSTRAINT fk_datavalueaudit_periodid FOREIGN KEY (periodid) REFERENCES public.period(periodid);


--
-- Name: fk_dimension_categoryoptiongroupsetid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.categoryoptiongroupsetdimension
    ADD CONSTRAINT fk_dimension_categoryoptiongroupsetid FOREIGN KEY (categoryoptiongroupsetid) REFERENCES public.categoryoptiongroupset(categoryoptiongroupsetid);


--
-- Name: fk_dimension_dataelementgroupsetid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dataelementgroupsetdimension
    ADD CONSTRAINT fk_dimension_dataelementgroupsetid FOREIGN KEY (dataelementgroupsetid) REFERENCES public.dataelementgroupset(dataelementgroupsetid);


--
-- Name: fk_dimension_items_categoryoptiongroupid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.categoryoptiongroupsetdimension_items
    ADD CONSTRAINT fk_dimension_items_categoryoptiongroupid FOREIGN KEY (categoryoptiongroupid) REFERENCES public.categoryoptiongroup(categoryoptiongroupid);


--
-- Name: fk_dimension_items_categoryoptiongroupsetdimensionid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.categoryoptiongroupsetdimension_items
    ADD CONSTRAINT fk_dimension_items_categoryoptiongroupsetdimensionid FOREIGN KEY (categoryoptiongroupsetdimensionid) REFERENCES public.categoryoptiongroupsetdimension(categoryoptiongroupsetdimensionid);


--
-- Name: fk_dimension_items_dataelementgroupid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dataelementgroupsetdimension_items
    ADD CONSTRAINT fk_dimension_items_dataelementgroupid FOREIGN KEY (dataelementgroupid) REFERENCES public.dataelementgroup(dataelementgroupid);


--
-- Name: fk_dimension_items_dataelementgroupsetdimensionid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dataelementgroupsetdimension_items
    ADD CONSTRAINT fk_dimension_items_dataelementgroupsetdimensionid FOREIGN KEY (dataelementgroupsetdimensionid) REFERENCES public.dataelementgroupsetdimension(dataelementgroupsetdimensionid);


--
-- Name: fk_dimension_items_orgunitgroupid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.orgunitgroupsetdimension_items
    ADD CONSTRAINT fk_dimension_items_orgunitgroupid FOREIGN KEY (orgunitgroupid) REFERENCES public.orgunitgroup(orgunitgroupid);


--
-- Name: fk_dimension_items_orgunitgroupsetdimensionid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.orgunitgroupsetdimension_items
    ADD CONSTRAINT fk_dimension_items_orgunitgroupsetdimensionid FOREIGN KEY (orgunitgroupsetdimensionid) REFERENCES public.orgunitgroupsetdimension(orgunitgroupsetdimensionid);


--
-- Name: fk_dimension_orgunitgroupsetid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.orgunitgroupsetdimension
    ADD CONSTRAINT fk_dimension_orgunitgroupsetid FOREIGN KEY (orgunitgroupsetid) REFERENCES public.orgunitgroupset(orgunitgroupsetid);


--
-- Name: fk_document_fileresourceid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document
    ADD CONSTRAINT fk_document_fileresourceid FOREIGN KEY (fileresource) REFERENCES public.fileresource(fileresourceid);


--
-- Name: fk_document_userid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document
    ADD CONSTRAINT fk_document_userid FOREIGN KEY (userid) REFERENCES public.userinfo(userinfoid);


--
-- Name: fk_entityinstancedatavalue_dataelementid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.trackedentitydatavalue
    ADD CONSTRAINT fk_entityinstancedatavalue_dataelementid FOREIGN KEY (dataelementid) REFERENCES public.dataelement(dataelementid);


--
-- Name: fk_entityinstancedatavalue_programstageinstanceid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.trackedentitydatavalue
    ADD CONSTRAINT fk_entityinstancedatavalue_programstageinstanceid FOREIGN KEY (programstageinstanceid) REFERENCES public.programstageinstance(programstageinstanceid);


--
-- Name: fk_entityinstancedatavalueaudit_dataelementid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.trackedentitydatavalueaudit
    ADD CONSTRAINT fk_entityinstancedatavalueaudit_dataelementid FOREIGN KEY (dataelementid) REFERENCES public.dataelement(dataelementid);


--
-- Name: fk_entityinstancedatavalueaudit_programstageinstanceid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.trackedentitydatavalueaudit
    ADD CONSTRAINT fk_entityinstancedatavalueaudit_programstageinstanceid FOREIGN KEY (programstageinstanceid) REFERENCES public.programstageinstance(programstageinstanceid);


--
-- Name: fk_eventchart_attributedimensions_attributedimensionid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.eventchart_attributedimensions
    ADD CONSTRAINT fk_eventchart_attributedimensions_attributedimensionid FOREIGN KEY (trackedentityattributedimensionid) REFERENCES public.trackedentityattributedimension(trackedentityattributedimensionid);


--
-- Name: fk_eventchart_attributedimensions_eventchartid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.eventchart_attributedimensions
    ADD CONSTRAINT fk_eventchart_attributedimensions_eventchartid FOREIGN KEY (eventchartid) REFERENCES public.eventchart(eventchartid);


--
-- Name: fk_eventchart_attributevaluedimensionid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.eventchart
    ADD CONSTRAINT fk_eventchart_attributevaluedimensionid FOREIGN KEY (attributevaluedimensionid) REFERENCES public.trackedentityattribute(trackedentityattributeid);


--
-- Name: fk_eventchart_categorydimensions_categorydimensionid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.eventchart_categorydimensions
    ADD CONSTRAINT fk_eventchart_categorydimensions_categorydimensionid FOREIGN KEY (categorydimensionid) REFERENCES public.categorydimension(categorydimensionid);


--
-- Name: fk_eventchart_categorydimensions_eventchartid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.eventchart_categorydimensions
    ADD CONSTRAINT fk_eventchart_categorydimensions_eventchartid FOREIGN KEY (eventchartid) REFERENCES public.eventchart(eventchartid);


--
-- Name: fk_eventchart_catoptiongroupsetdimensions_eventchartid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.eventchart_categoryoptiongroupsetdimensions
    ADD CONSTRAINT fk_eventchart_catoptiongroupsetdimensions_eventchartid FOREIGN KEY (eventchartid) REFERENCES public.eventchart(eventchartid);


--
-- Name: fk_eventchart_columns_eventchartid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.eventchart_columns
    ADD CONSTRAINT fk_eventchart_columns_eventchartid FOREIGN KEY (eventchartid) REFERENCES public.eventchart(eventchartid);


--
-- Name: fk_eventchart_dataelementdimensions_dataelementdimensionid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.eventchart_dataelementdimensions
    ADD CONSTRAINT fk_eventchart_dataelementdimensions_dataelementdimensionid FOREIGN KEY (trackedentitydataelementdimensionid) REFERENCES public.trackedentitydataelementdimension(trackedentitydataelementdimensionid);


--
-- Name: fk_eventchart_dataelementdimensions_eventchartid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.eventchart_dataelementdimensions
    ADD CONSTRAINT fk_eventchart_dataelementdimensions_eventchartid FOREIGN KEY (eventchartid) REFERENCES public.eventchart(eventchartid);


--
-- Name: fk_eventchart_dataelementvaluedimensionid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.eventchart
    ADD CONSTRAINT fk_eventchart_dataelementvaluedimensionid FOREIGN KEY (dataelementvaluedimensionid) REFERENCES public.dataelement(dataelementid);


--
-- Name: fk_eventchart_dimensions_catoptiongroupsetdimensionid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.eventchart_categoryoptiongroupsetdimensions
    ADD CONSTRAINT fk_eventchart_dimensions_catoptiongroupsetdimensionid FOREIGN KEY (categoryoptiongroupsetdimensionid) REFERENCES public.categoryoptiongroupsetdimension(categoryoptiongroupsetdimensionid);


--
-- Name: fk_eventchart_dimensions_ogunitgroupsetdimensionid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.eventchart_orgunitgroupsetdimensions
    ADD CONSTRAINT fk_eventchart_dimensions_ogunitgroupsetdimensionid FOREIGN KEY (orgunitgroupsetdimensionid) REFERENCES public.orgunitgroupsetdimension(orgunitgroupsetdimensionid);


--
-- Name: fk_eventchart_filters_eventchartid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.eventchart_filters
    ADD CONSTRAINT fk_eventchart_filters_eventchartid FOREIGN KEY (eventchartid) REFERENCES public.eventchart(eventchartid);


--
-- Name: fk_eventchart_itemorgunitgroups_orgunitgroupid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.eventchart_itemorgunitgroups
    ADD CONSTRAINT fk_eventchart_itemorgunitgroups_orgunitgroupid FOREIGN KEY (orgunitgroupid) REFERENCES public.orgunitgroup(orgunitgroupid);


--
-- Name: fk_eventchart_itemorgunitunitgroups_eventchartid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.eventchart_itemorgunitgroups
    ADD CONSTRAINT fk_eventchart_itemorgunitunitgroups_eventchartid FOREIGN KEY (eventchartid) REFERENCES public.eventchart(eventchartid);


--
-- Name: fk_eventchart_organisationunits_eventchartid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.eventchart_organisationunits
    ADD CONSTRAINT fk_eventchart_organisationunits_eventchartid FOREIGN KEY (eventchartid) REFERENCES public.eventchart(eventchartid);


--
-- Name: fk_eventchart_organisationunits_organisationunitid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.eventchart_organisationunits
    ADD CONSTRAINT fk_eventchart_organisationunits_organisationunitid FOREIGN KEY (organisationunitid) REFERENCES public.organisationunit(organisationunitid);


--
-- Name: fk_eventchart_orgunitgroupsetdimensions_eventchartid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.eventchart_orgunitgroupsetdimensions
    ADD CONSTRAINT fk_eventchart_orgunitgroupsetdimensions_eventchartid FOREIGN KEY (eventchartid) REFERENCES public.eventchart(eventchartid);


--
-- Name: fk_eventchart_orgunitlevels_eventchartid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.eventchart_orgunitlevels
    ADD CONSTRAINT fk_eventchart_orgunitlevels_eventchartid FOREIGN KEY (eventchartid) REFERENCES public.eventchart(eventchartid);


--
-- Name: fk_eventchart_periods_eventchartid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.eventchart_periods
    ADD CONSTRAINT fk_eventchart_periods_eventchartid FOREIGN KEY (eventchartid) REFERENCES public.eventchart(eventchartid);


--
-- Name: fk_eventchart_periods_periodid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.eventchart_periods
    ADD CONSTRAINT fk_eventchart_periods_periodid FOREIGN KEY (periodid) REFERENCES public.period(periodid);


--
-- Name: fk_eventchart_prindicatordimensions_prindicatordimensionid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.eventchart_programindicatordimensions
    ADD CONSTRAINT fk_eventchart_prindicatordimensions_prindicatordimensionid FOREIGN KEY (trackedentityprogramindicatordimensionid) REFERENCES public.trackedentityprogramindicatordimension(trackedentityprogramindicatordimensionid);


--
-- Name: fk_eventchart_programid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.eventchart
    ADD CONSTRAINT fk_eventchart_programid FOREIGN KEY (programid) REFERENCES public.program(programid);


--
-- Name: fk_eventchart_programindicatordimensions_eventchartid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.eventchart_programindicatordimensions
    ADD CONSTRAINT fk_eventchart_programindicatordimensions_eventchartid FOREIGN KEY (eventchartid) REFERENCES public.eventchart(eventchartid);


--
-- Name: fk_eventchart_programstageid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.eventchart
    ADD CONSTRAINT fk_eventchart_programstageid FOREIGN KEY (programstageid) REFERENCES public.programstage(programstageid);


--
-- Name: fk_eventchart_relativeperiodsid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.eventchart
    ADD CONSTRAINT fk_eventchart_relativeperiodsid FOREIGN KEY (relativeperiodsid) REFERENCES public.relativeperiods(relativeperiodsid);


--
-- Name: fk_eventchart_rows_eventchartid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.eventchart_rows
    ADD CONSTRAINT fk_eventchart_rows_eventchartid FOREIGN KEY (eventchartid) REFERENCES public.eventchart(eventchartid);


--
-- Name: fk_eventchart_userid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.eventchart
    ADD CONSTRAINT fk_eventchart_userid FOREIGN KEY (userid) REFERENCES public.userinfo(userinfoid);


--
-- Name: fk_eventreport_attributedimensions_attributedimensionid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.eventreport_attributedimensions
    ADD CONSTRAINT fk_eventreport_attributedimensions_attributedimensionid FOREIGN KEY (trackedentityattributedimensionid) REFERENCES public.trackedentityattributedimension(trackedentityattributedimensionid);


--
-- Name: fk_eventreport_attributedimensions_eventreportid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.eventreport_attributedimensions
    ADD CONSTRAINT fk_eventreport_attributedimensions_eventreportid FOREIGN KEY (eventreportid) REFERENCES public.eventreport(eventreportid);


--
-- Name: fk_eventreport_attributevaluedimensionid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.eventreport
    ADD CONSTRAINT fk_eventreport_attributevaluedimensionid FOREIGN KEY (attributevaluedimensionid) REFERENCES public.trackedentityattribute(trackedentityattributeid);


--
-- Name: fk_eventreport_categorydimensions_categorydimensionid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.eventreport_categorydimensions
    ADD CONSTRAINT fk_eventreport_categorydimensions_categorydimensionid FOREIGN KEY (categorydimensionid) REFERENCES public.categorydimension(categorydimensionid);


--
-- Name: fk_eventreport_categorydimensions_eventreportid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.eventreport_categorydimensions
    ADD CONSTRAINT fk_eventreport_categorydimensions_eventreportid FOREIGN KEY (eventreportid) REFERENCES public.eventreport(eventreportid);


--
-- Name: fk_eventreport_catoptiongroupsetdimensions_eventreportid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.eventreport_categoryoptiongroupsetdimensions
    ADD CONSTRAINT fk_eventreport_catoptiongroupsetdimensions_eventreportid FOREIGN KEY (eventreportid) REFERENCES public.eventreport(eventreportid);


--
-- Name: fk_eventreport_columns_eventreportid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.eventreport_columns
    ADD CONSTRAINT fk_eventreport_columns_eventreportid FOREIGN KEY (eventreportid) REFERENCES public.eventreport(eventreportid);


--
-- Name: fk_eventreport_dataelementdimensions_dataelementdimensionid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.eventreport_dataelementdimensions
    ADD CONSTRAINT fk_eventreport_dataelementdimensions_dataelementdimensionid FOREIGN KEY (trackedentitydataelementdimensionid) REFERENCES public.trackedentitydataelementdimension(trackedentitydataelementdimensionid);


--
-- Name: fk_eventreport_dataelementdimensions_eventreportid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.eventreport_dataelementdimensions
    ADD CONSTRAINT fk_eventreport_dataelementdimensions_eventreportid FOREIGN KEY (eventreportid) REFERENCES public.eventreport(eventreportid);


--
-- Name: fk_eventreport_dataelementvaluedimensionid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.eventreport
    ADD CONSTRAINT fk_eventreport_dataelementvaluedimensionid FOREIGN KEY (dataelementvaluedimensionid) REFERENCES public.dataelement(dataelementid);


--
-- Name: fk_eventreport_dimensions_catoptiongroupsetdimensionid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.eventreport_categoryoptiongroupsetdimensions
    ADD CONSTRAINT fk_eventreport_dimensions_catoptiongroupsetdimensionid FOREIGN KEY (categoryoptiongroupsetdimensionid) REFERENCES public.categoryoptiongroupsetdimension(categoryoptiongroupsetdimensionid);


--
-- Name: fk_eventreport_dimensions_ogunitgroupsetdimensionid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.eventreport_orgunitgroupsetdimensions
    ADD CONSTRAINT fk_eventreport_dimensions_ogunitgroupsetdimensionid FOREIGN KEY (orgunitgroupsetdimensionid) REFERENCES public.orgunitgroupsetdimension(orgunitgroupsetdimensionid);


--
-- Name: fk_eventreport_filters_eventreportid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.eventreport_filters
    ADD CONSTRAINT fk_eventreport_filters_eventreportid FOREIGN KEY (eventreportid) REFERENCES public.eventreport(eventreportid);


--
-- Name: fk_eventreport_itemorgunitgroups_orgunitgroupid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.eventreport_itemorgunitgroups
    ADD CONSTRAINT fk_eventreport_itemorgunitgroups_orgunitgroupid FOREIGN KEY (orgunitgroupid) REFERENCES public.orgunitgroup(orgunitgroupid);


--
-- Name: fk_eventreport_itemorgunitunitgroups_eventreportid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.eventreport_itemorgunitgroups
    ADD CONSTRAINT fk_eventreport_itemorgunitunitgroups_eventreportid FOREIGN KEY (eventreportid) REFERENCES public.eventreport(eventreportid);


--
-- Name: fk_eventreport_organisationunits_eventreportid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.eventreport_organisationunits
    ADD CONSTRAINT fk_eventreport_organisationunits_eventreportid FOREIGN KEY (eventreportid) REFERENCES public.eventreport(eventreportid);


--
-- Name: fk_eventreport_organisationunits_organisationunitid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.eventreport_organisationunits
    ADD CONSTRAINT fk_eventreport_organisationunits_organisationunitid FOREIGN KEY (organisationunitid) REFERENCES public.organisationunit(organisationunitid);


--
-- Name: fk_eventreport_orgunitgroupsetdimensions_eventreporteid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.eventreport_orgunitgroupsetdimensions
    ADD CONSTRAINT fk_eventreport_orgunitgroupsetdimensions_eventreporteid FOREIGN KEY (eventreportid) REFERENCES public.eventreport(eventreportid);


--
-- Name: fk_eventreport_orgunitlevels_eventreportid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.eventreport_orgunitlevels
    ADD CONSTRAINT fk_eventreport_orgunitlevels_eventreportid FOREIGN KEY (eventreportid) REFERENCES public.eventreport(eventreportid);


--
-- Name: fk_eventreport_periods_eventreportid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.eventreport_periods
    ADD CONSTRAINT fk_eventreport_periods_eventreportid FOREIGN KEY (eventreportid) REFERENCES public.eventreport(eventreportid);


--
-- Name: fk_eventreport_periods_periodid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.eventreport_periods
    ADD CONSTRAINT fk_eventreport_periods_periodid FOREIGN KEY (periodid) REFERENCES public.period(periodid);


--
-- Name: fk_eventreport_prindicatordimensions_prindicatordimensionid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.eventreport_programindicatordimensions
    ADD CONSTRAINT fk_eventreport_prindicatordimensions_prindicatordimensionid FOREIGN KEY (trackedentityprogramindicatordimensionid) REFERENCES public.trackedentityprogramindicatordimension(trackedentityprogramindicatordimensionid);


--
-- Name: fk_eventreport_programid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.eventreport
    ADD CONSTRAINT fk_eventreport_programid FOREIGN KEY (programid) REFERENCES public.program(programid);


--
-- Name: fk_eventreport_programindicatordimensions_eventreportid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.eventreport_programindicatordimensions
    ADD CONSTRAINT fk_eventreport_programindicatordimensions_eventreportid FOREIGN KEY (eventreportid) REFERENCES public.eventreport(eventreportid);


--
-- Name: fk_eventreport_programstageid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.eventreport
    ADD CONSTRAINT fk_eventreport_programstageid FOREIGN KEY (programstageid) REFERENCES public.programstage(programstageid);


--
-- Name: fk_eventreport_relativeperiodsid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.eventreport
    ADD CONSTRAINT fk_eventreport_relativeperiodsid FOREIGN KEY (relativeperiodsid) REFERENCES public.relativeperiods(relativeperiodsid);


--
-- Name: fk_eventreport_rows_eventreportid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.eventreport_rows
    ADD CONSTRAINT fk_eventreport_rows_eventreportid FOREIGN KEY (eventreportid) REFERENCES public.eventreport(eventreportid);


--
-- Name: fk_eventreport_userid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.eventreport
    ADD CONSTRAINT fk_eventreport_userid FOREIGN KEY (userid) REFERENCES public.userinfo(userinfoid);


--
-- Name: fk_externalmaplayer_legendsetid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.externalmaplayer
    ADD CONSTRAINT fk_externalmaplayer_legendsetid FOREIGN KEY (legendsetid) REFERENCES public.maplegendset(maplegendsetid);


--
-- Name: fk_externalmaplayer_userid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.externalmaplayer
    ADD CONSTRAINT fk_externalmaplayer_userid FOREIGN KEY (userid) REFERENCES public.userinfo(userinfoid);


--
-- Name: fk_fileresource_externalfileresource; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.externalfileresource
    ADD CONSTRAINT fk_fileresource_externalfileresource FOREIGN KEY (fileresourceid) REFERENCES public.fileresource(fileresourceid);


--
-- Name: fk_fileresource_userid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.fileresource
    ADD CONSTRAINT fk_fileresource_userid FOREIGN KEY (userid) REFERENCES public.userinfo(userinfoid);


--
-- Name: fk_fk_users_catconstraints_dataelementcategoryid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users_catdimensionconstraints
    ADD CONSTRAINT fk_fk_users_catconstraints_dataelementcategoryid FOREIGN KEY (dataelementcategoryid) REFERENCES public.dataelementcategory(categoryid);


--
-- Name: fk_fk_users_cogsconstraints_categoryoptiongroupsetid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users_cogsdimensionconstraints
    ADD CONSTRAINT fk_fk_users_cogsconstraints_categoryoptiongroupsetid FOREIGN KEY (categoryoptiongroupsetid) REFERENCES public.categoryoptiongroupset(categoryoptiongroupsetid);


--
-- Name: fk_incomingsms_userid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.incomingsms
    ADD CONSTRAINT fk_incomingsms_userid FOREIGN KEY (userid) REFERENCES public.userinfo(userinfoid);


--
-- Name: fk_indicator_indicatortypeid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.indicator
    ADD CONSTRAINT fk_indicator_indicatortypeid FOREIGN KEY (indicatortypeid) REFERENCES public.indicatortype(indicatortypeid);


--
-- Name: fk_indicator_legendsetid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.indicatorlegendsets
    ADD CONSTRAINT fk_indicator_legendsetid FOREIGN KEY (legendsetid) REFERENCES public.maplegendset(maplegendsetid);


--
-- Name: fk_indicator_userid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.indicator
    ADD CONSTRAINT fk_indicator_userid FOREIGN KEY (userid) REFERENCES public.userinfo(userinfoid);


--
-- Name: fk_indicatorgroup_indicatorid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.indicatorgroupmembers
    ADD CONSTRAINT fk_indicatorgroup_indicatorid FOREIGN KEY (indicatorid) REFERENCES public.indicator(indicatorid);


--
-- Name: fk_indicatorgroup_userid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.indicatorgroup
    ADD CONSTRAINT fk_indicatorgroup_userid FOREIGN KEY (userid) REFERENCES public.userinfo(userinfoid);


--
-- Name: fk_indicatorgroupmembers_indicatorgroupid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.indicatorgroupmembers
    ADD CONSTRAINT fk_indicatorgroupmembers_indicatorgroupid FOREIGN KEY (indicatorgroupid) REFERENCES public.indicatorgroup(indicatorgroupid);


--
-- Name: fk_indicatorgroupset_indicatorgroupid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.indicatorgroupsetmembers
    ADD CONSTRAINT fk_indicatorgroupset_indicatorgroupid FOREIGN KEY (indicatorgroupid) REFERENCES public.indicatorgroup(indicatorgroupid);


--
-- Name: fk_indicatorgroupset_userid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.indicatorgroupset
    ADD CONSTRAINT fk_indicatorgroupset_userid FOREIGN KEY (userid) REFERENCES public.userinfo(userinfoid);


--
-- Name: fk_indicatorgroupsetmembers_indicatorgroupsetid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.indicatorgroupsetmembers
    ADD CONSTRAINT fk_indicatorgroupsetmembers_indicatorgroupsetid FOREIGN KEY (indicatorgroupsetid) REFERENCES public.indicatorgroupset(indicatorgroupsetid);


--
-- Name: fk_intepretation_likedby_userid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.intepretation_likedby
    ADD CONSTRAINT fk_intepretation_likedby_userid FOREIGN KEY (userid) REFERENCES public.userinfo(userinfoid);


--
-- Name: fk_interpretation_chartid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.interpretation
    ADD CONSTRAINT fk_interpretation_chartid FOREIGN KEY (chartid) REFERENCES public.chart(chartid);


--
-- Name: fk_interpretation_comments_interpretationcommentid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.interpretation_comments
    ADD CONSTRAINT fk_interpretation_comments_interpretationcommentid FOREIGN KEY (interpretationcommentid) REFERENCES public.interpretationcomment(interpretationcommentid);


--
-- Name: fk_interpretation_comments_interpretationid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.interpretation_comments
    ADD CONSTRAINT fk_interpretation_comments_interpretationid FOREIGN KEY (interpretationid) REFERENCES public.interpretation(interpretationid);


--
-- Name: fk_interpretation_datasetid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.interpretation
    ADD CONSTRAINT fk_interpretation_datasetid FOREIGN KEY (datasetid) REFERENCES public.dataset(datasetid);


--
-- Name: fk_interpretation_eventchartid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.interpretation
    ADD CONSTRAINT fk_interpretation_eventchartid FOREIGN KEY (eventchartid) REFERENCES public.eventchart(eventchartid);


--
-- Name: fk_interpretation_eventreportid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.interpretation
    ADD CONSTRAINT fk_interpretation_eventreportid FOREIGN KEY (eventreportid) REFERENCES public.eventreport(eventreportid);


--
-- Name: fk_interpretation_likedby_interpretationid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.intepretation_likedby
    ADD CONSTRAINT fk_interpretation_likedby_interpretationid FOREIGN KEY (interpretationid) REFERENCES public.interpretation(interpretationid);


--
-- Name: fk_interpretation_mapid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.interpretation
    ADD CONSTRAINT fk_interpretation_mapid FOREIGN KEY (mapid) REFERENCES public.map(mapid);


--
-- Name: fk_interpretation_organisationunitid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.interpretation
    ADD CONSTRAINT fk_interpretation_organisationunitid FOREIGN KEY (organisationunitid) REFERENCES public.organisationunit(organisationunitid);


--
-- Name: fk_interpretation_periodid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.interpretation
    ADD CONSTRAINT fk_interpretation_periodid FOREIGN KEY (periodid) REFERENCES public.period(periodid);


--
-- Name: fk_interpretation_reporttableid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.interpretation
    ADD CONSTRAINT fk_interpretation_reporttableid FOREIGN KEY (reporttableid) REFERENCES public.reporttable(reporttableid);


--
-- Name: fk_interpretation_userid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.interpretation
    ADD CONSTRAINT fk_interpretation_userid FOREIGN KEY (userid) REFERENCES public.userinfo(userinfoid);


--
-- Name: fk_interpretationcomment_userid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.interpretationcomment
    ADD CONSTRAINT fk_interpretationcomment_userid FOREIGN KEY (userid) REFERENCES public.userinfo(userinfoid);


--
-- Name: fk_lastupdateby_userid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.attribute
    ADD CONSTRAINT fk_lastupdateby_userid FOREIGN KEY (lastupdatedby) REFERENCES public.userinfo(userinfoid);


--
-- Name: fk_lastupdateby_userid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.categorycombo
    ADD CONSTRAINT fk_lastupdateby_userid FOREIGN KEY (lastupdatedby) REFERENCES public.userinfo(userinfoid);


--
-- Name: fk_lastupdateby_userid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.categoryoptioncombo
    ADD CONSTRAINT fk_lastupdateby_userid FOREIGN KEY (lastupdatedby) REFERENCES public.userinfo(userinfoid);


--
-- Name: fk_lastupdateby_userid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.categoryoptiongroup
    ADD CONSTRAINT fk_lastupdateby_userid FOREIGN KEY (lastupdatedby) REFERENCES public.userinfo(userinfoid);


--
-- Name: fk_lastupdateby_userid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.categoryoptiongroupset
    ADD CONSTRAINT fk_lastupdateby_userid FOREIGN KEY (lastupdatedby) REFERENCES public.userinfo(userinfoid);


--
-- Name: fk_lastupdateby_userid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.chart
    ADD CONSTRAINT fk_lastupdateby_userid FOREIGN KEY (lastupdatedby) REFERENCES public.userinfo(userinfoid);


--
-- Name: fk_lastupdateby_userid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.color
    ADD CONSTRAINT fk_lastupdateby_userid FOREIGN KEY (lastupdatedby) REFERENCES public.userinfo(userinfoid);


--
-- Name: fk_lastupdateby_userid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.colorset
    ADD CONSTRAINT fk_lastupdateby_userid FOREIGN KEY (lastupdatedby) REFERENCES public.userinfo(userinfoid);


--
-- Name: fk_lastupdateby_userid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.constant
    ADD CONSTRAINT fk_lastupdateby_userid FOREIGN KEY (lastupdatedby) REFERENCES public.userinfo(userinfoid);


--
-- Name: fk_lastupdateby_userid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dashboard
    ADD CONSTRAINT fk_lastupdateby_userid FOREIGN KEY (lastupdatedby) REFERENCES public.userinfo(userinfoid);


--
-- Name: fk_lastupdateby_userid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dashboarditem
    ADD CONSTRAINT fk_lastupdateby_userid FOREIGN KEY (lastupdatedby) REFERENCES public.userinfo(userinfoid);


--
-- Name: fk_lastupdateby_userid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dataapprovallevel
    ADD CONSTRAINT fk_lastupdateby_userid FOREIGN KEY (lastupdatedby) REFERENCES public.userinfo(userinfoid);


--
-- Name: fk_lastupdateby_userid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dataapprovalworkflow
    ADD CONSTRAINT fk_lastupdateby_userid FOREIGN KEY (lastupdatedby) REFERENCES public.userinfo(userinfoid);


--
-- Name: fk_lastupdateby_userid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dataelement
    ADD CONSTRAINT fk_lastupdateby_userid FOREIGN KEY (lastupdatedby) REFERENCES public.userinfo(userinfoid);


--
-- Name: fk_lastupdateby_userid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dataelementcategory
    ADD CONSTRAINT fk_lastupdateby_userid FOREIGN KEY (lastupdatedby) REFERENCES public.userinfo(userinfoid);


--
-- Name: fk_lastupdateby_userid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dataelementcategoryoption
    ADD CONSTRAINT fk_lastupdateby_userid FOREIGN KEY (lastupdatedby) REFERENCES public.userinfo(userinfoid);


--
-- Name: fk_lastupdateby_userid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dataelementgroup
    ADD CONSTRAINT fk_lastupdateby_userid FOREIGN KEY (lastupdatedby) REFERENCES public.userinfo(userinfoid);


--
-- Name: fk_lastupdateby_userid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dataelementgroupset
    ADD CONSTRAINT fk_lastupdateby_userid FOREIGN KEY (lastupdatedby) REFERENCES public.userinfo(userinfoid);


--
-- Name: fk_lastupdateby_userid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dataentryform
    ADD CONSTRAINT fk_lastupdateby_userid FOREIGN KEY (lastupdatedby) REFERENCES public.userinfo(userinfoid);


--
-- Name: fk_lastupdateby_userid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dataset
    ADD CONSTRAINT fk_lastupdateby_userid FOREIGN KEY (lastupdatedby) REFERENCES public.userinfo(userinfoid);


--
-- Name: fk_lastupdateby_userid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.datasetnotificationtemplate
    ADD CONSTRAINT fk_lastupdateby_userid FOREIGN KEY (lastupdatedby) REFERENCES public.userinfo(userinfoid);


--
-- Name: fk_lastupdateby_userid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.datastatistics
    ADD CONSTRAINT fk_lastupdateby_userid FOREIGN KEY (lastupdatedby) REFERENCES public.userinfo(userinfoid);


--
-- Name: fk_lastupdateby_userid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document
    ADD CONSTRAINT fk_lastupdateby_userid FOREIGN KEY (lastupdatedby) REFERENCES public.userinfo(userinfoid);


--
-- Name: fk_lastupdateby_userid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.eventchart
    ADD CONSTRAINT fk_lastupdateby_userid FOREIGN KEY (lastupdatedby) REFERENCES public.userinfo(userinfoid);


--
-- Name: fk_lastupdateby_userid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.eventreport
    ADD CONSTRAINT fk_lastupdateby_userid FOREIGN KEY (lastupdatedby) REFERENCES public.userinfo(userinfoid);


--
-- Name: fk_lastupdateby_userid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.externalfileresource
    ADD CONSTRAINT fk_lastupdateby_userid FOREIGN KEY (lastupdatedby) REFERENCES public.userinfo(userinfoid);


--
-- Name: fk_lastupdateby_userid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.externalmaplayer
    ADD CONSTRAINT fk_lastupdateby_userid FOREIGN KEY (lastupdatedby) REFERENCES public.userinfo(userinfoid);


--
-- Name: fk_lastupdateby_userid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.fileresource
    ADD CONSTRAINT fk_lastupdateby_userid FOREIGN KEY (lastupdatedby) REFERENCES public.userinfo(userinfoid);


--
-- Name: fk_lastupdateby_userid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.i18nlocale
    ADD CONSTRAINT fk_lastupdateby_userid FOREIGN KEY (lastupdatedby) REFERENCES public.userinfo(userinfoid);


--
-- Name: fk_lastupdateby_userid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.indicator
    ADD CONSTRAINT fk_lastupdateby_userid FOREIGN KEY (lastupdatedby) REFERENCES public.userinfo(userinfoid);


--
-- Name: fk_lastupdateby_userid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.indicatorgroup
    ADD CONSTRAINT fk_lastupdateby_userid FOREIGN KEY (lastupdatedby) REFERENCES public.userinfo(userinfoid);


--
-- Name: fk_lastupdateby_userid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.indicatorgroupset
    ADD CONSTRAINT fk_lastupdateby_userid FOREIGN KEY (lastupdatedby) REFERENCES public.userinfo(userinfoid);


--
-- Name: fk_lastupdateby_userid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.indicatortype
    ADD CONSTRAINT fk_lastupdateby_userid FOREIGN KEY (lastupdatedby) REFERENCES public.userinfo(userinfoid);


--
-- Name: fk_lastupdateby_userid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.jobconfiguration
    ADD CONSTRAINT fk_lastupdateby_userid FOREIGN KEY (lastupdatedby) REFERENCES public.userinfo(userinfoid);


--
-- Name: fk_lastupdateby_userid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.keyjsonvalue
    ADD CONSTRAINT fk_lastupdateby_userid FOREIGN KEY (lastupdatedby) REFERENCES public.userinfo(userinfoid);


--
-- Name: fk_lastupdateby_userid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.map
    ADD CONSTRAINT fk_lastupdateby_userid FOREIGN KEY (lastupdatedby) REFERENCES public.userinfo(userinfoid);


--
-- Name: fk_lastupdateby_userid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.maplegend
    ADD CONSTRAINT fk_lastupdateby_userid FOREIGN KEY (lastupdatedby) REFERENCES public.userinfo(userinfoid);


--
-- Name: fk_lastupdateby_userid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.maplegendset
    ADD CONSTRAINT fk_lastupdateby_userid FOREIGN KEY (lastupdatedby) REFERENCES public.userinfo(userinfoid);


--
-- Name: fk_lastupdateby_userid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.mapview
    ADD CONSTRAINT fk_lastupdateby_userid FOREIGN KEY (lastupdatedby) REFERENCES public.userinfo(userinfoid);


--
-- Name: fk_lastupdateby_userid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.metadataversion
    ADD CONSTRAINT fk_lastupdateby_userid FOREIGN KEY (lastupdatedby) REFERENCES public.userinfo(userinfoid);


--
-- Name: fk_lastupdateby_userid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.oauth2client
    ADD CONSTRAINT fk_lastupdateby_userid FOREIGN KEY (lastupdatedby) REFERENCES public.userinfo(userinfoid);


--
-- Name: fk_lastupdateby_userid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.optiongroup
    ADD CONSTRAINT fk_lastupdateby_userid FOREIGN KEY (lastupdatedby) REFERENCES public.userinfo(userinfoid);


--
-- Name: fk_lastupdateby_userid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.optiongroupset
    ADD CONSTRAINT fk_lastupdateby_userid FOREIGN KEY (lastupdatedby) REFERENCES public.userinfo(userinfoid);


--
-- Name: fk_lastupdateby_userid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.optionset
    ADD CONSTRAINT fk_lastupdateby_userid FOREIGN KEY (lastupdatedby) REFERENCES public.userinfo(userinfoid);


--
-- Name: fk_lastupdateby_userid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.organisationunit
    ADD CONSTRAINT fk_lastupdateby_userid FOREIGN KEY (lastupdatedby) REFERENCES public.userinfo(userinfoid);


--
-- Name: fk_lastupdateby_userid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.orgunitgroup
    ADD CONSTRAINT fk_lastupdateby_userid FOREIGN KEY (lastupdatedby) REFERENCES public.userinfo(userinfoid);


--
-- Name: fk_lastupdateby_userid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.orgunitgroupset
    ADD CONSTRAINT fk_lastupdateby_userid FOREIGN KEY (lastupdatedby) REFERENCES public.userinfo(userinfoid);


--
-- Name: fk_lastupdateby_userid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.orgunitlevel
    ADD CONSTRAINT fk_lastupdateby_userid FOREIGN KEY (lastupdatedby) REFERENCES public.userinfo(userinfoid);


--
-- Name: fk_lastupdateby_userid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.predictor
    ADD CONSTRAINT fk_lastupdateby_userid FOREIGN KEY (lastupdatedby) REFERENCES public.userinfo(userinfoid);


--
-- Name: fk_lastupdateby_userid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.program
    ADD CONSTRAINT fk_lastupdateby_userid FOREIGN KEY (lastupdatedby) REFERENCES public.userinfo(userinfoid);


--
-- Name: fk_lastupdateby_userid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.program_attribute_group
    ADD CONSTRAINT fk_lastupdateby_userid FOREIGN KEY (lastupdatedby) REFERENCES public.userinfo(userinfoid);


--
-- Name: fk_lastupdateby_userid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.program_attributes
    ADD CONSTRAINT fk_lastupdateby_userid FOREIGN KEY (lastupdatedby) REFERENCES public.userinfo(userinfoid);


--
-- Name: fk_lastupdateby_userid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.programindicator
    ADD CONSTRAINT fk_lastupdateby_userid FOREIGN KEY (lastupdatedby) REFERENCES public.userinfo(userinfoid);


--
-- Name: fk_lastupdateby_userid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.programindicatorgroup
    ADD CONSTRAINT fk_lastupdateby_userid FOREIGN KEY (lastupdatedby) REFERENCES public.userinfo(userinfoid);


--
-- Name: fk_lastupdateby_userid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.programmessage
    ADD CONSTRAINT fk_lastupdateby_userid FOREIGN KEY (lastupdatedby) REFERENCES public.userinfo(userinfoid);


--
-- Name: fk_lastupdateby_userid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.programnotificationtemplate
    ADD CONSTRAINT fk_lastupdateby_userid FOREIGN KEY (lastupdatedby) REFERENCES public.userinfo(userinfoid);


--
-- Name: fk_lastupdateby_userid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.programrule
    ADD CONSTRAINT fk_lastupdateby_userid FOREIGN KEY (lastupdatedby) REFERENCES public.userinfo(userinfoid);


--
-- Name: fk_lastupdateby_userid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.programruleaction
    ADD CONSTRAINT fk_lastupdateby_userid FOREIGN KEY (lastupdatedby) REFERENCES public.userinfo(userinfoid);


--
-- Name: fk_lastupdateby_userid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.programrulevariable
    ADD CONSTRAINT fk_lastupdateby_userid FOREIGN KEY (lastupdatedby) REFERENCES public.userinfo(userinfoid);


--
-- Name: fk_lastupdateby_userid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.programsection
    ADD CONSTRAINT fk_lastupdateby_userid FOREIGN KEY (lastupdatedby) REFERENCES public.userinfo(userinfoid);


--
-- Name: fk_lastupdateby_userid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.programstage
    ADD CONSTRAINT fk_lastupdateby_userid FOREIGN KEY (lastupdatedby) REFERENCES public.userinfo(userinfoid);


--
-- Name: fk_lastupdateby_userid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.programstagedataelement
    ADD CONSTRAINT fk_lastupdateby_userid FOREIGN KEY (lastupdatedby) REFERENCES public.userinfo(userinfoid);


--
-- Name: fk_lastupdateby_userid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.programstagesection
    ADD CONSTRAINT fk_lastupdateby_userid FOREIGN KEY (lastupdatedby) REFERENCES public.userinfo(userinfoid);


--
-- Name: fk_lastupdateby_userid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pushanalysis
    ADD CONSTRAINT fk_lastupdateby_userid FOREIGN KEY (lastupdatedby) REFERENCES public.userinfo(userinfoid);


--
-- Name: fk_lastupdateby_userid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.relationshiptype
    ADD CONSTRAINT fk_lastupdateby_userid FOREIGN KEY (lastupdatedby) REFERENCES public.userinfo(userinfoid);


--
-- Name: fk_lastupdateby_userid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.report
    ADD CONSTRAINT fk_lastupdateby_userid FOREIGN KEY (lastupdatedby) REFERENCES public.userinfo(userinfoid);


--
-- Name: fk_lastupdateby_userid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.reporttable
    ADD CONSTRAINT fk_lastupdateby_userid FOREIGN KEY (lastupdatedby) REFERENCES public.userinfo(userinfoid);


--
-- Name: fk_lastupdateby_userid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.section
    ADD CONSTRAINT fk_lastupdateby_userid FOREIGN KEY (lastupdatedby) REFERENCES public.userinfo(userinfoid);


--
-- Name: fk_lastupdateby_userid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sqlview
    ADD CONSTRAINT fk_lastupdateby_userid FOREIGN KEY (lastupdatedby) REFERENCES public.userinfo(userinfoid);


--
-- Name: fk_lastupdateby_userid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tablehook
    ADD CONSTRAINT fk_lastupdateby_userid FOREIGN KEY (lastupdatedby) REFERENCES public.userinfo(userinfoid);


--
-- Name: fk_lastupdateby_userid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.trackedentityattribute
    ADD CONSTRAINT fk_lastupdateby_userid FOREIGN KEY (lastupdatedby) REFERENCES public.userinfo(userinfoid);


--
-- Name: fk_lastupdateby_userid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.trackedentityinstance
    ADD CONSTRAINT fk_lastupdateby_userid FOREIGN KEY (lastupdatedby) REFERENCES public.userinfo(userinfoid);


--
-- Name: fk_lastupdateby_userid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.trackedentityinstancefilter
    ADD CONSTRAINT fk_lastupdateby_userid FOREIGN KEY (lastupdatedby) REFERENCES public.userinfo(userinfoid);


--
-- Name: fk_lastupdateby_userid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.trackedentitytype
    ADD CONSTRAINT fk_lastupdateby_userid FOREIGN KEY (lastupdatedby) REFERENCES public.userinfo(userinfoid);


--
-- Name: fk_lastupdateby_userid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.trackedentitytypeattribute
    ADD CONSTRAINT fk_lastupdateby_userid FOREIGN KEY (lastupdatedby) REFERENCES public.userinfo(userinfoid);


--
-- Name: fk_lastupdateby_userid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.usergroup
    ADD CONSTRAINT fk_lastupdateby_userid FOREIGN KEY (lastupdatedby) REFERENCES public.userinfo(userinfoid);


--
-- Name: fk_lastupdateby_userid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.userkeyjsonvalue
    ADD CONSTRAINT fk_lastupdateby_userid FOREIGN KEY (lastupdatedby) REFERENCES public.userinfo(userinfoid);


--
-- Name: fk_lastupdateby_userid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.userrole
    ADD CONSTRAINT fk_lastupdateby_userid FOREIGN KEY (lastupdatedby) REFERENCES public.userinfo(userinfoid);


--
-- Name: fk_lastupdateby_userid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT fk_lastupdateby_userid FOREIGN KEY (lastupdatedby) REFERENCES public.userinfo(userinfoid);


--
-- Name: fk_lastupdateby_userid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.validationcriteria
    ADD CONSTRAINT fk_lastupdateby_userid FOREIGN KEY (lastupdatedby) REFERENCES public.userinfo(userinfoid);


--
-- Name: fk_lastupdateby_userid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.validationnotificationtemplate
    ADD CONSTRAINT fk_lastupdateby_userid FOREIGN KEY (lastupdatedby) REFERENCES public.userinfo(userinfoid);


--
-- Name: fk_lastupdateby_userid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.validationrule
    ADD CONSTRAINT fk_lastupdateby_userid FOREIGN KEY (lastupdatedby) REFERENCES public.userinfo(userinfoid);


--
-- Name: fk_lastupdateby_userid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.validationrulegroup
    ADD CONSTRAINT fk_lastupdateby_userid FOREIGN KEY (lastupdatedby) REFERENCES public.userinfo(userinfoid);


--
-- Name: fk_legendset_userid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.maplegendset
    ADD CONSTRAINT fk_legendset_userid FOREIGN KEY (userid) REFERENCES public.userinfo(userinfoid);


--
-- Name: fk_lockexception_datasetid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.lockexception
    ADD CONSTRAINT fk_lockexception_datasetid FOREIGN KEY (datasetid) REFERENCES public.dataset(datasetid);


--
-- Name: fk_lockexception_organisationunitid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.lockexception
    ADD CONSTRAINT fk_lockexception_organisationunitid FOREIGN KEY (organisationunitid) REFERENCES public.organisationunit(organisationunitid);


--
-- Name: fk_lockexception_periodid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.lockexception
    ADD CONSTRAINT fk_lockexception_periodid FOREIGN KEY (periodid) REFERENCES public.period(periodid);


--
-- Name: fk_maplegend_maplegendsetid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.maplegend
    ADD CONSTRAINT fk_maplegend_maplegendsetid FOREIGN KEY (maplegendsetid) REFERENCES public.maplegendset(maplegendsetid);


--
-- Name: fk_mapmapview_mapid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.mapmapviews
    ADD CONSTRAINT fk_mapmapview_mapid FOREIGN KEY (mapid) REFERENCES public.map(mapid);


--
-- Name: fk_mapmapview_mapviewid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.mapmapviews
    ADD CONSTRAINT fk_mapmapview_mapviewid FOREIGN KEY (mapviewid) REFERENCES public.mapview(mapviewid);


--
-- Name: fk_mapview_attributedimensions_attributedimensionid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.mapview_attributedimensions
    ADD CONSTRAINT fk_mapview_attributedimensions_attributedimensionid FOREIGN KEY (trackedentityattributedimensionid) REFERENCES public.trackedentityattributedimension(trackedentityattributedimensionid);


--
-- Name: fk_mapview_attributedimensions_mapviewid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.mapview_attributedimensions
    ADD CONSTRAINT fk_mapview_attributedimensions_mapviewid FOREIGN KEY (mapviewid) REFERENCES public.mapview(mapviewid);


--
-- Name: fk_mapview_columns_mapviewid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.mapview_columns
    ADD CONSTRAINT fk_mapview_columns_mapviewid FOREIGN KEY (mapviewid) REFERENCES public.mapview(mapviewid);


--
-- Name: fk_mapview_datadimensionitems_datadimensionitemid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.mapview_datadimensionitems
    ADD CONSTRAINT fk_mapview_datadimensionitems_datadimensionitemid FOREIGN KEY (datadimensionitemid) REFERENCES public.datadimensionitem(datadimensionitemid);


--
-- Name: fk_mapview_datadimensionitems_mapviewid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.mapview_datadimensionitems
    ADD CONSTRAINT fk_mapview_datadimensionitems_mapviewid FOREIGN KEY (mapviewid) REFERENCES public.mapview(mapviewid);


--
-- Name: fk_mapview_dataelementdimensions_dataelementdimensionid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.mapview_dataelementdimensions
    ADD CONSTRAINT fk_mapview_dataelementdimensions_dataelementdimensionid FOREIGN KEY (trackedentitydataelementdimensionid) REFERENCES public.trackedentitydataelementdimension(trackedentitydataelementdimensionid);


--
-- Name: fk_mapview_dataelementdimensions_mapviewid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.mapview_dataelementdimensions
    ADD CONSTRAINT fk_mapview_dataelementdimensions_mapviewid FOREIGN KEY (mapviewid) REFERENCES public.mapview(mapviewid);


--
-- Name: fk_mapview_itemorgunitgroups_orgunitgroupid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.mapview_itemorgunitgroups
    ADD CONSTRAINT fk_mapview_itemorgunitgroups_orgunitgroupid FOREIGN KEY (orgunitgroupid) REFERENCES public.orgunitgroup(orgunitgroupid);


--
-- Name: fk_mapview_itemorgunitunitgroups_mapviewid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.mapview_itemorgunitgroups
    ADD CONSTRAINT fk_mapview_itemorgunitunitgroups_mapviewid FOREIGN KEY (mapviewid) REFERENCES public.mapview(mapviewid);


--
-- Name: fk_mapview_maplegendsetid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.mapview
    ADD CONSTRAINT fk_mapview_maplegendsetid FOREIGN KEY (legendsetid) REFERENCES public.maplegendset(maplegendsetid);


--
-- Name: fk_mapview_organisationunits_mapviewid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.mapview_organisationunits
    ADD CONSTRAINT fk_mapview_organisationunits_mapviewid FOREIGN KEY (mapviewid) REFERENCES public.mapview(mapviewid);


--
-- Name: fk_mapview_organisationunits_organisationunitid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.mapview_organisationunits
    ADD CONSTRAINT fk_mapview_organisationunits_organisationunitid FOREIGN KEY (organisationunitid) REFERENCES public.organisationunit(organisationunitid);


--
-- Name: fk_mapview_orgunitgroupsetid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.mapview
    ADD CONSTRAINT fk_mapview_orgunitgroupsetid FOREIGN KEY (orgunitgroupsetid) REFERENCES public.orgunitgroupset(orgunitgroupsetid);


--
-- Name: fk_mapview_orgunitlevels_mapviewid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.mapview_orgunitlevels
    ADD CONSTRAINT fk_mapview_orgunitlevels_mapviewid FOREIGN KEY (mapviewid) REFERENCES public.mapview(mapviewid);


--
-- Name: fk_mapview_periods_mapviewid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.mapview_periods
    ADD CONSTRAINT fk_mapview_periods_mapviewid FOREIGN KEY (mapviewid) REFERENCES public.mapview(mapviewid);


--
-- Name: fk_mapview_periods_periodid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.mapview_periods
    ADD CONSTRAINT fk_mapview_periods_periodid FOREIGN KEY (periodid) REFERENCES public.period(periodid);


--
-- Name: fk_mapview_programid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.mapview
    ADD CONSTRAINT fk_mapview_programid FOREIGN KEY (programid) REFERENCES public.program(programid);


--
-- Name: fk_mapview_programstageid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.mapview
    ADD CONSTRAINT fk_mapview_programstageid FOREIGN KEY (programstageid) REFERENCES public.programstage(programstageid);


--
-- Name: fk_mapview_relativeperiodsid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.mapview
    ADD CONSTRAINT fk_mapview_relativeperiodsid FOREIGN KEY (relativeperiodsid) REFERENCES public.relativeperiods(relativeperiodsid);


--
-- Name: fk_mapview_userid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.map
    ADD CONSTRAINT fk_mapview_userid FOREIGN KEY (userid) REFERENCES public.userinfo(userinfoid);


--
-- Name: fk_message_userid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.message
    ADD CONSTRAINT fk_message_userid FOREIGN KEY (userid) REFERENCES public.userinfo(userinfoid);


--
-- Name: fk_messageconversation_lastsender_userid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.messageconversation
    ADD CONSTRAINT fk_messageconversation_lastsender_userid FOREIGN KEY (lastsenderid) REFERENCES public.userinfo(userinfoid);


--
-- Name: fk_messageconversation_messages_messageconversationid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.messageconversation_messages
    ADD CONSTRAINT fk_messageconversation_messages_messageconversationid FOREIGN KEY (messageconversationid) REFERENCES public.messageconversation(messageconversationid);


--
-- Name: fk_messageconversation_messages_messageid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.messageconversation_messages
    ADD CONSTRAINT fk_messageconversation_messages_messageid FOREIGN KEY (messageid) REFERENCES public.message(messageid);


--
-- Name: fk_messageconversation_user_user_assigned; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.messageconversation
    ADD CONSTRAINT fk_messageconversation_user_user_assigned FOREIGN KEY (user_assigned) REFERENCES public.userinfo(userinfoid);


--
-- Name: fk_messageconversation_user_userid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.messageconversation
    ADD CONSTRAINT fk_messageconversation_user_userid FOREIGN KEY (userid) REFERENCES public.userinfo(userinfoid);


--
-- Name: fk_messageconversation_usermessages_messageconversationid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.messageconversation_usermessages
    ADD CONSTRAINT fk_messageconversation_usermessages_messageconversationid FOREIGN KEY (messageconversationid) REFERENCES public.messageconversation(messageconversationid);


--
-- Name: fk_messageconversation_usermessages_usermessageid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.messageconversation_usermessages
    ADD CONSTRAINT fk_messageconversation_usermessages_usermessageid FOREIGN KEY (usermessageid) REFERENCES public.usermessage(usermessageid);


--
-- Name: fk_minmaxdataelement_categoryoptioncomboid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.minmaxdataelement
    ADD CONSTRAINT fk_minmaxdataelement_categoryoptioncomboid FOREIGN KEY (categoryoptioncomboid) REFERENCES public.categoryoptioncombo(categoryoptioncomboid);


--
-- Name: fk_minmaxdataelement_dataelementid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.minmaxdataelement
    ADD CONSTRAINT fk_minmaxdataelement_dataelementid FOREIGN KEY (dataelementid) REFERENCES public.dataelement(dataelementid);


--
-- Name: fk_minmaxdataelement_organisationunitid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.minmaxdataelement
    ADD CONSTRAINT fk_minmaxdataelement_organisationunitid FOREIGN KEY (sourceid) REFERENCES public.organisationunit(organisationunitid);


--
-- Name: fk_oauth2clientgranttypes_oauth2clientid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.oauth2clientgranttypes
    ADD CONSTRAINT fk_oauth2clientgranttypes_oauth2clientid FOREIGN KEY (oauth2clientid) REFERENCES public.oauth2client(oauth2clientid);


--
-- Name: fk_oauth2clientredirecturis_oauth2clientid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.oauth2clientredirecturis
    ADD CONSTRAINT fk_oauth2clientredirecturis_oauth2clientid FOREIGN KEY (oauth2clientid) REFERENCES public.oauth2client(oauth2clientid);


--
-- Name: fk_objecttranslation_attributeid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.attributetranslations
    ADD CONSTRAINT fk_objecttranslation_attributeid FOREIGN KEY (attributeid) REFERENCES public.attribute(attributeid);


--
-- Name: fk_objecttranslation_categorycomboid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.categorycombotranslations
    ADD CONSTRAINT fk_objecttranslation_categorycomboid FOREIGN KEY (categorycomboid) REFERENCES public.categorycombo(categorycomboid);


--
-- Name: fk_objecttranslation_categoryid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dataelementcategorytranslations
    ADD CONSTRAINT fk_objecttranslation_categoryid FOREIGN KEY (categoryid) REFERENCES public.dataelementcategory(categoryid);


--
-- Name: fk_objecttranslation_categoryoptioncomboid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.categoryoptioncombotranslations
    ADD CONSTRAINT fk_objecttranslation_categoryoptioncomboid FOREIGN KEY (categoryoptioncomboid) REFERENCES public.categoryoptioncombo(categoryoptioncomboid);


--
-- Name: fk_objecttranslation_categoryoptiongroupid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.categoryoptiongrouptranslations
    ADD CONSTRAINT fk_objecttranslation_categoryoptiongroupid FOREIGN KEY (categoryoptiongroupid) REFERENCES public.categoryoptiongroup(categoryoptiongroupid);


--
-- Name: fk_objecttranslation_categoryoptiongroupsetid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.categoryoptiongroupsettranslations
    ADD CONSTRAINT fk_objecttranslation_categoryoptiongroupsetid FOREIGN KEY (categoryoptiongroupsetid) REFERENCES public.categoryoptiongroupset(categoryoptiongroupsetid);


--
-- Name: fk_objecttranslation_categoryoptionid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.categoryoptiontranslations
    ADD CONSTRAINT fk_objecttranslation_categoryoptionid FOREIGN KEY (categoryoptionid) REFERENCES public.dataelementcategoryoption(categoryoptionid);


--
-- Name: fk_objecttranslation_chartid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.charttranslations
    ADD CONSTRAINT fk_objecttranslation_chartid FOREIGN KEY (chartid) REFERENCES public.chart(chartid);


--
-- Name: fk_objecttranslation_colorid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.colortranslations
    ADD CONSTRAINT fk_objecttranslation_colorid FOREIGN KEY (colorid) REFERENCES public.color(colorid);


--
-- Name: fk_objecttranslation_colorid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.constanttranslations
    ADD CONSTRAINT fk_objecttranslation_colorid FOREIGN KEY (colorid) REFERENCES public.constant(constantid);


--
-- Name: fk_objecttranslation_colorsetid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.colorsettranslations
    ADD CONSTRAINT fk_objecttranslation_colorsetid FOREIGN KEY (colorsetid) REFERENCES public.colorset(colorsetid);


--
-- Name: fk_objecttranslation_dashboardid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dashboardtranslations
    ADD CONSTRAINT fk_objecttranslation_dashboardid FOREIGN KEY (dashboardid) REFERENCES public.dashboard(dashboardid);


--
-- Name: fk_objecttranslation_dashboarditemid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dashboarditemtranslations
    ADD CONSTRAINT fk_objecttranslation_dashboarditemid FOREIGN KEY (dashboarditemid) REFERENCES public.dashboarditem(dashboarditemid);


--
-- Name: fk_objecttranslation_dataapprovallevelid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dataapprovalleveltranslations
    ADD CONSTRAINT fk_objecttranslation_dataapprovallevelid FOREIGN KEY (dataapprovallevelid) REFERENCES public.dataapprovallevel(dataapprovallevelid);


--
-- Name: fk_objecttranslation_dataelementgroupid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dataelementgrouptranslations
    ADD CONSTRAINT fk_objecttranslation_dataelementgroupid FOREIGN KEY (dataelementgroupid) REFERENCES public.dataelementgroup(dataelementgroupid);


--
-- Name: fk_objecttranslation_dataelementgroupsetid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dataelementgroupsettranslations
    ADD CONSTRAINT fk_objecttranslation_dataelementgroupsetid FOREIGN KEY (dataelementgroupsetid) REFERENCES public.dataelementgroupset(dataelementgroupsetid);


--
-- Name: fk_objecttranslation_dataelementid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dataelementtranslations
    ADD CONSTRAINT fk_objecttranslation_dataelementid FOREIGN KEY (dataelementid) REFERENCES public.dataelement(dataelementid);


--
-- Name: fk_objecttranslation_dataentryformid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dataentryformtranslations
    ADD CONSTRAINT fk_objecttranslation_dataentryformid FOREIGN KEY (dataentryformid) REFERENCES public.dataentryform(dataentryformid);


--
-- Name: fk_objecttranslation_datasetid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.datasettranslations
    ADD CONSTRAINT fk_objecttranslation_datasetid FOREIGN KEY (datasetid) REFERENCES public.dataset(datasetid);


--
-- Name: fk_objecttranslation_documentid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.documenttranslations
    ADD CONSTRAINT fk_objecttranslation_documentid FOREIGN KEY (documentid) REFERENCES public.document(documentid);


--
-- Name: fk_objecttranslation_eventchartid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.eventcharttranslations
    ADD CONSTRAINT fk_objecttranslation_eventchartid FOREIGN KEY (eventchartid) REFERENCES public.eventchart(eventchartid);


--
-- Name: fk_objecttranslation_eventreportid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.eventreporttranslations
    ADD CONSTRAINT fk_objecttranslation_eventreportid FOREIGN KEY (eventreportid) REFERENCES public.eventreport(eventreportid);


--
-- Name: fk_objecttranslation_indicatorgroupid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.indicatorgrouptranslations
    ADD CONSTRAINT fk_objecttranslation_indicatorgroupid FOREIGN KEY (indicatorgroupid) REFERENCES public.indicatorgroup(indicatorgroupid);


--
-- Name: fk_objecttranslation_indicatorgroupsetid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.indicatorgroupsettranslations
    ADD CONSTRAINT fk_objecttranslation_indicatorgroupsetid FOREIGN KEY (indicatorgroupsetid) REFERENCES public.indicatorgroupset(indicatorgroupsetid);


--
-- Name: fk_objecttranslation_indicatorid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.indicatortranslations
    ADD CONSTRAINT fk_objecttranslation_indicatorid FOREIGN KEY (indicatorid) REFERENCES public.indicator(indicatorid);


--
-- Name: fk_objecttranslation_indicatortypeid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.indicatortypetranslations
    ADD CONSTRAINT fk_objecttranslation_indicatortypeid FOREIGN KEY (indicatortypeid) REFERENCES public.indicatortype(indicatortypeid);


--
-- Name: fk_objecttranslation_maplegendid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.maplegendtranslations
    ADD CONSTRAINT fk_objecttranslation_maplegendid FOREIGN KEY (maplegendid) REFERENCES public.maplegend(maplegendid);


--
-- Name: fk_objecttranslation_maplegendsetid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.maplegendsettranslations
    ADD CONSTRAINT fk_objecttranslation_maplegendsetid FOREIGN KEY (maplegendsetid) REFERENCES public.maplegendset(maplegendsetid);


--
-- Name: fk_objecttranslation_mapviewid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.mapviewtranslations
    ADD CONSTRAINT fk_objecttranslation_mapviewid FOREIGN KEY (mapviewid) REFERENCES public.mapview(mapviewid);


--
-- Name: fk_objecttranslation_optiongroupid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.optiongrouptranslations
    ADD CONSTRAINT fk_objecttranslation_optiongroupid FOREIGN KEY (optiongroupid) REFERENCES public.optiongroup(optiongroupid);


--
-- Name: fk_objecttranslation_optiongroupsetid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.optiongroupsettranslations
    ADD CONSTRAINT fk_objecttranslation_optiongroupsetid FOREIGN KEY (optiongroupsetid) REFERENCES public.optiongroupset(optiongroupsetid);


--
-- Name: fk_objecttranslation_optionsetid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.optionsettranslations
    ADD CONSTRAINT fk_objecttranslation_optionsetid FOREIGN KEY (optionsetid) REFERENCES public.optionset(optionsetid);


--
-- Name: fk_objecttranslation_optionvalueid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.optionvaluetranslations
    ADD CONSTRAINT fk_objecttranslation_optionvalueid FOREIGN KEY (optionvalueid) REFERENCES public.optionvalue(optionvalueid);


--
-- Name: fk_objecttranslation_organisationunitid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.organisationunittranslations
    ADD CONSTRAINT fk_objecttranslation_organisationunitid FOREIGN KEY (organisationunitid) REFERENCES public.organisationunit(organisationunitid);


--
-- Name: fk_objecttranslation_orgunitgroupid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.orgunitgrouptranslations
    ADD CONSTRAINT fk_objecttranslation_orgunitgroupid FOREIGN KEY (orgunitgroupid) REFERENCES public.orgunitgroup(orgunitgroupid);


--
-- Name: fk_objecttranslation_orgunitgroupsetid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.orgunitgroupsettranslations
    ADD CONSTRAINT fk_objecttranslation_orgunitgroupsetid FOREIGN KEY (orgunitgroupsetid) REFERENCES public.orgunitgroupset(orgunitgroupsetid);


--
-- Name: fk_objecttranslation_orgunitlevelid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.orgunitleveltranslations
    ADD CONSTRAINT fk_objecttranslation_orgunitlevelid FOREIGN KEY (orgunitlevelid) REFERENCES public.orgunitlevel(orgunitlevelid);


--
-- Name: fk_objecttranslation_programid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.programtranslations
    ADD CONSTRAINT fk_objecttranslation_programid FOREIGN KEY (programid) REFERENCES public.program(programid);


--
-- Name: fk_objecttranslation_programindicatorgroupid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.programindicatorgrouptranslations
    ADD CONSTRAINT fk_objecttranslation_programindicatorgroupid FOREIGN KEY (programindicatorgroupid) REFERENCES public.programindicatorgroup(programindicatorgroupid);


--
-- Name: fk_objecttranslation_programindicatorid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.programindicatortranslations
    ADD CONSTRAINT fk_objecttranslation_programindicatorid FOREIGN KEY (programindicatorid) REFERENCES public.programindicator(programindicatorid);


--
-- Name: fk_objecttranslation_programmessageid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.programmessagetranslations
    ADD CONSTRAINT fk_objecttranslation_programmessageid FOREIGN KEY (id) REFERENCES public.programmessage(id);


--
-- Name: fk_objecttranslation_programruleid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.programruletranslations
    ADD CONSTRAINT fk_objecttranslation_programruleid FOREIGN KEY (programruleid) REFERENCES public.programrule(programruleid);


--
-- Name: fk_objecttranslation_programsectionid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.programsectiontranslations
    ADD CONSTRAINT fk_objecttranslation_programsectionid FOREIGN KEY (programsectionid) REFERENCES public.programsection(programsectionid);


--
-- Name: fk_objecttranslation_programstageid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.programstagetranslations
    ADD CONSTRAINT fk_objecttranslation_programstageid FOREIGN KEY (programstageid) REFERENCES public.programstage(programstageid);


--
-- Name: fk_objecttranslation_programstagesectionid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.programstagesectiontranslations
    ADD CONSTRAINT fk_objecttranslation_programstagesectionid FOREIGN KEY (programstagesectionid) REFERENCES public.programstagesection(programstagesectionid);


--
-- Name: fk_objecttranslation_programtrackedentityattributegroupid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.programtrackedentityattributegrouptranslations
    ADD CONSTRAINT fk_objecttranslation_programtrackedentityattributegroupid FOREIGN KEY (programtrackedentityattributegroupid) REFERENCES public.program_attribute_group(programtrackedentityattributegroupid);


--
-- Name: fk_objecttranslation_relationshiptypeid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.relationshiptypetranslations
    ADD CONSTRAINT fk_objecttranslation_relationshiptypeid FOREIGN KEY (relationshiptypeid) REFERENCES public.relationshiptype(relationshiptypeid);


--
-- Name: fk_objecttranslation_reportid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.reporttranslations
    ADD CONSTRAINT fk_objecttranslation_reportid FOREIGN KEY (reportid) REFERENCES public.report(reportid);


--
-- Name: fk_objecttranslation_reporttableid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.reporttabletranslations
    ADD CONSTRAINT fk_objecttranslation_reporttableid FOREIGN KEY (reporttableid) REFERENCES public.reporttable(reporttableid);


--
-- Name: fk_objecttranslation_sectionid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.datasetsectiontranslations
    ADD CONSTRAINT fk_objecttranslation_sectionid FOREIGN KEY (sectionid) REFERENCES public.section(sectionid);


--
-- Name: fk_objecttranslation_trackedentityattributeid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.trackedentityattributetranslations
    ADD CONSTRAINT fk_objecttranslation_trackedentityattributeid FOREIGN KEY (trackedentityattributeid) REFERENCES public.trackedentityattribute(trackedentityattributeid);


--
-- Name: fk_objecttranslation_trackedentitytypeid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.trackedentitytranslations
    ADD CONSTRAINT fk_objecttranslation_trackedentitytypeid FOREIGN KEY (trackedentitytypeid) REFERENCES public.trackedentitytype(trackedentitytypeid);


--
-- Name: fk_objecttranslation_usergroupid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.usergrouptranslations
    ADD CONSTRAINT fk_objecttranslation_usergroupid FOREIGN KEY (usergroupid) REFERENCES public.usergroup(usergroupid);


--
-- Name: fk_objecttranslation_userroleid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.userroletranslations
    ADD CONSTRAINT fk_objecttranslation_userroleid FOREIGN KEY (userroleid) REFERENCES public.userrole(userroleid);


--
-- Name: fk_objecttranslation_validationcriteriaid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.validationcriteriatranslations
    ADD CONSTRAINT fk_objecttranslation_validationcriteriaid FOREIGN KEY (validationcriteriaid) REFERENCES public.validationcriteria(validationcriteriaid);


--
-- Name: fk_objecttranslation_validationrulegroupid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.validationrulegrouptranslations
    ADD CONSTRAINT fk_objecttranslation_validationrulegroupid FOREIGN KEY (validationrulegroupid) REFERENCES public.validationrulegroup(validationrulegroupid);


--
-- Name: fk_objecttranslation_validationruleid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.validationruletranslations
    ADD CONSTRAINT fk_objecttranslation_validationruleid FOREIGN KEY (validationruleid) REFERENCES public.validationrule(validationruleid);


--
-- Name: fk_objecttranslation_workflowid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dataapprovalworkflowtranslations
    ADD CONSTRAINT fk_objecttranslation_workflowid FOREIGN KEY (workflowid) REFERENCES public.dataapprovalworkflow(workflowid);


--
-- Name: fk_optiongroup_userid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.optiongroup
    ADD CONSTRAINT fk_optiongroup_userid FOREIGN KEY (userid) REFERENCES public.userinfo(userinfoid);


--
-- Name: fk_optiongroupmembers_optiongroupid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.optiongroupmembers
    ADD CONSTRAINT fk_optiongroupmembers_optiongroupid FOREIGN KEY (optionid) REFERENCES public.optionvalue(optionvalueid);


--
-- Name: fk_optiongroupmembers_optionid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.optiongroupmembers
    ADD CONSTRAINT fk_optiongroupmembers_optionid FOREIGN KEY (optiongroupid) REFERENCES public.optiongroup(optiongroupid);


--
-- Name: fk_optiongroupset_optionsetid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.optiongroupset
    ADD CONSTRAINT fk_optiongroupset_optionsetid FOREIGN KEY (optionsetid) REFERENCES public.optionset(optionsetid);


--
-- Name: fk_optiongroupset_userid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.optiongroupset
    ADD CONSTRAINT fk_optiongroupset_userid FOREIGN KEY (userid) REFERENCES public.userinfo(userinfoid);


--
-- Name: fk_optiongroupsetmembers_optiongroupid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.optiongroupsetmembers
    ADD CONSTRAINT fk_optiongroupsetmembers_optiongroupid FOREIGN KEY (optiongroupid) REFERENCES public.optiongroup(optiongroupid);


--
-- Name: fk_optiongroupsetmembers_optiongroupsetid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.optiongroupsetmembers
    ADD CONSTRAINT fk_optiongroupsetmembers_optiongroupsetid FOREIGN KEY (optiongroupsetid) REFERENCES public.optiongroupset(optiongroupsetid);


--
-- Name: fk_optionset_userid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.optionset
    ADD CONSTRAINT fk_optionset_userid FOREIGN KEY (userid) REFERENCES public.userinfo(userinfoid);


--
-- Name: fk_optionsetmembers_optionsetid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.optionvalue
    ADD CONSTRAINT fk_optionsetmembers_optionsetid FOREIGN KEY (optionsetid) REFERENCES public.optionset(optionsetid);


--
-- Name: fk_organisationunit_userid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.organisationunit
    ADD CONSTRAINT fk_organisationunit_userid FOREIGN KEY (userid) REFERENCES public.userinfo(userinfoid);


--
-- Name: fk_organisationunitlevel_validationtuleid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.validationruleorganisationunitlevels
    ADD CONSTRAINT fk_organisationunitlevel_validationtuleid FOREIGN KEY (validationruleid) REFERENCES public.validationrule(validationruleid);


--
-- Name: fk_orgunitgroup_organisationunitid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.orgunitgroupmembers
    ADD CONSTRAINT fk_orgunitgroup_organisationunitid FOREIGN KEY (organisationunitid) REFERENCES public.organisationunit(organisationunitid);


--
-- Name: fk_orgunitgroup_userid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.orgunitgroup
    ADD CONSTRAINT fk_orgunitgroup_userid FOREIGN KEY (userid) REFERENCES public.userinfo(userinfoid);


--
-- Name: fk_orgunitgroupmembers_orgunitgroupid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.orgunitgroupmembers
    ADD CONSTRAINT fk_orgunitgroupmembers_orgunitgroupid FOREIGN KEY (orgunitgroupid) REFERENCES public.orgunitgroup(orgunitgroupid);


--
-- Name: fk_orgunitgroupset_orgunitgroupid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.orgunitgroupsetmembers
    ADD CONSTRAINT fk_orgunitgroupset_orgunitgroupid FOREIGN KEY (orgunitgroupid) REFERENCES public.orgunitgroup(orgunitgroupid);


--
-- Name: fk_orgunitgroupset_userid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.orgunitgroupset
    ADD CONSTRAINT fk_orgunitgroupset_userid FOREIGN KEY (userid) REFERENCES public.userinfo(userinfoid);


--
-- Name: fk_orgunitgroupsetmembers_orgunitgroupsetid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.orgunitgroupsetmembers
    ADD CONSTRAINT fk_orgunitgroupsetmembers_orgunitgroupsetid FOREIGN KEY (orgunitgroupsetid) REFERENCES public.orgunitgroupset(orgunitgroupsetid);


--
-- Name: fk_parentid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.organisationunit
    ADD CONSTRAINT fk_parentid FOREIGN KEY (parentid) REFERENCES public.organisationunit(organisationunitid);


--
-- Name: fk_period_periodtypeid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.period
    ADD CONSTRAINT fk_period_periodtypeid FOREIGN KEY (periodtypeid) REFERENCES public.periodtype(periodtypeid);


--
-- Name: fk_predictor_generatorexpressionid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.predictor
    ADD CONSTRAINT fk_predictor_generatorexpressionid FOREIGN KEY (generatorexpressionid) REFERENCES public.expression(expressionid);


--
-- Name: fk_predictor_outputcomboid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.predictor
    ADD CONSTRAINT fk_predictor_outputcomboid FOREIGN KEY (generatoroutputcombo) REFERENCES public.categoryoptioncombo(categoryoptioncomboid);


--
-- Name: fk_predictor_outputdataelementid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.predictor
    ADD CONSTRAINT fk_predictor_outputdataelementid FOREIGN KEY (generatoroutput) REFERENCES public.dataelement(dataelementid);


--
-- Name: fk_predictororgunitlevels_orgunitlevelid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.predictororgunitlevels
    ADD CONSTRAINT fk_predictororgunitlevels_orgunitlevelid FOREIGN KEY (orgunitlevelid) REFERENCES public.orgunitlevel(orgunitlevelid);


--
-- Name: fk_predictororgunitlevels_predictorid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.predictororgunitlevels
    ADD CONSTRAINT fk_predictororgunitlevels_predictorid FOREIGN KEY (predictorid) REFERENCES public.predictor(predictorid);


--
-- Name: fk_program_attributeid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.program_attributes
    ADD CONSTRAINT fk_program_attributeid FOREIGN KEY (trackedentityattributeid) REFERENCES public.trackedentityattribute(trackedentityattributeid);


--
-- Name: fk_program_categorycomboid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.program
    ADD CONSTRAINT fk_program_categorycomboid FOREIGN KEY (categorycomboid) REFERENCES public.categorycombo(categorycomboid);


--
-- Name: fk_program_criteria_programid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.program_criteria
    ADD CONSTRAINT fk_program_criteria_programid FOREIGN KEY (programid) REFERENCES public.program(programid);


--
-- Name: fk_program_criteria_validationcriteriaid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.program_criteria
    ADD CONSTRAINT fk_program_criteria_validationcriteriaid FOREIGN KEY (validationcriteriaid) REFERENCES public.validationcriteria(validationcriteriaid);


--
-- Name: fk_program_dataentryformid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.program
    ADD CONSTRAINT fk_program_dataentryformid FOREIGN KEY (dataentryformid) REFERENCES public.dataentryform(dataentryformid);


--
-- Name: fk_program_expiryperiodtypeid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.program
    ADD CONSTRAINT fk_program_expiryperiodtypeid FOREIGN KEY (expiryperiodtypeid) REFERENCES public.periodtype(periodtypeid);


--
-- Name: fk_program_organisationunits_organisationunitid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.program_organisationunits
    ADD CONSTRAINT fk_program_organisationunits_organisationunitid FOREIGN KEY (organisationunitid) REFERENCES public.organisationunit(organisationunitid);


--
-- Name: fk_program_organisationunits_programid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.program_organisationunits
    ADD CONSTRAINT fk_program_organisationunits_programid FOREIGN KEY (programid) REFERENCES public.program(programid);


--
-- Name: fk_program_programid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.programsection
    ADD CONSTRAINT fk_program_programid FOREIGN KEY (programid) REFERENCES public.program(programid);


--
-- Name: fk_program_programstageid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.programstagesection
    ADD CONSTRAINT fk_program_programstageid FOREIGN KEY (programstageid) REFERENCES public.programstage(programstageid);


--
-- Name: fk_program_relatedprogram; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.program
    ADD CONSTRAINT fk_program_relatedprogram FOREIGN KEY (relatedprogramid) REFERENCES public.program(programid);


--
-- Name: fk_program_relationshipid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.program
    ADD CONSTRAINT fk_program_relationshipid FOREIGN KEY (relationshiptypeid) REFERENCES public.relationshiptype(relationshiptypeid);


--
-- Name: fk_program_trackedentitytypeid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.program
    ADD CONSTRAINT fk_program_trackedentitytypeid FOREIGN KEY (trackedentitytypeid) REFERENCES public.trackedentitytype(trackedentitytypeid);


--
-- Name: fk_program_userid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.program
    ADD CONSTRAINT fk_program_userid FOREIGN KEY (userid) REFERENCES public.userinfo(userinfoid);


--
-- Name: fk_program_userroles; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.program_userroles
    ADD CONSTRAINT fk_program_userroles FOREIGN KEY (userroleid) REFERENCES public.userrole(userroleid);


--
-- Name: fk_program_workflowid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.program
    ADD CONSTRAINT fk_program_workflowid FOREIGN KEY (workflowid) REFERENCES public.dataapprovalworkflow(workflowid);


--
-- Name: fk_programindicator_legendsetid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.programindicatorlegendsets
    ADD CONSTRAINT fk_programindicator_legendsetid FOREIGN KEY (legendsetid) REFERENCES public.maplegendset(maplegendsetid);


--
-- Name: fk_programindicator_program; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.programindicator
    ADD CONSTRAINT fk_programindicator_program FOREIGN KEY (programid) REFERENCES public.program(programid);


--
-- Name: fk_programindicator_userid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.programindicator
    ADD CONSTRAINT fk_programindicator_userid FOREIGN KEY (userid) REFERENCES public.userinfo(userinfoid);


--
-- Name: fk_programindicatorgroup_programindicatorid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.programindicatorgroupmembers
    ADD CONSTRAINT fk_programindicatorgroup_programindicatorid FOREIGN KEY (programindicatorid) REFERENCES public.programindicator(programindicatorid);


--
-- Name: fk_programindicatorgroup_userid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.programindicatorgroup
    ADD CONSTRAINT fk_programindicatorgroup_userid FOREIGN KEY (userid) REFERENCES public.userinfo(userinfoid);


--
-- Name: fk_programindicatorgroupmembers_programindicatorgroupid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.programindicatorgroupmembers
    ADD CONSTRAINT fk_programindicatorgroupmembers_programindicatorgroupid FOREIGN KEY (programindicatorgroupid) REFERENCES public.programindicatorgroup(programindicatorgroupid);


--
-- Name: fk_programinstance_organisationunitid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.programinstance
    ADD CONSTRAINT fk_programinstance_organisationunitid FOREIGN KEY (organisationunitid) REFERENCES public.organisationunit(organisationunitid);


--
-- Name: fk_programinstance_programid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.programinstance
    ADD CONSTRAINT fk_programinstance_programid FOREIGN KEY (programid) REFERENCES public.program(programid);


--
-- Name: fk_programinstance_trackedentityinstanceid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.programinstance
    ADD CONSTRAINT fk_programinstance_trackedentityinstanceid FOREIGN KEY (trackedentityinstanceid) REFERENCES public.trackedentityinstance(trackedentityinstanceid);


--
-- Name: fk_programinstancecomments_programinstanceid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.programinstancecomments
    ADD CONSTRAINT fk_programinstancecomments_programinstanceid FOREIGN KEY (programinstanceid) REFERENCES public.programinstance(programinstanceid);


--
-- Name: fk_programinstancecomments_trackedentitycommentid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.programinstancecomments
    ADD CONSTRAINT fk_programinstancecomments_trackedentitycommentid FOREIGN KEY (trackedentitycommentid) REFERENCES public.trackedentitycomment(trackedentitycommentid);


--
-- Name: fk_programmessage_organisationunitid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.programmessage
    ADD CONSTRAINT fk_programmessage_organisationunitid FOREIGN KEY (organisationunitid) REFERENCES public.organisationunit(organisationunitid);


--
-- Name: fk_programmessage_programinstanceid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.programmessage
    ADD CONSTRAINT fk_programmessage_programinstanceid FOREIGN KEY (programinstanceid) REFERENCES public.programinstance(programinstanceid);


--
-- Name: fk_programmessage_programstageinstanceid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.programmessage
    ADD CONSTRAINT fk_programmessage_programstageinstanceid FOREIGN KEY (programstageinstanceid) REFERENCES public.programstageinstance(programstageinstanceid);


--
-- Name: fk_programmessage_trackedentityinstanceid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.programmessage
    ADD CONSTRAINT fk_programmessage_trackedentityinstanceid FOREIGN KEY (trackedentityinstanceid) REFERENCES public.trackedentityinstance(trackedentityinstanceid);


--
-- Name: fk_programrule_program; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.programrule
    ADD CONSTRAINT fk_programrule_program FOREIGN KEY (programid) REFERENCES public.program(programid);


--
-- Name: fk_programrule_programstage; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.programrule
    ADD CONSTRAINT fk_programrule_programstage FOREIGN KEY (programstageid) REFERENCES public.programstage(programstageid);


--
-- Name: fk_programruleaction_dataelement; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.programruleaction
    ADD CONSTRAINT fk_programruleaction_dataelement FOREIGN KEY (dataelementid) REFERENCES public.dataelement(dataelementid);


--
-- Name: fk_programruleaction_programindicator; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.programruleaction
    ADD CONSTRAINT fk_programruleaction_programindicator FOREIGN KEY (programindicatorid) REFERENCES public.programindicator(programindicatorid);


--
-- Name: fk_programruleaction_programnotification; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.programruleaction
    ADD CONSTRAINT fk_programruleaction_programnotification FOREIGN KEY (programnotificationtemplateid) REFERENCES public.programnotificationtemplate(programnotificationtemplateid);


--
-- Name: fk_programruleaction_programrule; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.programruleaction
    ADD CONSTRAINT fk_programruleaction_programrule FOREIGN KEY (programruleid) REFERENCES public.programrule(programruleid);


--
-- Name: fk_programruleaction_programstage; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.programruleaction
    ADD CONSTRAINT fk_programruleaction_programstage FOREIGN KEY (programstageid) REFERENCES public.programstage(programstageid);


--
-- Name: fk_programruleaction_programstagesection; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.programruleaction
    ADD CONSTRAINT fk_programruleaction_programstagesection FOREIGN KEY (programstagesectionid) REFERENCES public.programstagesection(programstagesectionid);


--
-- Name: fk_programruleaction_trackedentityattribute; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.programruleaction
    ADD CONSTRAINT fk_programruleaction_trackedentityattribute FOREIGN KEY (trackedentityattributeid) REFERENCES public.trackedentityattribute(trackedentityattributeid);


--
-- Name: fk_programrulevariable_dataelement; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.programrulevariable
    ADD CONSTRAINT fk_programrulevariable_dataelement FOREIGN KEY (dataelementid) REFERENCES public.dataelement(dataelementid);


--
-- Name: fk_programrulevariable_program; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.programrulevariable
    ADD CONSTRAINT fk_programrulevariable_program FOREIGN KEY (programid) REFERENCES public.program(programid);


--
-- Name: fk_programrulevariable_programstage; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.programrulevariable
    ADD CONSTRAINT fk_programrulevariable_programstage FOREIGN KEY (programstageid) REFERENCES public.programstage(programstageid);


--
-- Name: fk_programrulevariable_trackedentityattribute; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.programrulevariable
    ADD CONSTRAINT fk_programrulevariable_trackedentityattribute FOREIGN KEY (trackedentityattributeid) REFERENCES public.trackedentityattribute(trackedentityattributeid);


--
-- Name: fk_programsection_attributes_trackedentityattributeid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.programsection_attributes
    ADD CONSTRAINT fk_programsection_attributes_trackedentityattributeid FOREIGN KEY (trackedentityattributeid) REFERENCES public.trackedentityattribute(trackedentityattributeid);


--
-- Name: fk_programsections_attributes_programsectionid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.programsection_attributes
    ADD CONSTRAINT fk_programsections_attributes_programsectionid FOREIGN KEY (programsectionid) REFERENCES public.programsection(programsectionid);


--
-- Name: fk_programstage_dataentryform; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.programstage
    ADD CONSTRAINT fk_programstage_dataentryform FOREIGN KEY (dataentryformid) REFERENCES public.dataentryform(dataentryformid);


--
-- Name: fk_programstage_periodtypeid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.programstage
    ADD CONSTRAINT fk_programstage_periodtypeid FOREIGN KEY (periodtypeid) REFERENCES public.periodtype(periodtypeid);


--
-- Name: fk_programstage_program; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.programstage
    ADD CONSTRAINT fk_programstage_program FOREIGN KEY (programid) REFERENCES public.program(programid);


--
-- Name: fk_programstage_userid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.programstage
    ADD CONSTRAINT fk_programstage_userid FOREIGN KEY (userid) REFERENCES public.userinfo(userinfoid);


--
-- Name: fk_programstagedataelement_dataelementid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.programstagedataelement
    ADD CONSTRAINT fk_programstagedataelement_dataelementid FOREIGN KEY (dataelementid) REFERENCES public.dataelement(dataelementid);


--
-- Name: fk_programstagedataelement_programstageid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.programstagedataelement
    ADD CONSTRAINT fk_programstagedataelement_programstageid FOREIGN KEY (programstageid) REFERENCES public.programstage(programstageid);


--
-- Name: fk_programstageinstance_attributeoptioncomboid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.programstageinstance
    ADD CONSTRAINT fk_programstageinstance_attributeoptioncomboid FOREIGN KEY (attributeoptioncomboid) REFERENCES public.categoryoptioncombo(categoryoptioncomboid);


--
-- Name: fk_programstageinstance_organisationunitid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.programstageinstance
    ADD CONSTRAINT fk_programstageinstance_organisationunitid FOREIGN KEY (organisationunitid) REFERENCES public.organisationunit(organisationunitid);


--
-- Name: fk_programstageinstance_programinstanceid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.programstageinstance
    ADD CONSTRAINT fk_programstageinstance_programinstanceid FOREIGN KEY (programinstanceid) REFERENCES public.programinstance(programinstanceid);


--
-- Name: fk_programstageinstance_programstageid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.programstageinstance
    ADD CONSTRAINT fk_programstageinstance_programstageid FOREIGN KEY (programstageid) REFERENCES public.programstage(programstageid);


--
-- Name: fk_programstageinstancecomments_programstageinstanceid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.programstageinstancecomments
    ADD CONSTRAINT fk_programstageinstancecomments_programstageinstanceid FOREIGN KEY (programstageinstanceid) REFERENCES public.programstageinstance(programstageinstanceid);


--
-- Name: fk_programstageinstancecomments_trackedentitycommentid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.programstageinstancecomments
    ADD CONSTRAINT fk_programstageinstancecomments_trackedentitycommentid FOREIGN KEY (trackedentitycommentid) REFERENCES public.trackedentitycomment(trackedentitycommentid);


--
-- Name: fk_programstagenotification_dataelementid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.programnotificationtemplate
    ADD CONSTRAINT fk_programstagenotification_dataelementid FOREIGN KEY (dataelementid) REFERENCES public.dataelement(dataelementid);


--
-- Name: fk_programstagenotification_trackedentityattributeid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.programnotificationtemplate
    ADD CONSTRAINT fk_programstagenotification_trackedentityattributeid FOREIGN KEY (trackedentityattributeid) REFERENCES public.trackedentityattribute(trackedentityattributeid);


--
-- Name: fk_programstagenotification_usergroup; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.programnotificationtemplate
    ADD CONSTRAINT fk_programstagenotification_usergroup FOREIGN KEY (usergroupid) REFERENCES public.usergroup(usergroupid);


--
-- Name: fk_programstagesection_dataelements_dataelementid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.programstagesection_dataelements
    ADD CONSTRAINT fk_programstagesection_dataelements_dataelementid FOREIGN KEY (dataelementid) REFERENCES public.dataelement(dataelementid);


--
-- Name: fk_programstagesection_dataelements_programstagesectionid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.programstagesection_dataelements
    ADD CONSTRAINT fk_programstagesection_dataelements_programstagesectionid FOREIGN KEY (programstagesectionid) REFERENCES public.programstagesection(programstagesectionid);


--
-- Name: fk_programstagesection_programindicators_indicatorid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.programstagesection_programindicators
    ADD CONSTRAINT fk_programstagesection_programindicators_indicatorid FOREIGN KEY (programindicatorid) REFERENCES public.programindicator(programindicatorid);


--
-- Name: fk_programstagesection_programindicators_sectionid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.programstagesection_programindicators
    ADD CONSTRAINT fk_programstagesection_programindicators_sectionid FOREIGN KEY (programstagesectionid) REFERENCES public.programstagesection(programstagesectionid);


--
-- Name: fk_programtrackedentityattribute_programid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.program_attributes
    ADD CONSTRAINT fk_programtrackedentityattribute_programid FOREIGN KEY (programid) REFERENCES public.program(programid);


--
-- Name: fk_programtrackedentityattributegroupmembers_attributeid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.programtrackedentityattributegroupmembers
    ADD CONSTRAINT fk_programtrackedentityattributegroupmembers_attributeid FOREIGN KEY (programtrackedentityattributeid) REFERENCES public.program_attributes(programtrackedentityattributeid);


--
-- Name: fk_programtrackedentityattributegroupmembers_groupid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.programtrackedentityattributegroupmembers
    ADD CONSTRAINT fk_programtrackedentityattributegroupmembers_groupid FOREIGN KEY (programtrackedentityattributegroupid) REFERENCES public.program_attribute_group(programtrackedentityattributegroupid);


--
-- Name: fk_pushanalysis_recipientusergroups; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pushanalysisrecipientusergroups
    ADD CONSTRAINT fk_pushanalysis_recipientusergroups FOREIGN KEY (elt) REFERENCES public.usergroup(usergroupid);


--
-- Name: fk_relationship_relationshiptypeid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.relationship
    ADD CONSTRAINT fk_relationship_relationshiptypeid FOREIGN KEY (relationshiptypeid) REFERENCES public.relationshiptype(relationshiptypeid);


--
-- Name: fk_relationship_trackedentityinstanceida; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.relationship
    ADD CONSTRAINT fk_relationship_trackedentityinstanceida FOREIGN KEY (trackedentityinstanceaid) REFERENCES public.trackedentityinstance(trackedentityinstanceid);


--
-- Name: fk_relationship_trackedentityinstanceidb; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.relationship
    ADD CONSTRAINT fk_relationship_trackedentityinstanceidb FOREIGN KEY (trackedentityinstancebid) REFERENCES public.trackedentityinstance(trackedentityinstanceid);


--
-- Name: fk_report_relativeperiodsid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.report
    ADD CONSTRAINT fk_report_relativeperiodsid FOREIGN KEY (relativeperiodsid) REFERENCES public.relativeperiods(relativeperiodsid);


--
-- Name: fk_report_reporttableid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.report
    ADD CONSTRAINT fk_report_reporttableid FOREIGN KEY (reporttableid) REFERENCES public.reporttable(reporttableid);


--
-- Name: fk_report_userid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.report
    ADD CONSTRAINT fk_report_userid FOREIGN KEY (userid) REFERENCES public.userinfo(userinfoid);


--
-- Name: fk_reporttable_categorydimensions_categorydimensionid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.reporttable_categorydimensions
    ADD CONSTRAINT fk_reporttable_categorydimensions_categorydimensionid FOREIGN KEY (categorydimensionid) REFERENCES public.categorydimension(categorydimensionid);


--
-- Name: fk_reporttable_categorydimensions_reporttableid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.reporttable_categorydimensions
    ADD CONSTRAINT fk_reporttable_categorydimensions_reporttableid FOREIGN KEY (reporttableid) REFERENCES public.reporttable(reporttableid);


--
-- Name: fk_reporttable_catoptiongroupsetdimensions_reporttableid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.reporttable_categoryoptiongroupsetdimensions
    ADD CONSTRAINT fk_reporttable_catoptiongroupsetdimensions_reporttableid FOREIGN KEY (reporttableid) REFERENCES public.reporttable(reporttableid);


--
-- Name: fk_reporttable_columns_reporttableid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.reporttable_columns
    ADD CONSTRAINT fk_reporttable_columns_reporttableid FOREIGN KEY (reporttableid) REFERENCES public.reporttable(reporttableid);


--
-- Name: fk_reporttable_datadimensionitems_datadimensionitemid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.reporttable_datadimensionitems
    ADD CONSTRAINT fk_reporttable_datadimensionitems_datadimensionitemid FOREIGN KEY (datadimensionitemid) REFERENCES public.datadimensionitem(datadimensionitemid);


--
-- Name: fk_reporttable_datadimensionitems_reporttableid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.reporttable_datadimensionitems
    ADD CONSTRAINT fk_reporttable_datadimensionitems_reporttableid FOREIGN KEY (reporttableid) REFERENCES public.reporttable(reporttableid);


--
-- Name: fk_reporttable_dataelememntgroupsetdimensions_reporttableid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.reporttable_dataelementgroupsetdimensions
    ADD CONSTRAINT fk_reporttable_dataelememntgroupsetdimensions_reporttableid FOREIGN KEY (reporttableid) REFERENCES public.reporttable(reporttableid);


--
-- Name: fk_reporttable_dimensions_catoptiongroupsetdimensionid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.reporttable_categoryoptiongroupsetdimensions
    ADD CONSTRAINT fk_reporttable_dimensions_catoptiongroupsetdimensionid FOREIGN KEY (categoryoptiongroupsetdimensionid) REFERENCES public.categoryoptiongroupsetdimension(categoryoptiongroupsetdimensionid);


--
-- Name: fk_reporttable_dimensions_dataelementgroupsetdimensionid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.reporttable_dataelementgroupsetdimensions
    ADD CONSTRAINT fk_reporttable_dimensions_dataelementgroupsetdimensionid FOREIGN KEY (dataelementgroupsetdimensionid) REFERENCES public.dataelementgroupsetdimension(dataelementgroupsetdimensionid);


--
-- Name: fk_reporttable_dimensions_orgunitgroupsetdimensionid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.reporttable_orgunitgroupsetdimensions
    ADD CONSTRAINT fk_reporttable_dimensions_orgunitgroupsetdimensionid FOREIGN KEY (orgunitgroupsetdimensionid) REFERENCES public.orgunitgroupsetdimension(orgunitgroupsetdimensionid);


--
-- Name: fk_reporttable_filters_reporttableid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.reporttable_filters
    ADD CONSTRAINT fk_reporttable_filters_reporttableid FOREIGN KEY (reporttableid) REFERENCES public.reporttable(reporttableid);


--
-- Name: fk_reporttable_itemorgunitgroups_orgunitgroupid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.reporttable_itemorgunitgroups
    ADD CONSTRAINT fk_reporttable_itemorgunitgroups_orgunitgroupid FOREIGN KEY (orgunitgroupid) REFERENCES public.orgunitgroup(orgunitgroupid);


--
-- Name: fk_reporttable_itemorgunitunitgroups_reporttableid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.reporttable_itemorgunitgroups
    ADD CONSTRAINT fk_reporttable_itemorgunitunitgroups_reporttableid FOREIGN KEY (reporttableid) REFERENCES public.reporttable(reporttableid);


--
-- Name: fk_reporttable_legendsetid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.reporttable
    ADD CONSTRAINT fk_reporttable_legendsetid FOREIGN KEY (legendsetid) REFERENCES public.maplegendset(maplegendsetid);


--
-- Name: fk_reporttable_organisationunits_organisationunitid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.reporttable_organisationunits
    ADD CONSTRAINT fk_reporttable_organisationunits_organisationunitid FOREIGN KEY (organisationunitid) REFERENCES public.organisationunit(organisationunitid);


--
-- Name: fk_reporttable_organisationunits_reporttableid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.reporttable_organisationunits
    ADD CONSTRAINT fk_reporttable_organisationunits_reporttableid FOREIGN KEY (reporttableid) REFERENCES public.reporttable(reporttableid);


--
-- Name: fk_reporttable_orgunitgroupsetdimensions_reporttableid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.reporttable_orgunitgroupsetdimensions
    ADD CONSTRAINT fk_reporttable_orgunitgroupsetdimensions_reporttableid FOREIGN KEY (reporttableid) REFERENCES public.reporttable(reporttableid);


--
-- Name: fk_reporttable_orgunitlevels_reporttableid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.reporttable_orgunitlevels
    ADD CONSTRAINT fk_reporttable_orgunitlevels_reporttableid FOREIGN KEY (reporttableid) REFERENCES public.reporttable(reporttableid);


--
-- Name: fk_reporttable_periods_periodid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.reporttable_periods
    ADD CONSTRAINT fk_reporttable_periods_periodid FOREIGN KEY (periodid) REFERENCES public.period(periodid);


--
-- Name: fk_reporttable_periods_reporttableid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.reporttable_periods
    ADD CONSTRAINT fk_reporttable_periods_reporttableid FOREIGN KEY (reporttableid) REFERENCES public.reporttable(reporttableid);


--
-- Name: fk_reporttable_relativeperiodsid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.reporttable
    ADD CONSTRAINT fk_reporttable_relativeperiodsid FOREIGN KEY (relativeperiodsid) REFERENCES public.relativeperiods(relativeperiodsid);


--
-- Name: fk_reporttable_rows_reporttableid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.reporttable_rows
    ADD CONSTRAINT fk_reporttable_rows_reporttableid FOREIGN KEY (reporttableid) REFERENCES public.reporttable(reporttableid);


--
-- Name: fk_reporttable_userid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.reporttable
    ADD CONSTRAINT fk_reporttable_userid FOREIGN KEY (userid) REFERENCES public.userinfo(userinfoid);


--
-- Name: fk_section_dataelementid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sectiondataelements
    ADD CONSTRAINT fk_section_dataelementid FOREIGN KEY (dataelementid) REFERENCES public.dataelement(dataelementid);


--
-- Name: fk_section_dataelementoperandid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sectiongreyedfields
    ADD CONSTRAINT fk_section_dataelementoperandid FOREIGN KEY (dataelementoperandid) REFERENCES public.dataelementoperand(dataelementoperandid);


--
-- Name: fk_section_datasetid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.section
    ADD CONSTRAINT fk_section_datasetid FOREIGN KEY (datasetid) REFERENCES public.dataset(datasetid);


--
-- Name: fk_section_indicatorid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sectionindicators
    ADD CONSTRAINT fk_section_indicatorid FOREIGN KEY (indicatorid) REFERENCES public.indicator(indicatorid);


--
-- Name: fk_sectiondataelements_sectionid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sectiondataelements
    ADD CONSTRAINT fk_sectiondataelements_sectionid FOREIGN KEY (sectionid) REFERENCES public.section(sectionid);


--
-- Name: fk_sectiongreyedfields_sectionid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sectiongreyedfields
    ADD CONSTRAINT fk_sectiongreyedfields_sectionid FOREIGN KEY (sectionid) REFERENCES public.section(sectionid);


--
-- Name: fk_sectionindicators_sectionid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sectionindicators
    ADD CONSTRAINT fk_sectionindicators_sectionid FOREIGN KEY (sectionid) REFERENCES public.section(sectionid);


--
-- Name: fk_smscommand_program; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.smscommands
    ADD CONSTRAINT fk_smscommand_program FOREIGN KEY (programid) REFERENCES public.program(programid);


--
-- Name: fk_smscommand_programstage; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.smscommands
    ADD CONSTRAINT fk_smscommand_programstage FOREIGN KEY (programstageid) REFERENCES public.programstage(programstageid);


--
-- Name: fk_smscommand_usergroup; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.smscommands
    ADD CONSTRAINT fk_smscommand_usergroup FOREIGN KEY (usergroupid) REFERENCES public.usergroup(usergroupid);


--
-- Name: fk_sqlview_userid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sqlview
    ADD CONSTRAINT fk_sqlview_userid FOREIGN KEY (userid) REFERENCES public.userinfo(userinfoid);


--
-- Name: fk_teattributedimension_attributeid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.trackedentityattributedimension
    ADD CONSTRAINT fk_teattributedimension_attributeid FOREIGN KEY (trackedentityattributeid) REFERENCES public.trackedentityattribute(trackedentityattributeid);


--
-- Name: fk_teattributedimension_legendsetid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.trackedentityattributedimension
    ADD CONSTRAINT fk_teattributedimension_legendsetid FOREIGN KEY (legendsetid) REFERENCES public.maplegendset(maplegendsetid);


--
-- Name: fk_tedataelementdimension_dataelementid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.trackedentitydataelementdimension
    ADD CONSTRAINT fk_tedataelementdimension_dataelementid FOREIGN KEY (dataelementid) REFERENCES public.dataelement(dataelementid);


--
-- Name: fk_tedataelementdimension_legendsetid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.trackedentitydataelementdimension
    ADD CONSTRAINT fk_tedataelementdimension_legendsetid FOREIGN KEY (legendsetid) REFERENCES public.maplegendset(maplegendsetid);


--
-- Name: fk_teprogramindicatordimension_legendsetid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.trackedentityprogramindicatordimension
    ADD CONSTRAINT fk_teprogramindicatordimension_legendsetid FOREIGN KEY (legendsetid) REFERENCES public.maplegendset(maplegendsetid);


--
-- Name: fk_teprogramindicatordimension_programindicatorid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.trackedentityprogramindicatordimension
    ADD CONSTRAINT fk_teprogramindicatordimension_programindicatorid FOREIGN KEY (programindicatorid) REFERENCES public.programindicator(programindicatorid);


--
-- Name: fk_trackedentityattribute_legendsetid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.trackedentityattributelegendsets
    ADD CONSTRAINT fk_trackedentityattribute_legendsetid FOREIGN KEY (legendsetid) REFERENCES public.maplegendset(maplegendsetid);


--
-- Name: fk_trackedentityattribute_optionsetid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.trackedentityattribute
    ADD CONSTRAINT fk_trackedentityattribute_optionsetid FOREIGN KEY (optionsetid) REFERENCES public.optionset(optionsetid);


--
-- Name: fk_trackedentityattribute_trackedentityattributeid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.smscodes
    ADD CONSTRAINT fk_trackedentityattribute_trackedentityattributeid FOREIGN KEY (trackedentityattributeid) REFERENCES public.trackedentityattribute(trackedentityattributeid);


--
-- Name: fk_trackedentityattribute_userid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.trackedentityattribute
    ADD CONSTRAINT fk_trackedentityattribute_userid FOREIGN KEY (userid) REFERENCES public.userinfo(userinfoid);


--
-- Name: fk_trackedentityinstance_organisationunitid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.trackedentityinstance
    ADD CONSTRAINT fk_trackedentityinstance_organisationunitid FOREIGN KEY (organisationunitid) REFERENCES public.organisationunit(organisationunitid);


--
-- Name: fk_trackedentityinstance_representativeid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.trackedentityinstance
    ADD CONSTRAINT fk_trackedentityinstance_representativeid FOREIGN KEY (representativeid) REFERENCES public.trackedentityinstance(trackedentityinstanceid);


--
-- Name: fk_trackedentityinstance_trackedentitytypeid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.trackedentityinstance
    ADD CONSTRAINT fk_trackedentityinstance_trackedentitytypeid FOREIGN KEY (trackedentitytypeid) REFERENCES public.trackedentitytype(trackedentitytypeid);


--
-- Name: fk_trackedentityinstancefilter_programid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.trackedentityinstancefilter
    ADD CONSTRAINT fk_trackedentityinstancefilter_programid FOREIGN KEY (programid) REFERENCES public.program(programid);


--
-- Name: fk_trackedentitytype_userid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.trackedentitytype
    ADD CONSTRAINT fk_trackedentitytype_userid FOREIGN KEY (userid) REFERENCES public.userinfo(userinfoid);


--
-- Name: fk_trackedentitytypeattribute_trackedentityattributeid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.trackedentitytypeattribute
    ADD CONSTRAINT fk_trackedentitytypeattribute_trackedentityattributeid FOREIGN KEY (trackedentityattributeid) REFERENCES public.trackedentityattribute(trackedentityattributeid);


--
-- Name: fk_trackedentitytypeattribute_trackedentitytypeid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.trackedentitytypeattribute
    ADD CONSTRAINT fk_trackedentitytypeattribute_trackedentitytypeid FOREIGN KEY (trackedentitytypeid) REFERENCES public.trackedentitytype(trackedentitytypeid);


--
-- Name: fk_user_userid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT fk_user_userid FOREIGN KEY (creatoruserid) REFERENCES public.userinfo(userinfoid);


--
-- Name: fk_user_userinfoid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT fk_user_userinfoid FOREIGN KEY (userid) REFERENCES public.userinfo(userinfoid);


--
-- Name: fk_useraccess_user; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.useraccess
    ADD CONSTRAINT fk_useraccess_user FOREIGN KEY (userid) REFERENCES public.userinfo(userinfoid);


--
-- Name: fk_userapps_userinfoid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.userapps
    ADD CONSTRAINT fk_userapps_userinfoid FOREIGN KEY (userinfoid) REFERENCES public.userinfo(userinfoid);


--
-- Name: fk_userdatavieworgunits_organisationunitid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.userdatavieworgunits
    ADD CONSTRAINT fk_userdatavieworgunits_organisationunitid FOREIGN KEY (organisationunitid) REFERENCES public.organisationunit(organisationunitid);


--
-- Name: fk_userdatavieworgunits_userinfoid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.userdatavieworgunits
    ADD CONSTRAINT fk_userdatavieworgunits_userinfoid FOREIGN KEY (userinfoid) REFERENCES public.userinfo(userinfoid);


--
-- Name: fk_usergroup_userid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.usergroup
    ADD CONSTRAINT fk_usergroup_userid FOREIGN KEY (userid) REFERENCES public.userinfo(userinfoid);


--
-- Name: fk_usergroupaccess_usergroup; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.usergroupaccess
    ADD CONSTRAINT fk_usergroupaccess_usergroup FOREIGN KEY (usergroupid) REFERENCES public.usergroup(usergroupid);


--
-- Name: fk_usergroupmanaging_managedbygroupid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.usergroupmanaged
    ADD CONSTRAINT fk_usergroupmanaging_managedbygroupid FOREIGN KEY (managedbygroupid) REFERENCES public.usergroup(usergroupid);


--
-- Name: fk_usergroupmanaging_managedgroupid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.usergroupmanaged
    ADD CONSTRAINT fk_usergroupmanaging_managedgroupid FOREIGN KEY (managedgroupid) REFERENCES public.usergroup(usergroupid);


--
-- Name: fk_usergroupmembers_usergroupid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.usergroupmembers
    ADD CONSTRAINT fk_usergroupmembers_usergroupid FOREIGN KEY (usergroupid) REFERENCES public.usergroup(usergroupid);


--
-- Name: fk_usergroupmembers_userid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.usergroupmembers
    ADD CONSTRAINT fk_usergroupmembers_userid FOREIGN KEY (userid) REFERENCES public.userinfo(userinfoid);


--
-- Name: fk_userinfo_organisationunitid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.usermembership
    ADD CONSTRAINT fk_userinfo_organisationunitid FOREIGN KEY (organisationunitid) REFERENCES public.organisationunit(organisationunitid);


--
-- Name: fk_userkeyjsonvalue_user; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.userkeyjsonvalue
    ADD CONSTRAINT fk_userkeyjsonvalue_user FOREIGN KEY (userid) REFERENCES public.userinfo(userinfoid);


--
-- Name: fk_usermembership_userinfoid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.usermembership
    ADD CONSTRAINT fk_usermembership_userinfoid FOREIGN KEY (userinfoid) REFERENCES public.userinfo(userinfoid);


--
-- Name: fk_usermessage_user; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.usermessage
    ADD CONSTRAINT fk_usermessage_user FOREIGN KEY (userid) REFERENCES public.userinfo(userinfoid);


--
-- Name: fk_userrole_userid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.userrole
    ADD CONSTRAINT fk_userrole_userid FOREIGN KEY (userid) REFERENCES public.userinfo(userinfoid);


--
-- Name: fk_userroleauthorities_userroleid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.userroleauthorities
    ADD CONSTRAINT fk_userroleauthorities_userroleid FOREIGN KEY (userroleid) REFERENCES public.userrole(userroleid);


--
-- Name: fk_userrolemembers_userid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.userrolemembers
    ADD CONSTRAINT fk_userrolemembers_userid FOREIGN KEY (userid) REFERENCES public.users(userid);


--
-- Name: fk_userrolemembers_userroleid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.userrolemembers
    ADD CONSTRAINT fk_userrolemembers_userroleid FOREIGN KEY (userroleid) REFERENCES public.userrole(userroleid);


--
-- Name: fk_users_catconstraints_userid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users_catdimensionconstraints
    ADD CONSTRAINT fk_users_catconstraints_userid FOREIGN KEY (userid) REFERENCES public.users(userid);


--
-- Name: fk_users_cogsconstraints_userid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users_cogsdimensionconstraints
    ADD CONSTRAINT fk_users_cogsconstraints_userid FOREIGN KEY (userid) REFERENCES public.users(userid);


--
-- Name: fk_usersetting_userinfoid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.usersetting
    ADD CONSTRAINT fk_usersetting_userinfoid FOREIGN KEY (userinfoid) REFERENCES public.userinfo(userinfoid);


--
-- Name: fk_userteisearchorgunits_organisationunitid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.userteisearchorgunits
    ADD CONSTRAINT fk_userteisearchorgunits_organisationunitid FOREIGN KEY (organisationunitid) REFERENCES public.organisationunit(organisationunitid);


--
-- Name: fk_userteisearchorgunits_userinfoid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.userteisearchorgunits
    ADD CONSTRAINT fk_userteisearchorgunits_userinfoid FOREIGN KEY (userinfoid) REFERENCES public.userinfo(userinfoid);


--
-- Name: fk_validationnotificationtemplate_usergroup; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.validationnotificationtemplate_recipientusergroups
    ADD CONSTRAINT fk_validationnotificationtemplate_usergroup FOREIGN KEY (validationnotificationtemplateid) REFERENCES public.validationnotificationtemplate(validationnotificationtemplateid);


--
-- Name: fk_validationresult_attributeoptioncomboid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.validationresult
    ADD CONSTRAINT fk_validationresult_attributeoptioncomboid FOREIGN KEY (attributeoptioncomboid) REFERENCES public.categoryoptioncombo(categoryoptioncomboid);


--
-- Name: fk_validationresult_organisationunitid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.validationresult
    ADD CONSTRAINT fk_validationresult_organisationunitid FOREIGN KEY (organisationunitid) REFERENCES public.organisationunit(organisationunitid);


--
-- Name: fk_validationresult_period; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.validationresult
    ADD CONSTRAINT fk_validationresult_period FOREIGN KEY (periodid) REFERENCES public.period(periodid);


--
-- Name: fk_validationresult_validationruleid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.validationresult
    ADD CONSTRAINT fk_validationresult_validationruleid FOREIGN KEY (validationruleid) REFERENCES public.validationrule(validationruleid);


--
-- Name: fk_validationrule_leftexpressionid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.validationrule
    ADD CONSTRAINT fk_validationrule_leftexpressionid FOREIGN KEY (leftexpressionid) REFERENCES public.expression(expressionid);


--
-- Name: fk_validationrule_periodtypeid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.predictor
    ADD CONSTRAINT fk_validationrule_periodtypeid FOREIGN KEY (periodtypeid) REFERENCES public.periodtype(periodtypeid);


--
-- Name: fk_validationrule_periodtypeid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.validationrule
    ADD CONSTRAINT fk_validationrule_periodtypeid FOREIGN KEY (periodtypeid) REFERENCES public.periodtype(periodtypeid);


--
-- Name: fk_validationrule_rightexpressionid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.validationrule
    ADD CONSTRAINT fk_validationrule_rightexpressionid FOREIGN KEY (rightexpressionid) REFERENCES public.expression(expressionid);


--
-- Name: fk_validationrule_skiptestexpressionid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.predictor
    ADD CONSTRAINT fk_validationrule_skiptestexpressionid FOREIGN KEY (skiptestexpressionid) REFERENCES public.expression(expressionid);


--
-- Name: fk_validationrule_userid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.validationrule
    ADD CONSTRAINT fk_validationrule_userid FOREIGN KEY (userid) REFERENCES public.userinfo(userinfoid);


--
-- Name: fk_validationrule_validationnotificationtemplateid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.validationnotificationtemplatevalidationrules
    ADD CONSTRAINT fk_validationrule_validationnotificationtemplateid FOREIGN KEY (validationruleid) REFERENCES public.validationrule(validationruleid);


--
-- Name: fk_validationrulegroup_userid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.validationrulegroup
    ADD CONSTRAINT fk_validationrulegroup_userid FOREIGN KEY (userid) REFERENCES public.userinfo(userinfoid);


--
-- Name: fk_validationrulegroup_validationruleid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.validationrulegroupmembers
    ADD CONSTRAINT fk_validationrulegroup_validationruleid FOREIGN KEY (validationruleid) REFERENCES public.validationrule(validationruleid);


--
-- Name: fk_validationrulegroupmembers_validationrulegroupid; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.validationrulegroupmembers
    ADD CONSTRAINT fk_validationrulegroupmembers_validationrulegroupid FOREIGN KEY (validationgroupid) REFERENCES public.validationrulegroup(validationrulegroupid);


--
-- Name: fka4dwo79bmu0cjtqeqgclj4d42; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.constantattributevalues
    ADD CONSTRAINT fka4dwo79bmu0cjtqeqgclj4d42 FOREIGN KEY (attributevalueid) REFERENCES public.attributevalue(attributevalueid);


--
-- Name: fka5vwhm9044o3r2mlf7wmkvoka; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dataelementgroupsetusergroupaccesses
    ADD CONSTRAINT fka5vwhm9044o3r2mlf7wmkvoka FOREIGN KEY (usergroupaccessid) REFERENCES public.usergroupaccess(usergroupaccessid);


--
-- Name: fka8e7rdhv12fyvkl84wk5qs55q; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.attributeuseraccesses
    ADD CONSTRAINT fka8e7rdhv12fyvkl84wk5qs55q FOREIGN KEY (useraccessid) REFERENCES public.useraccess(useraccessid);


--
-- Name: fkaena7oeseunp4n3lpltyirxy7; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.trackedentityattributeuseraccesses
    ADD CONSTRAINT fkaena7oeseunp4n3lpltyirxy7 FOREIGN KEY (useraccessid) REFERENCES public.useraccess(useraccessid);


--
-- Name: fkaew232hpstgwmojawelwlvejm; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dashboarduseraccesses
    ADD CONSTRAINT fkaew232hpstgwmojawelwlvejm FOREIGN KEY (dashboardid) REFERENCES public.dashboard(dashboardid);


--
-- Name: fkagpfc3qen3mlu9y8w187rnw8y; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.optiongroupsetuseraccesses
    ADD CONSTRAINT fkagpfc3qen3mlu9y8w187rnw8y FOREIGN KEY (useraccessid) REFERENCES public.useraccess(useraccessid);


--
-- Name: fkamp4mkfqkkmhhmgjygkmtjpip; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.categoryoptiongroupusergroupaccesses
    ADD CONSTRAINT fkamp4mkfqkkmhhmgjygkmtjpip FOREIGN KEY (categoryoptiongroupid) REFERENCES public.categoryoptiongroup(categoryoptiongroupid);


--
-- Name: fkapnobox9g47rnrrf9wtjkaevy; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.documenttranslations
    ADD CONSTRAINT fkapnobox9g47rnrrf9wtjkaevy FOREIGN KEY (objecttranslationid) REFERENCES public.objecttranslation(objecttranslationid);


--
-- Name: fkat5c51eye5gfdskvvvgjeyiw7; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sqlviewuseraccesses
    ADD CONSTRAINT fkat5c51eye5gfdskvvvgjeyiw7 FOREIGN KEY (useraccessid) REFERENCES public.useraccess(useraccessid);


--
-- Name: fkatcq92ev29vb7yoiut5vcbw0p; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.categoryoptiongroupuseraccesses
    ADD CONSTRAINT fkatcq92ev29vb7yoiut5vcbw0p FOREIGN KEY (useraccessid) REFERENCES public.useraccess(useraccessid);


--
-- Name: fkaux0ab565allf4ria7i4yqe9o; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dataelementcategoryusergroupaccesses
    ADD CONSTRAINT fkaux0ab565allf4ria7i4yqe9o FOREIGN KEY (categoryid) REFERENCES public.dataelementcategory(categoryid);


--
-- Name: fkavox4jvxrnakb535jj5vo759s; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.orgunitgrouptranslations
    ADD CONSTRAINT fkavox4jvxrnakb535jj5vo759s FOREIGN KEY (objecttranslationid) REFERENCES public.objecttranslation(objecttranslationid);


--
-- Name: fkb2kr43ae9gkca8whshqtucs19; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dataapprovalleveluseraccesses
    ADD CONSTRAINT fkb2kr43ae9gkca8whshqtucs19 FOREIGN KEY (useraccessid) REFERENCES public.useraccess(useraccessid);


--
-- Name: fkb2m7919n599yobujaf6sbwkos; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dataapprovalleveluseraccesses
    ADD CONSTRAINT fkb2m7919n599yobujaf6sbwkos FOREIGN KEY (dataapprovallevelid) REFERENCES public.dataapprovallevel(dataapprovallevelid);


--
-- Name: fkb3i0kpxkt0oyh0pori98xj6f; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sqlviewusergroupaccesses
    ADD CONSTRAINT fkb3i0kpxkt0oyh0pori98xj6f FOREIGN KEY (usergroupaccessid) REFERENCES public.usergroupaccess(usergroupaccessid);


--
-- Name: fkb8c0sfajb4r29mb76o4o59850; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.trackedentityattributeattributevalues
    ADD CONSTRAINT fkb8c0sfajb4r29mb76o4o59850 FOREIGN KEY (trackedentityattributeid) REFERENCES public.trackedentityattribute(trackedentityattributeid);


--
-- Name: fkbarqjic704pntxy612aapkr53; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sqlviewuseraccesses
    ADD CONSTRAINT fkbarqjic704pntxy612aapkr53 FOREIGN KEY (sqlviewid) REFERENCES public.sqlview(sqlviewid);


--
-- Name: fkbcijpkvi3rcx4nupghfqtpds3; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.categoryoptioncombotranslations
    ADD CONSTRAINT fkbcijpkvi3rcx4nupghfqtpds3 FOREIGN KEY (objecttranslationid) REFERENCES public.objecttranslation(objecttranslationid);


--
-- Name: fkbfhtgn2aicjte21pj8qg6qqu4; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.categorycombouseraccesses
    ADD CONSTRAINT fkbfhtgn2aicjte21pj8qg6qqu4 FOREIGN KEY (categorycomboid) REFERENCES public.categorycombo(categorycomboid);


--
-- Name: fkbgaeqkluhopo8umxl265vmun7; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.reporttableuseraccesses
    ADD CONSTRAINT fkbgaeqkluhopo8umxl265vmun7 FOREIGN KEY (reporttableid) REFERENCES public.reporttable(reporttableid);


--
-- Name: fkbm0pqhdj9xudinnssoxjdgq6b; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.programstageusergroupaccesses
    ADD CONSTRAINT fkbm0pqhdj9xudinnssoxjdgq6b FOREIGN KEY (programid) REFERENCES public.programstage(programstageid);


--
-- Name: fkbmhr9ethpu50qckrga381i6cy; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dataelementattributevalues
    ADD CONSTRAINT fkbmhr9ethpu50qckrga381i6cy FOREIGN KEY (dataelementid) REFERENCES public.dataelement(dataelementid);


--
-- Name: fkbp9e1cf4kup4bfwa53kqhmhpe; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.reporttabletranslations
    ADD CONSTRAINT fkbp9e1cf4kup4bfwa53kqhmhpe FOREIGN KEY (objecttranslationid) REFERENCES public.objecttranslation(objecttranslationid);


--
-- Name: fkbqtw7paqqiuor7kenyjjjkiwv; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.documentusergroupaccesses
    ADD CONSTRAINT fkbqtw7paqqiuor7kenyjjjkiwv FOREIGN KEY (documentid) REFERENCES public.document(documentid);


--
-- Name: fkbrsplevygf9yr4hvydhix39ug; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dataelementlegendsets
    ADD CONSTRAINT fkbrsplevygf9yr4hvydhix39ug FOREIGN KEY (dataelementid) REFERENCES public.dataelement(dataelementid);


--
-- Name: fkbvcollq94hbv2kkjvbjhbklxi; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dataelementcategoryoptionusergroupaccesses
    ADD CONSTRAINT fkbvcollq94hbv2kkjvbjhbklxi FOREIGN KEY (usergroupaccessid) REFERENCES public.usergroupaccess(usergroupaccessid);


--
-- Name: fkbve6kfglt0ik8f9a3yw45hwnj; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.validationrulegrouptranslations
    ADD CONSTRAINT fkbve6kfglt0ik8f9a3yw45hwnj FOREIGN KEY (objecttranslationid) REFERENCES public.objecttranslation(objecttranslationid);


--
-- Name: fkbyaw75hj8du8w14hpuhxj762w; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.programmessage_emailaddresses
    ADD CONSTRAINT fkbyaw75hj8du8w14hpuhxj762w FOREIGN KEY (programmessageemailaddressid) REFERENCES public.programmessage(id);


--
-- Name: fkc42pvyyurx18c7g8x1or92x6; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.optiongroupuseraccesses
    ADD CONSTRAINT fkc42pvyyurx18c7g8x1or92x6 FOREIGN KEY (useraccessid) REFERENCES public.useraccess(useraccessid);


--
-- Name: fkc466epp3jve9b0lpavgxocse4; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dashboardtranslations
    ADD CONSTRAINT fkc466epp3jve9b0lpavgxocse4 FOREIGN KEY (objecttranslationid) REFERENCES public.objecttranslation(objecttranslationid);


--
-- Name: fkc5hdg6ruv7glmp88j6ohkvxgu; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.datasetusergroupaccesses
    ADD CONSTRAINT fkc5hdg6ruv7glmp88j6ohkvxgu FOREIGN KEY (usergroupaccessid) REFERENCES public.usergroupaccess(usergroupaccessid);


--
-- Name: fkc5w6s58ykqw8gf6h8oxinq1p1; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.categoryoptiongroupsetusergroupaccesses
    ADD CONSTRAINT fkc5w6s58ykqw8gf6h8oxinq1p1 FOREIGN KEY (categoryoptiongroupsetid) REFERENCES public.categoryoptiongroupset(categoryoptiongroupsetid);


--
-- Name: fkc6ae9oxts83ohrx20gxjoo2o4; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.categoryoptioncomboattributevalues
    ADD CONSTRAINT fkc6ae9oxts83ohrx20gxjoo2o4 FOREIGN KEY (categoryoptioncomboid) REFERENCES public.categoryoptioncombo(categoryoptioncomboid);


--
-- Name: fkc6ibwny8jp0hq6l6w0w2untt4; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.smscommandcodes
    ADD CONSTRAINT fkc6ibwny8jp0hq6l6w0w2untt4 FOREIGN KEY (id) REFERENCES public.smscommands(smscommandid);


--
-- Name: fkc7eve8dbu1difp790efea7rs4; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.categorycombouseraccesses
    ADD CONSTRAINT fkc7eve8dbu1difp790efea7rs4 FOREIGN KEY (useraccessid) REFERENCES public.useraccess(useraccessid);


--
-- Name: fkccl4gw7l7hxrfgqa2hqnvxlkq; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dataapprovallevelusergroupaccesses
    ADD CONSTRAINT fkccl4gw7l7hxrfgqa2hqnvxlkq FOREIGN KEY (usergroupaccessid) REFERENCES public.usergroupaccess(usergroupaccessid);


--
-- Name: fkcco3y9joqwitwh2mdrq2svakg; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dataelementgroupsetusergroupaccesses
    ADD CONSTRAINT fkcco3y9joqwitwh2mdrq2svakg FOREIGN KEY (dataelementgroupsetid) REFERENCES public.dataelementgroupset(dataelementgroupsetid);


--
-- Name: fkcd7hsom4yeetyooplbn496t76; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.validationruletranslations
    ADD CONSTRAINT fkcd7hsom4yeetyooplbn496t76 FOREIGN KEY (objecttranslationid) REFERENCES public.objecttranslation(objecttranslationid);


--
-- Name: fkcdkajbb0rpnpwuo57i894s0dg; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.trackedentityattributelegendsets
    ADD CONSTRAINT fkcdkajbb0rpnpwuo57i894s0dg FOREIGN KEY (trackedentityattributeid) REFERENCES public.trackedentityattribute(trackedentityattributeid);


--
-- Name: fkch98ncn24f71dft102f7of537; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.smscommandspecialcharacters
    ADD CONSTRAINT fkch98ncn24f71dft102f7of537 FOREIGN KEY (smscommandid) REFERENCES public.smscommands(smscommandid);


--
-- Name: fkci0bfpwjo9komus48g0w5vo6r; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.orgunitleveltranslations
    ADD CONSTRAINT fkci0bfpwjo9komus48g0w5vo6r FOREIGN KEY (objecttranslationid) REFERENCES public.objecttranslation(objecttranslationid);


--
-- Name: fkcljbikjrhndoo16muyolfar3n; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.chartuseraccesses
    ADD CONSTRAINT fkcljbikjrhndoo16muyolfar3n FOREIGN KEY (chartid) REFERENCES public.chart(chartid);


--
-- Name: fkcmnb6cbqwkgn6yl4ojsfapy4t; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dataelementcategorytranslations
    ADD CONSTRAINT fkcmnb6cbqwkgn6yl4ojsfapy4t FOREIGN KEY (objecttranslationid) REFERENCES public.objecttranslation(objecttranslationid);


--
-- Name: fkcoo6svgtx8pre5fabnjuyhgpf; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.organisationunitattributevalues
    ADD CONSTRAINT fkcoo6svgtx8pre5fabnjuyhgpf FOREIGN KEY (attributevalueid) REFERENCES public.attributevalue(attributevalueid);


--
-- Name: fkctrs1ehqub6785ojlihki52eh; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.userroleuseraccesses
    ADD CONSTRAINT fkctrs1ehqub6785ojlihki52eh FOREIGN KEY (useraccessid) REFERENCES public.useraccess(useraccessid);


--
-- Name: fkd8f9hmgonr1f04lom1pwg2td5; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.documentusergroupaccesses
    ADD CONSTRAINT fkd8f9hmgonr1f04lom1pwg2td5 FOREIGN KEY (usergroupaccessid) REFERENCES public.usergroupaccess(usergroupaccessid);


--
-- Name: fkdaq0s179v2imf215hn3b7kpdp; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.trackedentitytypeusergroupaccesses
    ADD CONSTRAINT fkdaq0s179v2imf215hn3b7kpdp FOREIGN KEY (trackedentitytypeid) REFERENCES public.trackedentitytype(trackedentitytypeid);


--
-- Name: fkdawo044shd3vyrgeqhlbp83h; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.colortranslations
    ADD CONSTRAINT fkdawo044shd3vyrgeqhlbp83h FOREIGN KEY (objecttranslationid) REFERENCES public.objecttranslation(objecttranslationid);


--
-- Name: fkdb0p44e9kub3gakn0bn39v47e; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.categorycombotranslations
    ADD CONSTRAINT fkdb0p44e9kub3gakn0bn39v47e FOREIGN KEY (objecttranslationid) REFERENCES public.objecttranslation(objecttranslationid);


--
-- Name: fkdba2e0q8kva3oiigmfjujmc09; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.indicatorattributevalues
    ADD CONSTRAINT fkdba2e0q8kva3oiigmfjujmc09 FOREIGN KEY (indicatorid) REFERENCES public.indicator(indicatorid);


--
-- Name: fkdc4xtxb8tk28tg8gihya0f8t3; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dataapprovalworkflowusergroupaccesses
    ADD CONSTRAINT fkdc4xtxb8tk28tg8gihya0f8t3 FOREIGN KEY (workflowid) REFERENCES public.dataapprovalworkflow(workflowid);


--
-- Name: fkdfoid1s8be97lj4d0dq0wn2h9; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dataelementusergroupaccesses
    ADD CONSTRAINT fkdfoid1s8be97lj4d0dq0wn2h9 FOREIGN KEY (dataelementid) REFERENCES public.dataelement(dataelementid);


--
-- Name: fkdk6whdv75o0d1kwveyfm7fo0i; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.trackedentitytypeuseraccesses
    ADD CONSTRAINT fkdk6whdv75o0d1kwveyfm7fo0i FOREIGN KEY (useraccessid) REFERENCES public.useraccess(useraccessid);


--
-- Name: fkdmc46bnsqath7p6mrsrb89eml; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.programstageinstance_messageconversation
    ADD CONSTRAINT fkdmc46bnsqath7p6mrsrb89eml FOREIGN KEY (messageconversationid) REFERENCES public.messageconversation(messageconversationid);


--
-- Name: fkdmiv8bdyjs0sj5bgltqmync3q; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.mapuseraccesses
    ADD CONSTRAINT fkdmiv8bdyjs0sj5bgltqmync3q FOREIGN KEY (useraccessid) REFERENCES public.useraccess(useraccessid);


--
-- Name: fkdmqfyfhml5bjunjsvdur0trxy; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.reportuseraccesses
    ADD CONSTRAINT fkdmqfyfhml5bjunjsvdur0trxy FOREIGN KEY (reportid) REFERENCES public.report(reportid);


--
-- Name: fkdudfflo1n7r4iuyqxba1b4ovi; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dataelementcategoryoptionusergroupaccesses
    ADD CONSTRAINT fkdudfflo1n7r4iuyqxba1b4ovi FOREIGN KEY (categoryoptionid) REFERENCES public.dataelementcategoryoption(categoryoptionid);


--
-- Name: fkdx9fhldp5xt6quko76j4d8kk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.optionsetusergroupaccesses
    ADD CONSTRAINT fkdx9fhldp5xt6quko76j4d8kk FOREIGN KEY (optionsetid) REFERENCES public.optionset(optionsetid);


--
-- Name: fke1eymlpayuhawlo8pfuwue654; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.smscommandcodes
    ADD CONSTRAINT fke1eymlpayuhawlo8pfuwue654 FOREIGN KEY (codeid) REFERENCES public.smscodes(smscodeid);


--
-- Name: fke2q9lkr609pqg1b0ydm0rowtm; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.programindicatorgroupattributevalues
    ADD CONSTRAINT fke2q9lkr609pqg1b0ydm0rowtm FOREIGN KEY (attributevalueid) REFERENCES public.attributevalue(attributevalueid);


--
-- Name: fke9a9ot5uw06v8xysffntqn163; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.reporttableusergroupaccesses
    ADD CONSTRAINT fke9a9ot5uw06v8xysffntqn163 FOREIGN KEY (usergroupaccessid) REFERENCES public.usergroupaccess(usergroupaccessid);


--
-- Name: fked5a3idn9xy17kqh044r4khnq; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.validationrulegroupuseraccesses
    ADD CONSTRAINT fked5a3idn9xy17kqh044r4khnq FOREIGN KEY (useraccessid) REFERENCES public.useraccess(useraccessid);


--
-- Name: fkehrkml89lh7kv1bmutotucsjm; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.programindicatorgroupusergroupaccesses
    ADD CONSTRAINT fkehrkml89lh7kv1bmutotucsjm FOREIGN KEY (programindicatorgroupid) REFERENCES public.programindicatorgroup(programindicatorgroupid);


--
-- Name: fken6g44y648k1fembweltcao3e; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.datasetnotification_datasets
    ADD CONSTRAINT fken6g44y648k1fembweltcao3e FOREIGN KEY (datasetid) REFERENCES public.dataset(datasetid);


--
-- Name: fker1uvlubbi174wihftcmjqwah; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.programindicatorgrouptranslations
    ADD CONSTRAINT fker1uvlubbi174wihftcmjqwah FOREIGN KEY (objecttranslationid) REFERENCES public.objecttranslation(objecttranslationid);


--
-- Name: fkeu7sin6er3x3kuhtbqys9bbqt; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.documentuseraccesses
    ADD CONSTRAINT fkeu7sin6er3x3kuhtbqys9bbqt FOREIGN KEY (documentid) REFERENCES public.document(documentid);


--
-- Name: fkeuett3yqyqms2edpep4g1etjd; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.reportusergroupaccesses
    ADD CONSTRAINT fkeuett3yqyqms2edpep4g1etjd FOREIGN KEY (reportid) REFERENCES public.report(reportid);


--
-- Name: fkf97c7k1pwvp39tdx1ehrwywxp; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.externalmaplayerusergroupaccesses
    ADD CONSTRAINT fkf97c7k1pwvp39tdx1ehrwywxp FOREIGN KEY (usergroupaccessid) REFERENCES public.usergroupaccess(usergroupaccessid);


--
-- Name: fkfamquh0yxd74tj2thpnxll8qd; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.optionsetusergroupaccesses
    ADD CONSTRAINT fkfamquh0yxd74tj2thpnxll8qd FOREIGN KEY (usergroupaccessid) REFERENCES public.usergroupaccess(usergroupaccessid);


--
-- Name: fkfgbg6qcks2bxagux2nqwl6mam; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.interpretationuseraccesses
    ADD CONSTRAINT fkfgbg6qcks2bxagux2nqwl6mam FOREIGN KEY (interpretationid) REFERENCES public.interpretation(interpretationid);


--
-- Name: fkfju7l9tdk4vuit5y3mw3pmfdp; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.datasetusergroupaccesses
    ADD CONSTRAINT fkfju7l9tdk4vuit5y3mw3pmfdp FOREIGN KEY (datasetid) REFERENCES public.dataset(datasetid);


--
-- Name: fkftog7iowqys99f34vxtwvhclx; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dataelementgroupsetuseraccesses
    ADD CONSTRAINT fkftog7iowqys99f34vxtwvhclx FOREIGN KEY (dataelementgroupsetid) REFERENCES public.dataelementgroupset(dataelementgroupsetid);


--
-- Name: fkfysoq9tcj6k0g942tni0p91sn; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.categoryoptiongroupsettranslations
    ADD CONSTRAINT fkfysoq9tcj6k0g942tni0p91sn FOREIGN KEY (objecttranslationid) REFERENCES public.objecttranslation(objecttranslationid);


--
-- Name: fkg6n5kwuhypwdvkn15ke824kpb; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.previouspasswords
    ADD CONSTRAINT fkg6n5kwuhypwdvkn15ke824kpb FOREIGN KEY (userid) REFERENCES public.users(userid);


--
-- Name: fkgb55kdvtf92qykh2840inyhst; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.program_userroles
    ADD CONSTRAINT fkgb55kdvtf92qykh2840inyhst FOREIGN KEY (programid) REFERENCES public.program(programid);


--
-- Name: fkgf3l6blh1evu8cbbfdel3dap; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.categoryoptiontranslations
    ADD CONSTRAINT fkgf3l6blh1evu8cbbfdel3dap FOREIGN KEY (objecttranslationid) REFERENCES public.objecttranslation(objecttranslationid);


--
-- Name: fkgq38c88dd0nqfrxbdlxj95gkn; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dashboarditemtranslations
    ADD CONSTRAINT fkgq38c88dd0nqfrxbdlxj95gkn FOREIGN KEY (objecttranslationid) REFERENCES public.objecttranslation(objecttranslationid);


--
-- Name: fkgscric80wkt82kyxdc4gvv030; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.validationruleuseraccesses
    ADD CONSTRAINT fkgscric80wkt82kyxdc4gvv030 FOREIGN KEY (useraccessid) REFERENCES public.useraccess(useraccessid);


--
-- Name: fkgvdx3u8ymbvq3mfr0qih7kbgl; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.categoryoptioncomboattributevalues
    ADD CONSTRAINT fkgvdx3u8ymbvq3mfr0qih7kbgl FOREIGN KEY (attributevalueid) REFERENCES public.attributevalue(attributevalueid);


--
-- Name: fkh063grx17s8wbufgi6rmb2qj9; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dataelementattributevalues
    ADD CONSTRAINT fkh063grx17s8wbufgi6rmb2qj9 FOREIGN KEY (attributevalueid) REFERENCES public.attributevalue(attributevalueid);


--
-- Name: fkh7rgh9ccjygftu2um7bt8o15w; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.optionsetattributevalues
    ADD CONSTRAINT fkh7rgh9ccjygftu2um7bt8o15w FOREIGN KEY (optionsetid) REFERENCES public.optionset(optionsetid);


--
-- Name: fkh8a8f65qyvb9ht8218fbqif3r; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.userroleusergroupaccesses
    ADD CONSTRAINT fkh8a8f65qyvb9ht8218fbqif3r FOREIGN KEY (userroleid) REFERENCES public.userrole(userroleid);


--
-- Name: fkhcb8xpki59p7up71arpcj6mgo; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.categorycombousergroupaccesses
    ADD CONSTRAINT fkhcb8xpki59p7up71arpcj6mgo FOREIGN KEY (usergroupaccessid) REFERENCES public.usergroupaccess(usergroupaccessid);


--
-- Name: fkhdb5bwj85vxienykc71k0h6gb; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.optionvaluetranslations
    ADD CONSTRAINT fkhdb5bwj85vxienykc71k0h6gb FOREIGN KEY (objecttranslationid) REFERENCES public.objecttranslation(objecttranslationid);


--
-- Name: fkhlhawnoj4iw21if6whyjhyuxx; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.eventreportusergroupaccesses
    ADD CONSTRAINT fkhlhawnoj4iw21if6whyjhyuxx FOREIGN KEY (eventreportid) REFERENCES public.eventreport(eventreportid);


--
-- Name: fkhmb8frud8xu70up73bpnbfpf8; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.validationruleusergroupaccesses
    ADD CONSTRAINT fkhmb8frud8xu70up73bpnbfpf8 FOREIGN KEY (usergroupaccessid) REFERENCES public.usergroupaccess(usergroupaccessid);


--
-- Name: fkhqi75xl3pvjqhvg2ffkapse5b; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dataelementgroupuseraccesses
    ADD CONSTRAINT fkhqi75xl3pvjqhvg2ffkapse5b FOREIGN KEY (dataelementgroupid) REFERENCES public.dataelementgroup(dataelementgroupid);


--
-- Name: fkhrmc5b26i4fv714agdvwm2tly; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.programstageusergroupaccesses
    ADD CONSTRAINT fkhrmc5b26i4fv714agdvwm2tly FOREIGN KEY (usergroupaccessid) REFERENCES public.usergroupaccess(usergroupaccessid);


--
-- Name: fkhsktcf5wolfqpbjum1h8mjlg0; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.attributeusergroupaccesses
    ADD CONSTRAINT fkhsktcf5wolfqpbjum1h8mjlg0 FOREIGN KEY (usergroupaccessid) REFERENCES public.usergroupaccess(usergroupaccessid);


--
-- Name: fki0jsa3ibpqnmf9f6a079yvqg1; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.optionattributevalues
    ADD CONSTRAINT fki0jsa3ibpqnmf9f6a079yvqg1 FOREIGN KEY (optionvalueid) REFERENCES public.optionvalue(optionvalueid);


--
-- Name: fki3c4derc037s8706gc29tn72y; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.legendsetuseraccesses
    ADD CONSTRAINT fki3c4derc037s8706gc29tn72y FOREIGN KEY (maplegendsetid) REFERENCES public.maplegendset(maplegendsetid);


--
-- Name: fkibpy72i2p9nfkdtqqe6my34nr; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pushanalysis
    ADD CONSTRAINT fkibpy72i2p9nfkdtqqe6my34nr FOREIGN KEY (dashboard) REFERENCES public.dashboard(dashboardid);


--
-- Name: fkiev77xq3u50tnxter17midwpk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.documentuseraccesses
    ADD CONSTRAINT fkiev77xq3u50tnxter17midwpk FOREIGN KEY (useraccessid) REFERENCES public.useraccess(useraccessid);


--
-- Name: fkijpqu28mpafr0wbgu2p4qs2ys; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.optiongroupattributevalues
    ADD CONSTRAINT fkijpqu28mpafr0wbgu2p4qs2ys FOREIGN KEY (attributevalueid) REFERENCES public.attributevalue(attributevalueid);


--
-- Name: fkikavm35a9xngxxqnaonnmk7yw; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.categoryoptiongroupattributevalues
    ADD CONSTRAINT fkikavm35a9xngxxqnaonnmk7yw FOREIGN KEY (attributevalueid) REFERENCES public.attributevalue(attributevalueid);


--
-- Name: fkilna5etu4xlgyf93sguvt6e6s; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.programindicatorattributevalues
    ADD CONSTRAINT fkilna5etu4xlgyf93sguvt6e6s FOREIGN KEY (attributevalueid) REFERENCES public.attributevalue(attributevalueid);


--
-- Name: fkisircfmtwyf4f63ci19fi4i8l; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.orgunitgroupsetattributevalues
    ADD CONSTRAINT fkisircfmtwyf4f63ci19fi4i8l FOREIGN KEY (attributevalueid) REFERENCES public.attributevalue(attributevalueid);


--
-- Name: fkj16b2115543s4odxcl034keuj; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.documentattributevalues
    ADD CONSTRAINT fkj16b2115543s4odxcl034keuj FOREIGN KEY (documentid) REFERENCES public.document(documentid);


--
-- Name: fkj3dr5vrqclcaodu7x4rm1qsbo; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.programinstance_messageconversation
    ADD CONSTRAINT fkj3dr5vrqclcaodu7x4rm1qsbo FOREIGN KEY (programinstanceid) REFERENCES public.programinstance(programinstanceid);


--
-- Name: fkj5qrssmmg27bp6i8vb391kwin; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.indicatoruseraccesses
    ADD CONSTRAINT fkj5qrssmmg27bp6i8vb391kwin FOREIGN KEY (indicatorid) REFERENCES public.indicator(indicatorid);


--
-- Name: fkjdlf4yqax04d3krscjtucfjv0; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dataelementuseraccesses
    ADD CONSTRAINT fkjdlf4yqax04d3krscjtucfjv0 FOREIGN KEY (dataelementid) REFERENCES public.dataelement(dataelementid);


--
-- Name: fkjl1fwmeghy7xswjxuin4bb5t9; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.indicatorgroupuseraccesses
    ADD CONSTRAINT fkjl1fwmeghy7xswjxuin4bb5t9 FOREIGN KEY (indicatorgroupid) REFERENCES public.indicatorgroup(indicatorgroupid);


--
-- Name: fkjmtfdehdm5kixd7fxidajbqpt; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dataelementgroupsettranslations
    ADD CONSTRAINT fkjmtfdehdm5kixd7fxidajbqpt FOREIGN KEY (objecttranslationid) REFERENCES public.objecttranslation(objecttranslationid);


--
-- Name: fkjp6o40q5mb5a9fixiaqxf6dur; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dataelementcategoryoptionattributevalues
    ADD CONSTRAINT fkjp6o40q5mb5a9fixiaqxf6dur FOREIGN KEY (attributevalueid) REFERENCES public.attributevalue(attributevalueid);


--
-- Name: fkjtpyr15khpfwyeljjblln3amh; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.indicatorgroupattributevalues
    ADD CONSTRAINT fkjtpyr15khpfwyeljjblln3amh FOREIGN KEY (indicatorgroupid) REFERENCES public.indicatorgroup(indicatorgroupid);


--
-- Name: fkjuv8jwcqjrp9u60ca0b9secwe; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.optiongroupsetusergroupaccesses
    ADD CONSTRAINT fkjuv8jwcqjrp9u60ca0b9secwe FOREIGN KEY (usergroupaccessid) REFERENCES public.usergroupaccess(usergroupaccessid);


--
-- Name: fkjwscshsefl3u0p4e1829sgdyr; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.attributeuseraccesses
    ADD CONSTRAINT fkjwscshsefl3u0p4e1829sgdyr FOREIGN KEY (attributeid) REFERENCES public.attribute(attributeid);


--
-- Name: fkjy8ap861np4x3c5glxv8l8719; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.programinstance_messageconversation
    ADD CONSTRAINT fkjy8ap861np4x3c5glxv8l8719 FOREIGN KEY (messageconversationid) REFERENCES public.messageconversation(messageconversationid);


--
-- Name: fkk42gcgtiru8yc79d83vqap641; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.constantuseraccesses
    ADD CONSTRAINT fkk42gcgtiru8yc79d83vqap641 FOREIGN KEY (constantid) REFERENCES public.constant(constantid);


--
-- Name: fkk53fwmr0vsgh3pbfw1u5i7kxd; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.indicatorusergroupaccesses
    ADD CONSTRAINT fkk53fwmr0vsgh3pbfw1u5i7kxd FOREIGN KEY (indicatorid) REFERENCES public.indicator(indicatorid);


--
-- Name: fkk6vnjbcq5ypgh3xllicm8rg53; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.datasetuseraccesses
    ADD CONSTRAINT fkk6vnjbcq5ypgh3xllicm8rg53 FOREIGN KEY (useraccessid) REFERENCES public.useraccess(useraccessid);


--
-- Name: fkkao3e3ujv7mb1y45j6f31su7l; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.trackedentitytypeuseraccesses
    ADD CONSTRAINT fkkao3e3ujv7mb1y45j6f31su7l FOREIGN KEY (trackedentitytypeid) REFERENCES public.trackedentitytype(trackedentitytypeid);


--
-- Name: fkkbd9rqv83w4nwogj5fchtxj9y; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.programindicatorlegendsets
    ADD CONSTRAINT fkkbd9rqv83w4nwogj5fchtxj9y FOREIGN KEY (programindicatorid) REFERENCES public.programindicator(programindicatorid);


--
-- Name: fkkbjtmc65moywxl2yr4rkg91dc; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.indicatorgroupsetuseraccesses
    ADD CONSTRAINT fkkbjtmc65moywxl2yr4rkg91dc FOREIGN KEY (useraccessid) REFERENCES public.useraccess(useraccessid);


--
-- Name: fkkca6l1aa5y714267lpm03f6k1; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.programusergroupaccesses
    ADD CONSTRAINT fkkca6l1aa5y714267lpm03f6k1 FOREIGN KEY (usergroupaccessid) REFERENCES public.usergroupaccess(usergroupaccessid);


--
-- Name: fkkcioj9orjwbcwmdam6pj6d9o2; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.programindicatorusergroupaccesses
    ADD CONSTRAINT fkkcioj9orjwbcwmdam6pj6d9o2 FOREIGN KEY (programindicatorid) REFERENCES public.programindicator(programindicatorid);


--
-- Name: fkkgab7upiou1pws7oempk5t367; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.programtranslations
    ADD CONSTRAINT fkkgab7upiou1pws7oempk5t367 FOREIGN KEY (objecttranslationid) REFERENCES public.objecttranslation(objecttranslationid);


--
-- Name: fkkml1la4fwlysih8lrwhkvx0du; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.optionsetuseraccesses
    ADD CONSTRAINT fkkml1la4fwlysih8lrwhkvx0du FOREIGN KEY (optionsetid) REFERENCES public.optionset(optionsetid);


--
-- Name: fkknm2jjnfl49hvsruohsfapo3r; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.orgunitgroupsettranslations
    ADD CONSTRAINT fkknm2jjnfl49hvsruohsfapo3r FOREIGN KEY (objecttranslationid) REFERENCES public.objecttranslation(objecttranslationid);


--
-- Name: fkkrew00svu3k1mj9dopscffp55; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.indicatorgroupsetuseraccesses
    ADD CONSTRAINT fkkrew00svu3k1mj9dopscffp55 FOREIGN KEY (indicatorgroupsetid) REFERENCES public.indicatorgroupset(indicatorgroupsetid);


--
-- Name: fkkrh34fj5dp5gvkiokhkmwlqw4; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.legendsetuseraccesses
    ADD CONSTRAINT fkkrh34fj5dp5gvkiokhkmwlqw4 FOREIGN KEY (useraccessid) REFERENCES public.useraccess(useraccessid);


--
-- Name: fkkrhc4bbmf9jnaxj545a004fb; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.optionsetattributevalues
    ADD CONSTRAINT fkkrhc4bbmf9jnaxj545a004fb FOREIGN KEY (attributevalueid) REFERENCES public.attributevalue(attributevalueid);


--
-- Name: fkkrroom2rcrf3a83abq969085u; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.chartusergroupaccesses
    ADD CONSTRAINT fkkrroom2rcrf3a83abq969085u FOREIGN KEY (chartid) REFERENCES public.chart(chartid);


--
-- Name: fkks9i10v8xg7d22hlhmesia51l; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.programstageinstance_messageconversation
    ADD CONSTRAINT fkks9i10v8xg7d22hlhmesia51l FOREIGN KEY (programstageinstanceid) REFERENCES public.programstageinstance(programstageinstanceid);


--
-- Name: fkktmkxjuo5b3v1q2jqk7lymh0p; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.outbound_sms_recipients
    ADD CONSTRAINT fkktmkxjuo5b3v1q2jqk7lymh0p FOREIGN KEY (outbound_sms_id) REFERENCES public.outbound_sms(id);


--
-- Name: fkkvxshrhiqymj6hb2k96hscvst; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.programsectiontranslations
    ADD CONSTRAINT fkkvxshrhiqymj6hb2k96hscvst FOREIGN KEY (objecttranslationid) REFERENCES public.objecttranslation(objecttranslationid);


--
-- Name: fkkyhyiwi48ogtjvtvltk506eeh; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.reportusergroupaccesses
    ADD CONSTRAINT fkkyhyiwi48ogtjvtvltk506eeh FOREIGN KEY (usergroupaccessid) REFERENCES public.usergroupaccess(usergroupaccessid);


--
-- Name: fkl0m801gevx2jxc3tv4uh917wd; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dataelementgroupsetuseraccesses
    ADD CONSTRAINT fkl0m801gevx2jxc3tv4uh917wd FOREIGN KEY (useraccessid) REFERENCES public.useraccess(useraccessid);


--
-- Name: fkl0xk38e01qsghc0kkbykbbodo; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.orgunitgroupsetusergroupaccesses
    ADD CONSTRAINT fkl0xk38e01qsghc0kkbykbbodo FOREIGN KEY (orgunitgroupsetid) REFERENCES public.orgunitgroupset(orgunitgroupsetid);


--
-- Name: fkl8cxqyb3s8c31qbaqehu71u9e; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.constantusergroupaccesses
    ADD CONSTRAINT fkl8cxqyb3s8c31qbaqehu71u9e FOREIGN KEY (constantid) REFERENCES public.constant(constantid);


--
-- Name: fklcvyf20urcrk3k1grq17u5yxa; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.programindicatorusergroupaccesses
    ADD CONSTRAINT fklcvyf20urcrk3k1grq17u5yxa FOREIGN KEY (usergroupaccessid) REFERENCES public.usergroupaccess(usergroupaccessid);


--
-- Name: fkleuiq3mib4iq5q840n80cv993; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.documentattributevalues
    ADD CONSTRAINT fkleuiq3mib4iq5q840n80cv993 FOREIGN KEY (attributevalueid) REFERENCES public.attributevalue(attributevalueid);


--
-- Name: fkljaoalw4iomchlahjcmijy41n; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dataelementusergroupaccesses
    ADD CONSTRAINT fkljaoalw4iomchlahjcmijy41n FOREIGN KEY (usergroupaccessid) REFERENCES public.usergroupaccess(usergroupaccessid);


--
-- Name: fkljv6vp4ro5l6stx7dclnkenen; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.programmessage_deliverychannels
    ADD CONSTRAINT fkljv6vp4ro5l6stx7dclnkenen FOREIGN KEY (programmessagedeliverychannelsid) REFERENCES public.programmessage(id);


--
-- Name: fklllvhilfsouycft98q82ph66q; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pushanalysisrecipientusergroups
    ADD CONSTRAINT fklllvhilfsouycft98q82ph66q FOREIGN KEY (usergroupid) REFERENCES public.pushanalysis(pushanalysisid);


--
-- Name: fklq73q1u6q1w6uilvg8xjvqpkq; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.eventreportusergroupaccesses
    ADD CONSTRAINT fklq73q1u6q1w6uilvg8xjvqpkq FOREIGN KEY (usergroupaccessid) REFERENCES public.usergroupaccess(usergroupaccessid);


--
-- Name: fklxmc2s4f0e2a318ab6vda0n6p; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.eventreportuseraccesses
    ADD CONSTRAINT fklxmc2s4f0e2a318ab6vda0n6p FOREIGN KEY (eventreportid) REFERENCES public.eventreport(eventreportid);


--
-- Name: fklxqwf9ghutdfxongiorp2jpef; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.eventchartuseraccesses
    ADD CONSTRAINT fklxqwf9ghutdfxongiorp2jpef FOREIGN KEY (eventchartid) REFERENCES public.eventchart(eventchartid);


--
-- Name: fkly81qo12mmdwo1nuxqvdvw07d; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.programstageattributevalues
    ADD CONSTRAINT fkly81qo12mmdwo1nuxqvdvw07d FOREIGN KEY (attributevalueid) REFERENCES public.attributevalue(attributevalueid);


--
-- Name: fkm5h5tkbbogqelay0io9qm74o0; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.eventchartusergroupaccesses
    ADD CONSTRAINT fkm5h5tkbbogqelay0io9qm74o0 FOREIGN KEY (usergroupaccessid) REFERENCES public.usergroupaccess(usergroupaccessid);


--
-- Name: fkmfeihksbnauk0swgve0o96ewr; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.interpretationusergroupaccesses
    ADD CONSTRAINT fkmfeihksbnauk0swgve0o96ewr FOREIGN KEY (usergroupaccessid) REFERENCES public.usergroupaccess(usergroupaccessid);


--
-- Name: fkmk0h5ph7j0ep4nxjj2q5ga9r0; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.validationruleuseraccesses
    ADD CONSTRAINT fkmk0h5ph7j0ep4nxjj2q5ga9r0 FOREIGN KEY (validationruleid) REFERENCES public.validationrule(validationruleid);


--
-- Name: fkmmdfsq1s9g437k0wsshbivaht; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.externalmaplayerusergroupaccesses
    ADD CONSTRAINT fkmmdfsq1s9g437k0wsshbivaht FOREIGN KEY (externalmaplayerid) REFERENCES public.externalmaplayer(externalmaplayerid);


--
-- Name: fkmrqgrjgwtns2j3w5wvp2cil0f; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.indicatorgrouptranslations
    ADD CONSTRAINT fkmrqgrjgwtns2j3w5wvp2cil0f FOREIGN KEY (objecttranslationid) REFERENCES public.objecttranslation(objecttranslationid);


--
-- Name: fkmrvj9l6sv7su7wehohc9wipdu; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dashboardusergroupaccesses
    ADD CONSTRAINT fkmrvj9l6sv7su7wehohc9wipdu FOREIGN KEY (dashboardid) REFERENCES public.dashboard(dashboardid);


--
-- Name: fkms3h2rvf98325h17u60hnpfdx; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.programindicatoruseraccesses
    ADD CONSTRAINT fkms3h2rvf98325h17u60hnpfdx FOREIGN KEY (useraccessid) REFERENCES public.useraccess(useraccessid);


--
-- Name: fkmumx7i7wqjn3jh4mt4r4x1eqe; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.categoryoptiongroupsetusergroupaccesses
    ADD CONSTRAINT fkmumx7i7wqjn3jh4mt4r4x1eqe FOREIGN KEY (usergroupaccessid) REFERENCES public.usergroupaccess(usergroupaccessid);


--
-- Name: fkmw5yn4ptnpkve2lsvxiopdp6; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dashboardusergroupaccesses
    ADD CONSTRAINT fkmw5yn4ptnpkve2lsvxiopdp6 FOREIGN KEY (usergroupaccessid) REFERENCES public.usergroupaccess(usergroupaccessid);


--
-- Name: fkmwadbe8twmr8ordbjjlrloxnp; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.userroleusergroupaccesses
    ADD CONSTRAINT fkmwadbe8twmr8ordbjjlrloxnp FOREIGN KEY (usergroupaccessid) REFERENCES public.usergroupaccess(usergroupaccessid);


--
-- Name: fkmxrvdw7rdmo0o50qjbk30lw8f; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.eventreporttranslations
    ADD CONSTRAINT fkmxrvdw7rdmo0o50qjbk30lw8f FOREIGN KEY (objecttranslationid) REFERENCES public.objecttranslation(objecttranslationid);


--
-- Name: fkn2afpli3opeouwqvtguobc7td; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.reporttranslations
    ADD CONSTRAINT fkn2afpli3opeouwqvtguobc7td FOREIGN KEY (objecttranslationid) REFERENCES public.objecttranslation(objecttranslationid);


--
-- Name: fkn5mp5cao30al69clovpwwe6mk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.orgunitgroupsetusergroupaccesses
    ADD CONSTRAINT fkn5mp5cao30al69clovpwwe6mk FOREIGN KEY (usergroupaccessid) REFERENCES public.usergroupaccess(usergroupaccessid);


--
-- Name: fkn8cff8o99v6tnpgl2fgugjwpf; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.usergroupusergroupaccesses
    ADD CONSTRAINT fkn8cff8o99v6tnpgl2fgugjwpf FOREIGN KEY (usergroupid) REFERENCES public.usergroup(usergroupid);


--
-- Name: fkndy19mcicdsxoq15p0fd7p1ew; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.indicatorgroupsettranslations
    ADD CONSTRAINT fkndy19mcicdsxoq15p0fd7p1ew FOREIGN KEY (objecttranslationid) REFERENCES public.objecttranslation(objecttranslationid);


--
-- Name: fkne0hjh5lknlabbotmbpm9ynwx; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.optiongroupusergroupaccesses
    ADD CONSTRAINT fkne0hjh5lknlabbotmbpm9ynwx FOREIGN KEY (optiongroupid) REFERENCES public.optiongroup(optiongroupid);


--
-- Name: fkneu0r5aaxns3msvu5r7cpvjhk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.categoryoptiongroupsetuseraccesses
    ADD CONSTRAINT fkneu0r5aaxns3msvu5r7cpvjhk FOREIGN KEY (categoryoptiongroupsetid) REFERENCES public.categoryoptiongroupset(categoryoptiongroupsetid);


--
-- Name: fknfwv4dnc90au8jvtt3ra2scbl; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.indicatorgroupusergroupaccesses
    ADD CONSTRAINT fknfwv4dnc90au8jvtt3ra2scbl FOREIGN KEY (usergroupaccessid) REFERENCES public.usergroupaccess(usergroupaccessid);


--
-- Name: fkngn9j2oevi4k05245lqfhuyh4; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.indicatoruseraccesses
    ADD CONSTRAINT fkngn9j2oevi4k05245lqfhuyh4 FOREIGN KEY (useraccessid) REFERENCES public.useraccess(useraccessid);


--
-- Name: fknimjjjq6ww7vcnjbxw9qo3daa; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.orgunitgroupusergroupaccesses
    ADD CONSTRAINT fknimjjjq6ww7vcnjbxw9qo3daa FOREIGN KEY (orgunitgroupid) REFERENCES public.orgunitgroup(orgunitgroupid);


--
-- Name: fknqghxxgrlh1dyluj9fgh1x6pn; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.trackedentityattributeusergroupaccesses
    ADD CONSTRAINT fknqghxxgrlh1dyluj9fgh1x6pn FOREIGN KEY (usergroupaccessid) REFERENCES public.usergroupaccess(usergroupaccessid);


--
-- Name: fknthmdh7yci1po66i02ssldxod; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.legendsetattributevalues
    ADD CONSTRAINT fknthmdh7yci1po66i02ssldxod FOREIGN KEY (attributevalueid) REFERENCES public.attributevalue(attributevalueid);


--
-- Name: fknyh2e7xbcnv2iw3wvtk2ng8h9; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.orgunitgroupsetuseraccesses
    ADD CONSTRAINT fknyh2e7xbcnv2iw3wvtk2ng8h9 FOREIGN KEY (orgunitgroupsetid) REFERENCES public.orgunitgroupset(orgunitgroupsetid);


--
-- Name: fko74ok1o1jcw9b9byfp2c995lu; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.trackedentityattributetranslations
    ADD CONSTRAINT fko74ok1o1jcw9b9byfp2c995lu FOREIGN KEY (objecttranslationid) REFERENCES public.objecttranslation(objecttranslationid);


--
-- Name: fko7bqom2xom9t71509y9cxvh7f; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.optionsetuseraccesses
    ADD CONSTRAINT fko7bqom2xom9t71509y9cxvh7f FOREIGN KEY (useraccessid) REFERENCES public.useraccess(useraccessid);


--
-- Name: fko975uxx8n7sspdysehujj8e7t; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.mapusergroupaccesses
    ADD CONSTRAINT fko975uxx8n7sspdysehujj8e7t FOREIGN KEY (usergroupaccessid) REFERENCES public.usergroupaccess(usergroupaccessid);


--
-- Name: fkoccxpdljjjbxr1vrwfp9d25dt; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sqlviewusergroupaccesses
    ADD CONSTRAINT fkoccxpdljjjbxr1vrwfp9d25dt FOREIGN KEY (sqlviewid) REFERENCES public.sqlview(sqlviewid);


--
-- Name: fkokgalu75pd2e1no2x53cxe8ik; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.mapusergroupaccesses
    ADD CONSTRAINT fkokgalu75pd2e1no2x53cxe8ik FOREIGN KEY (mapid) REFERENCES public.map(mapid);


--
-- Name: fkopw1b57inx5x5sm7r22lh0qso; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.programstagetranslations
    ADD CONSTRAINT fkopw1b57inx5x5sm7r22lh0qso FOREIGN KEY (objecttranslationid) REFERENCES public.objecttranslation(objecttranslationid);


--
-- Name: fkou5go53l80o7omb2dqcpp7wjh; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.chartusergroupaccesses
    ADD CONSTRAINT fkou5go53l80o7omb2dqcpp7wjh FOREIGN KEY (usergroupaccessid) REFERENCES public.usergroupaccess(usergroupaccessid);


--
-- Name: fkp6b2s2prdt8o77hncyiyoc3w0; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.interpretationuseraccesses
    ADD CONSTRAINT fkp6b2s2prdt8o77hncyiyoc3w0 FOREIGN KEY (useraccessid) REFERENCES public.useraccess(useraccessid);


--
-- Name: fkp7of94t57djd0buqsc46xs32u; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.orgunitgroupattributevalues
    ADD CONSTRAINT fkp7of94t57djd0buqsc46xs32u FOREIGN KEY (orgunitgroupid) REFERENCES public.orgunitgroup(orgunitgroupid);


--
-- Name: fkp7u6oqpln4dt83wovshmrc1jo; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.programruletranslations
    ADD CONSTRAINT fkp7u6oqpln4dt83wovshmrc1jo FOREIGN KEY (objecttranslationid) REFERENCES public.objecttranslation(objecttranslationid);


--
-- Name: fkp8i8mavj9jd5q2lyqag2rhi03; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dataelementgroupattributevalues
    ADD CONSTRAINT fkp8i8mavj9jd5q2lyqag2rhi03 FOREIGN KEY (dataelementgroupid) REFERENCES public.dataelementgroup(dataelementgroupid);


--
-- Name: fkpe7wkmr4j7aury8bwntn2jd0k; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dataelementgroupuseraccesses
    ADD CONSTRAINT fkpe7wkmr4j7aury8bwntn2jd0k FOREIGN KEY (useraccessid) REFERENCES public.useraccess(useraccessid);


--
-- Name: fkperhr810jcqprtiija9b5a4tj; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.usergroupuseraccesses
    ADD CONSTRAINT fkperhr810jcqprtiija9b5a4tj FOREIGN KEY (useraccessid) REFERENCES public.useraccess(useraccessid);


--
-- Name: fkpmebskggkjfjfwxw7u43twmg2; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.datasetnotificationtemplate_deliverychannel
    ADD CONSTRAINT fkpmebskggkjfjfwxw7u43twmg2 FOREIGN KEY (datasetnotificationtemplateid) REFERENCES public.datasetnotificationtemplate(datasetnotificationtemplateid);


--
-- Name: fkprt8bw5cw4fvcnpfe9iayng1v; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.attributetranslations
    ADD CONSTRAINT fkprt8bw5cw4fvcnpfe9iayng1v FOREIGN KEY (objecttranslationid) REFERENCES public.objecttranslation(objecttranslationid);


--
-- Name: fkq1mwh4ffdsnhwn7v097eayid5; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.categoryoptiongroupuseraccesses
    ADD CONSTRAINT fkq1mwh4ffdsnhwn7v097eayid5 FOREIGN KEY (categoryoptiongroupid) REFERENCES public.categoryoptiongroup(categoryoptiongroupid);


--
-- Name: fkq35si1aa88tk4o4ygpn8my54q; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.attributeusergroupaccesses
    ADD CONSTRAINT fkq35si1aa88tk4o4ygpn8my54q FOREIGN KEY (attributeid) REFERENCES public.attribute(attributeid);


--
-- Name: fkq6f4o8i51dngmiimuj3wctes3; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.userattributevalues
    ADD CONSTRAINT fkq6f4o8i51dngmiimuj3wctes3 FOREIGN KEY (userinfoid) REFERENCES public.userinfo(userinfoid);


--
-- Name: fkq80dj8d4slnw9lna5jrsdxxou; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.indicatorgroupsetusergroupaccesses
    ADD CONSTRAINT fkq80dj8d4slnw9lna5jrsdxxou FOREIGN KEY (usergroupaccessid) REFERENCES public.usergroupaccess(usergroupaccessid);


--
-- Name: fkqf598s5kghjesta6ibgiepbnp; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.userroleuseraccesses
    ADD CONSTRAINT fkqf598s5kghjesta6ibgiepbnp FOREIGN KEY (userroleid) REFERENCES public.userrole(userroleid);


--
-- Name: fkqgvpllqqqfstetxiuikf4my7q; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.categoryoptiongrouptranslations
    ADD CONSTRAINT fkqgvpllqqqfstetxiuikf4my7q FOREIGN KEY (objecttranslationid) REFERENCES public.objecttranslation(objecttranslationid);


--
-- Name: fkqit4l4bglf1xnh7jo7i3x11e7; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.optiongroupuseraccesses
    ADD CONSTRAINT fkqit4l4bglf1xnh7jo7i3x11e7 FOREIGN KEY (optiongroupid) REFERENCES public.optiongroup(optiongroupid);


--
-- Name: fkqky1rnn3ulqpc6j0mpjrm7elm; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.usergroupusergroupaccesses
    ADD CONSTRAINT fkqky1rnn3ulqpc6j0mpjrm7elm FOREIGN KEY (usergroupaccessid) REFERENCES public.usergroupaccess(usergroupaccessid);


--
-- Name: fkql75bu38n82o2bha8qt65nk2p; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.trackedentitytypeusergroupaccesses
    ADD CONSTRAINT fkql75bu38n82o2bha8qt65nk2p FOREIGN KEY (usergroupaccessid) REFERENCES public.usergroupaccess(usergroupaccessid);


--
-- Name: fkqramkdhx87vxn8oybmygjbu1a; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.validationcriteriatranslations
    ADD CONSTRAINT fkqramkdhx87vxn8oybmygjbu1a FOREIGN KEY (objecttranslationid) REFERENCES public.objecttranslation(objecttranslationid);


--
-- Name: fkqsfp938c3hscdt0l85kakwtxr; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.datasetattributevalues
    ADD CONSTRAINT fkqsfp938c3hscdt0l85kakwtxr FOREIGN KEY (attributevalueid) REFERENCES public.attributevalue(attributevalueid);


--
-- Name: fkqv5w8d50v5bhcsvwahlwfslqu; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.constantusergroupaccesses
    ADD CONSTRAINT fkqv5w8d50v5bhcsvwahlwfslqu FOREIGN KEY (usergroupaccessid) REFERENCES public.usergroupaccess(usergroupaccessid);


--
-- Name: fkr7hn20ublmb237x85sj6imdbf; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.eventreportuseraccesses
    ADD CONSTRAINT fkr7hn20ublmb237x85sj6imdbf FOREIGN KEY (useraccessid) REFERENCES public.useraccess(useraccessid);


--
-- Name: fkrbtkonmtsb3dd6fri8jh4kcgx; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.colorsettranslations
    ADD CONSTRAINT fkrbtkonmtsb3dd6fri8jh4kcgx FOREIGN KEY (objecttranslationid) REFERENCES public.objecttranslation(objecttranslationid);


--
-- Name: fkrj07bbr93ggi7te3wclxftolp; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.eventchartuseraccesses
    ADD CONSTRAINT fkrj07bbr93ggi7te3wclxftolp FOREIGN KEY (useraccessid) REFERENCES public.useraccess(useraccessid);


--
-- Name: fkrjv6nocvx88v1l9ygtbf5p5sb; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.trackedentitytypeattributevalues
    ADD CONSTRAINT fkrjv6nocvx88v1l9ygtbf5p5sb FOREIGN KEY (trackedentitytypeid) REFERENCES public.trackedentitytype(trackedentitytypeid);


--
-- Name: fkrk1nime7qkj74qk8bvl71nnu0; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.reporttableuseraccesses
    ADD CONSTRAINT fkrk1nime7qkj74qk8bvl71nnu0 FOREIGN KEY (useraccessid) REFERENCES public.useraccess(useraccessid);


--
-- Name: fkrlanjumcue8qe8csk47invf0m; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.chartuseraccesses
    ADD CONSTRAINT fkrlanjumcue8qe8csk47invf0m FOREIGN KEY (useraccessid) REFERENCES public.useraccess(useraccessid);


--
-- Name: fkrq69i1s0tkmw9u0mga5eggoyx; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dataapprovalleveltranslations
    ADD CONSTRAINT fkrq69i1s0tkmw9u0mga5eggoyx FOREIGN KEY (objecttranslationid) REFERENCES public.objecttranslation(objecttranslationid);


--
-- Name: fks04qh58fxmsf5601n9cvpdtc8; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.chart_filters
    ADD CONSTRAINT fks04qh58fxmsf5601n9cvpdtc8 FOREIGN KEY (chartid) REFERENCES public.chart(chartid);


--
-- Name: fks1k3a2f1c1isq1ujtwwqwfonx; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.indicatorusergroupaccesses
    ADD CONSTRAINT fks1k3a2f1c1isq1ujtwwqwfonx FOREIGN KEY (usergroupaccessid) REFERENCES public.usergroupaccess(usergroupaccessid);


--
-- Name: fks24flr8pd794omx6xusmkeboe; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dataelementgroupusergroupaccesses
    ADD CONSTRAINT fks24flr8pd794omx6xusmkeboe FOREIGN KEY (dataelementgroupid) REFERENCES public.dataelementgroup(dataelementgroupid);


--
-- Name: fks2olf101iiehl4ekaw0ytbmpg; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dataelementgroupattributevalues
    ADD CONSTRAINT fks2olf101iiehl4ekaw0ytbmpg FOREIGN KEY (attributevalueid) REFERENCES public.attributevalue(attributevalueid);


--
-- Name: fks2timamyiijrioyi2nd5ysxjc; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.userattributevalues
    ADD CONSTRAINT fks2timamyiijrioyi2nd5ysxjc FOREIGN KEY (attributevalueid) REFERENCES public.attributevalue(attributevalueid);


--
-- Name: fks3en52yvnu8nfdbcbsqdealwu; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sectionattributevalues
    ADD CONSTRAINT fks3en52yvnu8nfdbcbsqdealwu FOREIGN KEY (attributevalueid) REFERENCES public.attributevalue(attributevalueid);


--
-- Name: fks5roynmoahk5mqu1j019ym7; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sectionattributevalues
    ADD CONSTRAINT fks5roynmoahk5mqu1j019ym7 FOREIGN KEY (sectionid) REFERENCES public.section(sectionid);


--
-- Name: fks6crbtws3n0g2os9894uyb0c4; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.validationrulegroupusergroupaccesses
    ADD CONSTRAINT fks6crbtws3n0g2os9894uyb0c4 FOREIGN KEY (validationrulegroupid) REFERENCES public.validationrulegroup(validationrulegroupid);


--
-- Name: fksfctbv0m7p1qyf32jisp4u031; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.eventcharttranslations
    ADD CONSTRAINT fksfctbv0m7p1qyf32jisp4u031 FOREIGN KEY (objecttranslationid) REFERENCES public.objecttranslation(objecttranslationid);


--
-- Name: fksii4ij2x35tx3f9u7a76k78jl; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.maplegendtranslations
    ADD CONSTRAINT fksii4ij2x35tx3f9u7a76k78jl FOREIGN KEY (objecttranslationid) REFERENCES public.objecttranslation(objecttranslationid);


--
-- Name: fksmifkdbg5bgp66c2yl203lqrn; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.optiongroupattributevalues
    ADD CONSTRAINT fksmifkdbg5bgp66c2yl203lqrn FOREIGN KEY (optiongroupid) REFERENCES public.optiongroup(optiongroupid);


--
-- Name: fksn12ea6xcfweyp0bob6tssdcg; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.orgunitgroupusergroupaccesses
    ADD CONSTRAINT fksn12ea6xcfweyp0bob6tssdcg FOREIGN KEY (usergroupaccessid) REFERENCES public.usergroupaccess(usergroupaccessid);


--
-- Name: fksr8r9m97g9uc7b2nnbfp394hb; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dataelementcategoryuseraccesses
    ADD CONSTRAINT fksr8r9m97g9uc7b2nnbfp394hb FOREIGN KEY (useraccessid) REFERENCES public.useraccess(useraccessid);


--
-- Name: fksxqbj4uf6wwv2aqx2c9ay1ulk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.programstageuseraccesses
    ADD CONSTRAINT fksxqbj4uf6wwv2aqx2c9ay1ulk FOREIGN KEY (useraccessid) REFERENCES public.useraccess(useraccessid);


--
-- Name: fkt27tftlhawo7tq1t1embuwc5e; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.mapviewtranslations
    ADD CONSTRAINT fkt27tftlhawo7tq1t1embuwc5e FOREIGN KEY (objecttranslationid) REFERENCES public.objecttranslation(objecttranslationid);


--
-- Name: fkt66m7wsp2phes81tx37l4sn4b; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.indicatorgroupsetusergroupaccesses
    ADD CONSTRAINT fkt66m7wsp2phes81tx37l4sn4b FOREIGN KEY (indicatorgroupsetid) REFERENCES public.indicatorgroupset(indicatorgroupsetid);


--
-- Name: fkt7cgg1phqdlubtcwekr6jd785; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.legendsetattributevalues
    ADD CONSTRAINT fkt7cgg1phqdlubtcwekr6jd785 FOREIGN KEY (legendsetid) REFERENCES public.maplegendset(maplegendsetid);


--
-- Name: fktisxi0u191gvem3n2twyvni4y; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.optiongroupsetuseraccesses
    ADD CONSTRAINT fktisxi0u191gvem3n2twyvni4y FOREIGN KEY (optiongroupsetid) REFERENCES public.optiongroupset(optiongroupsetid);


--
-- Name: fktl0s6blarqvbvjhnoa94drtb2; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.smscommandspecialcharacters
    ADD CONSTRAINT fktl0s6blarqvbvjhnoa94drtb2 FOREIGN KEY (specialcharacterid) REFERENCES public.smsspecialcharacter(specialcharacterid);


--
-- Name: fktl5384fpv5fdjv4ke8e34ul6e; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.optiongrouptranslations
    ADD CONSTRAINT fktl5384fpv5fdjv4ke8e34ul6e FOREIGN KEY (objecttranslationid) REFERENCES public.objecttranslation(objecttranslationid);


--
-- Name: fktldthr3a2gqcrcngmtglr7kdr; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dashboarduseraccesses
    ADD CONSTRAINT fktldthr3a2gqcrcngmtglr7kdr FOREIGN KEY (useraccessid) REFERENCES public.useraccess(useraccessid);


--
-- Name: fktlnn6e4dj457rtlgf8gaangnq; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.usergroupattributevalues
    ADD CONSTRAINT fktlnn6e4dj457rtlgf8gaangnq FOREIGN KEY (attributevalueid) REFERENCES public.attributevalue(attributevalueid);


--
-- Name: fktokd1a55e5b1vetrjv1ka84av; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dataelementcategoryoptionattributevalues
    ADD CONSTRAINT fktokd1a55e5b1vetrjv1ka84av FOREIGN KEY (categoryoptionid) REFERENCES public.dataelementcategoryoption(categoryoptionid);


--
-- Name: fku1h7cukhyye5ejgjbs0kaye0; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.programusergroupaccesses
    ADD CONSTRAINT fku1h7cukhyye5ejgjbs0kaye0 FOREIGN KEY (programid) REFERENCES public.program(programid);


--
-- Name: fku37f3oirygw2xn7gqgo6rnq9; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.indicatortranslations
    ADD CONSTRAINT fku37f3oirygw2xn7gqgo6rnq9 FOREIGN KEY (objecttranslationid) REFERENCES public.objecttranslation(objecttranslationid);


--
-- Name: fkv2m3q13hlwe2199m0wy2mmqv; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.constantuseraccesses
    ADD CONSTRAINT fkv2m3q13hlwe2199m0wy2mmqv FOREIGN KEY (useraccessid) REFERENCES public.useraccess(useraccessid);


--
-- Name: SCHEMA public; Type: ACL; Schema: -; Owner: -
--

REVOKE ALL ON SCHEMA public FROM PUBLIC;
REVOKE ALL ON SCHEMA public FROM postgres;
GRANT ALL ON SCHEMA public TO postgres;
GRANT ALL ON SCHEMA public TO PUBLIC;


--
-- PostgreSQL database dump complete
--

